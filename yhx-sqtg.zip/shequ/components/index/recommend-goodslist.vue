<template>
	<view>
		<view class="recommend-goodslist" v-for="(item,index) in recommendgoodslistdata" :key="index" >
			<image class="recommend-goodslist-img" :src="item.src" style="height: 270upx;"></image>
			<button class="mini-btn" type="default" size="mini" style="float: right;color:rgba(60,192,117,1);background:#FFFFFF;border-radius:19px;font-size: 20upx;margin-right: 24upx;border:1px solid rgba(60,192,117,1);">仅剩6袋</button>
			<button class="mini-btn" type="default" size="mini" style="float: right;color:rgba(60,192,117,1);background:#FFFFFF;border-radius:19px;font-size: 20upx;margin-right: 24upx;border:1px solid rgba(60,192,117,1);">累积8个</button>
			<view class="recommend-goodslist-text" style="font-size: 26upx;margin-left: 24upx;">{{item.title}}</view>
			
			<view class="recommend-goodslist-text" style="font-size: 20upx;color: #999999;margin-left: 24upx;">预计到货：{{item.arrivetime}}</view>
			<text class="recommend-goodslist-price" style="color: #F25576 !important; font-size: 24upx;margin-left: 24upx;">￥{{item.price}}</text>
			<text style='color:#999999 !important;text-decoration:line-through;font-size: 20upx;margin-left: 24upx;'> ￥{{item.sales}} </text>
			<button type="default" size="mini" style="color: #FFFFFF;float: right;background:rgba(60,192,117,1);border-radius:19px;font-size: 24upx;margin-top: -15upx;margin-right: 20upx;">立即购买</button>
		</view>
	</view>
</template>
<script>
    
    export default {
        props:{
			recommendgoodslistdata:Array,
			default:''
		},
        data() {
          return{
			  
		  }
                
        },
        onLoad() {
        },
        onReady() {
        },
        onShow() {
            
        },
        onHide() {
            
        },
        methods: {
            
        }
		
    }
</script>

<style>
</style>
