<template>
	<view class="Carousel">
		<swiper indicator-dots autoplay :interval="3000" :duration="1000" circular>
			<block v-for="(item,index) in resdata" :key="index">
			<swiper-item>
				<view class="swiper-item" @tap="event(item)">
					<image :src="item.src" lazy-load style="height: 350upx;width: 750upx;"></image>
				</view>
			</swiper-item>
			</block>
		</swiper>
	</view>
</template>

<script>
	export default {
		props:{
			resdata:Array
		},
		methods:{
			event(tem){
				console.log("点解了轮播")
			}
		}
	}
</script>

<style lang="less" scoped>
	.Carousel{border-radius: 50upx;}
	
</style>
