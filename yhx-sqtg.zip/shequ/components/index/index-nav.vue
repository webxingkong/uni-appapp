<template>
    <view class="row j-center m-2">
    	<block v-for="(item,index) in resdata" :key="index">
			<view class="span-4 d-flex flex-column j-center a-center py1" @tap="even(item)">
				<image :src="item.src" style="width: 92upx; height: 92upx;"></image>
				<text style="font-size: 28upx;">{{item.text}}</text>
			</view>
    	</block>
	</view>
</template>
<script>
    
    export default {
        props:{
			resdata:Array
		},
        data() {
          return{
			  
		  }
                
        },
        onLoad() {
        },
        onReady() {
        },
        onShow() {
            
        },
        onHide() {
            
        },
        methods: {
            even(item){
				console.log(item);
        }
		}
    }
</script>

<style>
    .row{background-color: #666666;height: 168upx;}
</style>
