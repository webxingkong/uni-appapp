<template>
    <view class="uni-container">
        <view>
			<view>为了更好的购物体验</view>
			<view>请您授权登录</view>
			<image src="../../static/index_img/nothing.png" style="width: 365rpx;height: 365rpx;"></image>
			<button type="primary" style="margin-bottom: 20rpx;" @click="getuserInfo">登录</button>
			<button type="primary" @click="unagree">随便逛逛</button>
		</view>
    </view>
</template>
<script>
    
    export default {
        
        data() {
			return{
				"regiment_img":"",
				"title": 'get/set/clearStorage',
				"key": '',
				"data": ''
			} 
        },
        onLoad() {
			this.setStorage();
        },
        onReady() {
        },
        onShow() {
            
        },
        onHide() {
            
        },
        methods: {
			// 获取用户信息
            getuserInfo(){
				uni.getUserInfo({
					provider: this.loginProvider,
					success: (result) => {
						console.log('getUserInfo success', result);
						this.regiment_img=result.userInfo.avatarUrl;
						this.hasUserInfo = true;
						this.userInfo = result.userInfo;
						uni.setStorage({
						    key: 'userInfo_key',
						    data: result,
						    success: function () {
						        // console.log(result.userInfo.avatarUrl);
						        // console.log("88888888");
						    }
						});
						
					},
					fail: (error) => {
						console.log('getUserInfo fail', error);
						let content = error.errMsg;
						if (~content.indexOf('uni.login')) {
							content = '请在登录页面完成登录操作';
						}
						uni.showModal({
							title: '获取用户信息失败',
							content: '错误原因' + content,
							showCancel: false
						});
					}
				});
				uni.switchTab({
				    url: '../../pages/tabbar/index/index',
					success: function(){
						 let page = getCurrentPages().pop();  //跳转页面成功之后
						             if (!page) return;  
						             page.onLoad(); //如果页面存在，则重新刷新页面

						console.log("登录页面");
					}
				});
			},
			unagree: function(){
				uni.switchTab({
				    url: '../../pages/tabbar/index/index',
					success: function(){
						 let page = getCurrentPages().pop();  //跳转页面成功之后
             if (!page) return;  
             page.onLoad(); //如果页面存在，则重新刷新页面

						console.log("wei登录页面");
					}
				});
				
			}
        }
    };
</script>

<style>
	.uni-container{
		width: 686rpx;
		margin-left: 32rpx;
		margin-right: 32rpx;
		background: #FFFFFF;
	}
</style>
