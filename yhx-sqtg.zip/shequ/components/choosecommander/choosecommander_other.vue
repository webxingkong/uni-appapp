<template name="choosecommanderother">
	<view class="lacation_list">
		<view class="location_top">
			附近团长
		</view>
		<view class="location_center flex">
			<view class="location_img flex">
				<image src="../../static/0907165353.png" style="width: 110rpx;height: 110rpx;"></image>
				<view style="margin-left: 19rpx;">
					<view style="font-size: 30rpx;">丫丫便利店</view>
					<view class="flex" style="justify-content: space-between;">
						<view class="flex_wrap" style="">取货地址：啊覅时代受到收到发哦四佛阿斯</view>
						<image class="address_img" src="../../static/commodity_icon/address.png" style=""></image>
					</view>
					<view class="flex" style="justify-content: space-between;">
						<text style="color: #666666;font-size: 28rpx;">距您:&nbsp;&nbsp;25.0km</text>
						<button class="paybutton" type="primary" size="mini" @click="openPopup">就选这位</button>
					</view>
				</view>
			</view>
		</view>
		<uni-popup ref="popup" type="center">
		    <view class="m0">
				<view class="f32 fb" style="margin-top: 88rpx;">提醒</view>
				<view class="flex_wrap presentation">您选择的团长距离您5.9km,是否确定选择？</view>
			</view>
		    <view class="flex btn_buttom" style="justify-content: space-between;">
				<button class="cancel fb" plain="true" @click="closePopup">取消</button>
				<button class="sure fb" type="primary" plain="true">确定</button>
			</view>
		</uni-popup>
	</view>
	
</template>

<script>
	import uniPopup from "../uni-popup/uni-popup.vue"
	
	export default {
		components:{
			uniPopup
		},
		name:"choosecommanderother",
		props: {
			options: {
				type: String,
				default: function(e) {
					return {}
				}
			}
		},
		methods:{
			openPopup(){
			    this.$refs.popup.open()
			},
			closePopup(){
			    this.$refs.popup.close()
			}
		}
	}
</script>

<style>
	.btn_buttom button{
		border-radius: 0 !important;
		width: 50%;
	}
	.m0{
		width: 674rpx;height: 394rpx;
	}
	.cancel{
		border: #C9C7C7 1px solid !important;border-right: #FFFFFF !important;color: #666666;font-weight: bold;
	}
	.sure{
		border: #C9C7C7 1px solid !important;font-weight: bold;
	}
	.presentation{
		width: 445rpx;font-size: 28rpx;margin-left: 110rpx;margin-top: 59rpx;
	}
	.lacation_list{
		height: 256rpx;
		background: #FFFFFF;
		margin-left: 32rpx;
		margin-top: 16rpx;
		margin-right: 32rpx;
		width: 100%;
		border-radius: 12rpx;
	}
	.location_top{
		width: 120rpx;height: auto;background: #8CB739;color: #FFFFFF;border-radius: 12rpx 0rpx 12rpx 0rpx;
	}
	.location_center{
		justify-content: space-between;margin-top: 31rpx;
	}
	.location_img{
		justify-content:flex-start
	}
	.flex_wrap{
		width: 393rpx;font-size: 28rpx;color: #666666;flex-direction: row;line-height: 32rpx;
	}
	.address_img{
		width: 40rpx;height: 44rpx;margin-left: 76rpx;margin-top: -15rpx;
	}
	.location_address_img image{
		width: 40rpx;height: 44rpx;
	}
	.paybutton{
		font-size: 24rpx;border-radius: 22rpx;background: #3CC075;color: #FFFFFF;margin-left: 206rpx;
	}
</style>

