<template name="choosecommandertpl">
	<view class="lacation_list">
		<view class="location_top">
			当前团长
		</view>
		<view class="location_center flex">
			<view class="location_img flex" style="">
				<image src="../../static/0907165353.png" style="width: 110rpx;height: 110rpx;"></image>
				<view style="margin-left: 19rpx;">
					<view style="font-size: 30rpx;">丫丫便利店</view>
					<view class="flex_wrap" style="">取货地址：啊覅时代受到收到发哦四佛阿斯</view>
					<view style="margin-top: 10rpx;color: #666666;font-size: 28rpx;">距您:&nbsp;&nbsp;25.0km</view>
				</view>
			</view>
			<view class="location_address_img">
				<image src="../../static/commodity_icon/address.png"></image>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		name:"choosecommandertpl",
		props: {
			options: {
				type: String,
				default: function(e) {
					return {}
				}
			}
		},
	}
</script>

<style>
	.lacation_list{
		height: 256rpx;
		background: #FFFFFF;
		margin-left: 32rpx;
		margin-top: 16rpx;
		margin-right: 32rpx;
		width: 100%;
		border-radius: 12rpx;
	}
	.location_top{
		width: 120rpx;height: auto;background: #3CC075;color: #FFFFFF;border-radius: 12rpx 0rpx 12rpx 0rpx;
	}
	.location_center{
		justify-content: space-between;margin-top: 31rpx;
	}
	.location_img{
		justify-content:flex-start
	}
	.flex_wrap{
		width: 393rpx;font-size: 28rpx;color: #666666;flex-direction: row;line-height: 32rpx;
	}
	
	.location_address_img image{
		width: 40rpx;height: 44rpx;margin-right: 24rpx;margin-top: 40rpx;
	}
</style>