<script>

	export default {
		onLaunch: function() {
		},
		onShow: function() {
		},
		onHide: function() {
			console.log('App Hide')
		},
		
	}
</script>

<style>
	@import "./common/uni.css";
	@import "./common/common.css";
	@import "./common/zcm-main.css";
	@import "./common/my-assembly.css";
	
@font-face {
  font-family: 'iconfont';  /* project id 1395192 */
  src: url('//at.alicdn.com/t/font_1395192_e9ra4f05r44.eot');
  src: url('//at.alicdn.com/t/font_1395192_e9ra4f05r44.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_1395192_e9ra4f05r44.woff2') format('woff2'),
  url('//at.alicdn.com/t/font_1395192_e9ra4f05r44.woff') format('woff'),
  url('//at.alicdn.com/t/font_1395192_e9ra4f05r44.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_1395192_e9ra4f05r44.svg#iconfont') format('svg');
}
@font-face {
  font-family: 'iconfont';  /* project id 1395133 */
  src: url('//at.alicdn.com/t/font_1395133_axm033e6uxt.eot');
  src: url('//at.alicdn.com/t/font_1395133_axm033e6uxt.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_1395133_axm033e6uxt.woff2') format('woff2'),
  url('//at.alicdn.com/t/font_1395133_axm033e6uxt.woff') format('woff'),
  url('//at.alicdn.com/t/font_1395133_axm033e6uxt.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_1395133_axm033e6uxt.svg#iconfont') format('svg');
}
@font-face {
  font-family: 'iconfont';  /* project id 1417230 */
  src: url('//at.alicdn.com/t/font_1417230_lfxqv9hqzj.eot');
  src: url('//at.alicdn.com/t/font_1417230_lfxqv9hqzj.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_1417230_lfxqv9hqzj.woff2') format('woff2'),
  url('//at.alicdn.com/t/font_1417230_lfxqv9hqzj.woff') format('woff'),
  url('//at.alicdn.com/t/font_1417230_lfxqv9hqzj.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_1417230_lfxqv9hqzj.svg#iconfont') format('svg');
}
@font-face {
  font-family: 'iconfont';  /* project id 1395133 */
  src: url('//at.alicdn.com/t/font_1395133_2885nm0n9kv.eot');
  src: url('//at.alicdn.com/t/font_1395133_2885nm0n9kv.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_1395133_2885nm0n9kv.woff2') format('woff2'),
  url('//at.alicdn.com/t/font_1395133_2885nm0n9kv.woff') format('woff'),
  url('//at.alicdn.com/t/font_1395133_2885nm0n9kv.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_1395133_2885nm0n9kv.svg#iconfont') format('svg');
}
	.iconfont{
		font-family:"iconfont" !important;
		font-style:normal;
		-webkit-font-smoothing: antialiased;
		-webkit-text-stroke-width: 0.2px;
		-moz-osx-font-smoothing: grayscale;
	}
	page{
		background:#F4F4F4;
	}
	@import "common/common.css"; /* 公共css */
	@font-face {
	  font-family: 'iconfont';  /* project id 1397209 */
	  src: url('//at.alicdn.com/t/font_1397209_sahmzdmz38i.eot');
	  src: url('//at.alicdn.com/t/font_1397209_sahmzdmz38i.eot?#iefix') format('embedded-opentype'),
	  url('//at.alicdn.com/t/font_1397209_sahmzdmz38i.woff2') format('woff2'),
	  url('//at.alicdn.com/t/font_1397209_sahmzdmz38i.woff') format('woff'),
	  url('//at.alicdn.com/t/font_1397209_sahmzdmz38i.ttf') format('truetype'),
	  url('//at.alicdn.com/t/font_1397209_sahmzdmz38i.svg#iconfont') format('svg');
	}
	.iconfont{
		font-family:"iconfont" !important;
		font-style:normal;
		-webkit-font-smoothing: antialiased;
		-webkit-text-stroke-width: 0.2px;
		-moz-osx-font-smoothing: grayscale;
	}
	/* 分享所需的样式 */
	@font-face {
			font-family: 'font_family';  /* project id 1065286 */
			src: url('//at.alicdn.com/t/font_1065286_3bsye5aijur.eot');
			src: url('//at.alicdn.com/t/font_1065286_3bsye5aijur.eot?#iefix') format('embedded-opentype'),
			url('//at.alicdn.com/t/font_1065286_3bsye5aijur.woff2') format('woff2'),
			url('//at.alicdn.com/t/font_1065286_3bsye5aijur.woff') format('woff'),
			url('//at.alicdn.com/t/font_1065286_3bsye5aijur.ttf') format('truetype'),
			url('//at.alicdn.com/t/font_1065286_3bsye5aijur.svg#font_family') format('svg');
	 }
	 .font_family{
			font-family:"font_family" !important;
			font-size:16px;font-style:normal;
			-webkit-font-smoothing: antialiased;
			-webkit-text-stroke-width: 0.2px;
			-moz-osx-font-smoothing: grayscale;
	 }
	page {
		background-color: #F4F5F6;
		height: 100%;
		font-size: 28rpx;
		line-height: 1.8;
	}
	
</style>
