/* 首页 */
const index = '/index'//首页
/* 授权登录 */
const authorization='/authorization'//授权
/* 商品 */
const goodInfo = '/good_info' //商品详情
const goodTypes ='/good_types'//商品分类
const goodLists = '/good_lists' //商品列表
const goodList2 = '/good_list2' //商品列表2

/* 购物车 */
const shopCart = '/shop_cart' //购物车
const shopAdd = '/shop_add' //加入购物车
const shopPlus = '/shop_plus' //购物车商品数量增加
const shopReduce = '/shop_reduce' //购物车数量减少
const shopDel = '/shop_del' //购物车删除
const RightBuy = '/Right_buy' //立刻购买

/* 提交支付 */
const placeOrder = '/place_order' //提交订单
const payOrder = '/pay_order' //支付订单
const ckorder = '/ckorder' //点击提交付款按钮订单

/* 优惠卷 */

const couponLists = '/coupon_lists' //优惠卷列表
const couponInfo = '/coupon_info' //优惠卷详情

/* 订单列表 */
const orderLists = '/order_lists' //订单列表
const orderNnpaid = '/order_unpaid' //待付款订单
const orderSuccess = '/order_success' //已完成订单
const orderInfo = '/order_info' //订单详情

/* 选择团长 */
const chooseCommander = '/choose_commander' //团长信息
const checkedCommander = '/checked_commander' //选择团长

/* 搜索 */
const search = '/search' //搜索商品
const pussearch = '/pussearch' //搜索商品

/* 我的 */
const mycenter = '/mycenter' //我的中心
const integral = '/integral' //积分
const userAddress = '/path/user_address' //用户地址列表
const addressInsert = '/path/address_insert' //地址管理新增
const addressInfo = '/address_info' //地址编辑
const editAddress = '/edit_address' //地址修改提交
const addressDefault = '/address_default' //默认地址 
const addressDel = '/address_del' //地址删除

const membership='/membership'//会员权益
const Recommend='/Recommend'//推荐有奖
const balance='/balance'//余额
const Life='/Life'//生活服务


module.exports = {
	/* 首页 */
    index,
	/* 商品 */
	goodInfo,
	goodTypes,
	goodLists,
	goodList2,
	/* 购物车 */
	shopCart,
	shopAdd,
	shopPlus,
	shopReduce,
	shopDel,
	/* 提交支付 */
	placeOrder,
	payOrder,
	ckorder,
	/* 优惠卷 */
	
	couponLists,
	couponInfo,
	/* 订单列表 */
	orderLists,
	orderNnpaid,
	orderSuccess,
	orderInfo,
	/* 选择团长 */
	chooseCommander ,
	checkedCommander,
	/* 搜索 */
	search,
	/* 我的 */
	mycenter,
	integral,
    userAddress, //用户地址列表
    addressInsert,//地址管理新增
	addressInfo,//地址编辑
    editAddress, //地址修改提交
	addressDefault,//默认地址
    addressDel,//地址删除
	/* 会员权益 */
	membership,
	/* 推荐有奖 */
	Recommend,
	balance,
	Life,
	authorization,
	RightBuy,//立刻购买
	pussearch,
}