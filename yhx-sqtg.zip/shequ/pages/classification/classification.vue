<template>
	<view>
		<searh-s></searh-s><!-- 搜索栏 -->
		<!--分栏部分-->
		<view class="uni-tab-bar">
	<scroll-view scroll-x class="uni-swiper-tab">
		<block v-for="(item,index) in tabBars" :key="index">
		<view class="swiper-tab-list"  :class="{'active':tabIndex==index}"  @tap="tabswper(item.id,index)">
			{{item.name}}
			<view class="Line"></view>
		</view>
		</block>
	</scroll-view>
	</view>
		<!--展示区域-->
		<scroll-view v-for="(item1,index1) in commoditydata" :key="index1" @click="to_detali()">
			<view class="flex mt15 b_color b_radisu box-size pl5" style="justify-content:space-between;box-shadow:0px 6px 4px 0px rgba(76,175,56,0.06);">
			<view style="flex"><image :src="item1.good_img_url" style="width: 198rpx;height: 198rpx;border-radius:10rpx;"></image></view>
				<view class="flex flex_line_c_m f28 box-size" style="padding-right: 100rpx;">
					<text >{{item1.product_name}}</text>
					<text class="felx" style="flex-direction: row;">
					<text style="color:#F25576;">￥{{item1.product_price}}<text class="fonts pl20 fontcolorhh">{{item1.product_spurious_price}}</text></text>
					</text>
					<text>累计限量{{item1.sale_amount}}{{item1.good_unit}}</text>
				</view>
				<image class="totop" src="../../static/index_img/backtop.png" @click="top()" v-show="swithtop"></image>
				
					<view style="align-self:flex-end">
						<view class="uni-numbox flex_lr_ms pb30 pr30 box-size" style="display: flex; margin-left:45rpx;" v-if="item1.sale_amount!==item1.product_stock">
							<view class="uni-numbox__minus box-size" @click.stop="goods_red(item1,index1)"  v-show="item1.good_cart_num>0">-</view>
							<input class="uni-numbox__value pl10 box-size" disabled="false" type="number" :value="item1.good_cart_num" v-show="item1.good_cart_num>0">
							<view class="uni-numbox__plus" @click.stop="goods_add(item1,index1)">+</view>
						</view>
					<!-- 	过期的样式 -->
						<view class="uni-numbox flex_lr_ms pb30 pr30 box-size" style="display: flex; margin-left:45rpx;" v-if="item1.sale_amount==item1.product_stock">
							<image src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/classification/icon-2@2x.png" style="height:110rpx; width:120rpx;"></image>
						</view>
					</view>
			</view>
		</scroll-view>
		
			<!-- 底部加载更多的显示 -->
		<view class="load tc f28 lh28 mt15" style="color:#6D6D72; height:30rpx; margin-bottom:50rpx;">已经到达底部了</text></view>
		
		<view class="flex_tbr bgb"  style="width:749rpx;height:88rpx; position: fixed; bottom:00rpx;line-height: 0rpx;"  v-show="Number_commodities>0">
		 <view style="pl30"><i class='iconfont' style="font-size:55rpx;">&#xe634;</i></view>
		<view class="border_b fontcolob lh40" style="bottom:50rpx; background: red; height:38rpx;width:38rpx; position: absolute;left:40rpx; text-align: center;font-size:20rpx;">{{Number_commodities}}</view>
		 <view class="flex">
			<view style="padding-top:15rpx; margin-right: 30rpx;box-sizing: border-box;"><text >合计:</text><text class="fontcolorr">{{good_commodity}}</text></view>
			 <button class="fontcolob" style="background: #09BB07; border-radius:15rpx 0rpx 0rpx 15rpx; height:80rpx;" @click="go_goods()">去购物车</button>
		 </view>
		</view>
		
		
		</view>
</template>

<script>
	import api from '../../api/api.js'
	import { goodLists } from '../../api/conf.js'//商品列表
	import { shopPlus } from '../../api/conf.js'//商品增加
	import { shopReduce } from '../../api/conf.js'//商品减少
	import { shopAdd } from '../../api/conf.js'//加入购物车
	import seach from './search.vue'
	 var page=1;
	export default{
		components:{
			"searh-s":seach
		},
		data(){
			return{
				loadtext:'加载中.....',
				tabIndex:0,
				num:1,
				 usid:0,//用户名
				leader_id:0,//团长id
				tabBars:[],//分类名称
				commoditydata:[],//商品数据
				swithtop:false,/* 控制点击返回顶部按钮的显示 */
				loadingType: 0,
				product_stock:'',//商品库存
				limits_shopping:""//商品活动限购
			}
		},//下拉刷新数据

		onLoad(option) {
			this.tabIndex=option.name;//接受分类页的数据商品名称并动态更改分类加载的数据
			api.get(goodLists, {
			 sort_id:0/* 要加载分类的id */
			}).then(res=>{
			this.tabBars=res.category_list;
			this.commoditydata=res.good_list;
			}).catch(err => {
			})
		},
		methods:{
			tabswper(id,v){
				this.tabIndex=v;
				api.get(goodLists, {
					sort_id:id
				}).then(res=>{
					console.log(res)
				}).catch(err => {
				})
			},
	/* 跳转至购物车 */
			go_goods(){
				uni.switchTab({
				url: '/pages/tabbar/cart/cart'
				});
			},//到商品详情页
			to_detali(id){
				uni.navigateTo({
				    url: "../Commodity_details/commodity_details?Seckill=flase&goods=3&id="+id
				});
			},
			goods_add(item,index){//+添加到购物车
			var _THis=this;
				if(_THis.commoditydata[index].good_cart_num>_THis.commoditydata[index].product_stock && _THis.commoditydata[index].limits_shopping){
					uni.showToast({
					    title: '限购或商品不足',
					    duration: 2000
					});
					return
				}
				const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
				var usid=uid.usid;
				var leader_id=uid.leader_id;
									api.post(shopPlus, {
									  leader_id:leader_id,
									  user_id:usid,
									  shop_id:item.id
									}).then(res=>{
										console.log(res)
									}).catch(err => {
									})
					_THis.commoditydata[index].good_cart_num++;//增加商品
			},
			goods_red(item,index){
				var _THis=this;
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var usid=uid.usid;
			 var leader_id=uid.leader_id;
			api.post(shopReduce, {
			  leader_id:leader_id,
			  user_id:usid,
			  shop_id:item.id
			}).then(res=>{
				console.log(res)
			}).catch(err => {
			})
			_THis.commoditydata[index].good_cart_num--;
					},
			/* 	返回顶部 */
				top(){
					uni.pageScrollTo({
					    scrollTop: 0,
					    duration:500
					})
					}
		},
	/* 	监听滚动图高度 */
		onPageScroll: function(Object) {
		 Object.scrollTop>=50? this.swithtop=true:this.swithtop=false;
		},
		computed:{
			good_commodity(){//计算商品价格
				let pack=0;
				let Total=this.commoditydata;
				Total.forEach((item)=>{
					pack+=item.product_price*item.good_cart_num;
				})
				return pack;
			},
			Number_commodities(){//计算商品的个数
				let pack=0;
				let Total=this.commoditydata;
				Total.forEach((item)=>{
					pack+=item.good_cart_num;
				})
				return pack;
			}
			
		}
	}
</script>
<style>
	.uni-numbox{
		   width:150rpx;
	}
	.uni-numbox__plus,
	.uni-numbox__minus{
		height: 38rpx;
		line-height:35rpx;
		font-size:36rpx;
		font-weight: bold;
		text-align: center;
		width: 38rpx;
		border-radius: 100%;
		color: #FFFFFF;
	}
	.uni-numbox__plus{
		margin-left: 5rpx;
		font-size:30rpx;
		background:#3CC075;
	}
	.uni-numbox__minus{
		font-size:30rpx;
		transition: 6s all;
		background: #C5C5C5;
	}
	.uni-numbox__value {
		color: #666666;
		position: relative;
		background-color: #fff;
		width:45upx;
		text-align: center;
		align-items: center;
	}

	.uni-tab-bar {
		display: flex;
		flex: 1;
		flex-direction: column;
		overflow: hidden;
		height: 100%;
	}
	.uni-swiper-tab {
		width: 100%;
		white-space: nowrap;
		line-height: 100upx;
		height: 100upx;
		border-bottom: 1px solid #c8c7cc;
	}
	.swiper-tab-list {
		font-size: 30upx;
		width: 150upx;
		display: inline-block;
		text-align: center;
		color: #555;
	}
	.uni-uploader__input-box:active {
		border-color: #999999;
	}
	
	.uni-uploader__input-box:active:before,
	.uni-uploader__input-box:active:after {
		background-color: #999999;
	}
	.active .Line{
		margin-top: 15rpx;
		margin-left: 40rpx;
		height: 5rpx;
		width: 70rpx;
		background: #3CC075;
	}
	.sele{
		background: url("http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-%20disabled.png");
	}
	.seleav{
		background: url("http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-selected.png");
	}
	page{
		background:rgba(244,244,244,1);
	}
   .totop{
   	width: 60rpx;height: 60rpx;float: right;position:fixed;top: 900rpx;right: 5rpx;z-index: 9999;opacity:0.1;
   }
</style>
