<template>
	<view class="searche">
		<view class="container " @click="search()">
		    <form action="" class="parent">
				<i class="icon-user"></i>
		        <input type="text" class="search" placeholder="请输入你的商品">
		    </form>
		</view>
	</view>
</template>

<script>
	export default{
		methods:{
			//搜索
			search(){
				uni.navigateTo({
				    url: "../search/search"
				});
			},
		}
	}
</script>

<style>
	.container {
		    height: 60rpx;
		    width: 680rpx;
	margin-left: 16rpx; 
		}
		.container input{
			padding: 10rpx 0;
			padding-left: 70rpx;
		}
		.parent {
		    position: relative;
		}
	.search {
	    width: 648rpx;
	    height: 46rpx;
	    border-radius: 18rpx;
	    outline: none;
	    border: 1rpx solid #ccc;
	    padding-left: 20rpx;
	    position: absolute;
		background: #FFFFFF;
	}
	.icon-user{
	position: absolute;
	top: 9rpx;
	left:6rpx;
	z-index:5;
	background-image: url("http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/classification/search@2x.png");
	background-size: 20%;
	background-repeat: no-repeat; 
	background-position: 0rpx 0rpx; 
	width: 265rpx; 
	height: 50rpx;
	}
</style>
