<template>
	<view id="search" >
		<view class="head-location-r flex_c_m" style="background:rgba(60,192,117,1);height: 88rpx;">
			<i class="iconfont">&#xe717;</i>
			<input class="search_input sear" placeholder="请输入商品名称" confirm-type="search" v-model="searrch" />
			<text class="f26" style="color: #FFFFFF;font-size: 30rpx;padding-left:30rpx;" @click="search()">搜索</text>
		</view>
	<view v-show="switchdata"><!-- 搜索的数据(搜索记录) -->
		<view  style="margin:20rpx;">搜索记录</view>
		<view class="flex  tc flex_wrap">
	<block  v-for="(item,index) in goodHistory" :key='index' >
		<view class="border_rad b_color ml10 mr20" style="width:120rpx;" @click="addLabel(item)">{{item}}</view>
	</block>
		</view>
		<view class="tc fontcolorhh History" @click="data()">清空历史记录</view>
		<image src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/emptystate/Empty%20state-img-2.png" style="margin-left:60rpx;"></image>
		<view class="b flex_line_c_m mt30 fontcoll">暂无数据</view>
	</view>
	<!-- 获取到的页面搜索数据展示 -->
	<view v-for="(item1,index1) in commoditydata" :key="index1">
		<view class="flex mt15 b_color b_radisu box-size pl5" style="justify-content:space-between;box-shadow:0px 6px 4px 0px rgba(76,175,56,0.06);">
		<view style="flex"><image :src="item1.good_img_url" style="width: 198rpx;height: 198rpx;border-radius:10rpx;"></image></view>
			<view class="flex flex_line_c_m f28 box-size" style="padding-right: 100rpx;"  @click.prevent="to_detali(item1.good_id)">
				<text >{{item1.good_name}}</text>
				<text class="felx" style="flex-direction: row;">
				<text style="color:#F25576;">￥{{item1.good_price}}<text class="fonts pl20 fontcolorhh">{{item1.good_cost_price}}</text></text>
				</text>
				<text>累计限量{{item1.good_sales}}袋</text>
			</view>
				<view style="align-self:flex-end">
					<view class="uni-numbox flex_lr_ms pb30 pr30 box-size" style="display: flex; margin-left:45rpx;">
						<view class="uni-numbox__minus box-size" @click.prevent="goods_red(item1)"  v-show="item1.good_cart_num>0">-</view>
						<input class="uni-numbox__value pl10 box-size" type="number" :value="item1.good_cart_num" v-show="item1.good_cart_num>0" :disabled="true">
						<view class="uni-numbox__plus" @click.prevent="goods_add(item1)">+</view>
					</view>
				</view>
				<view class="flex_tbr bgb"  style="width:749rpx;height:88rpx; position: fixed; bottom:00rpx;line-height: 0rpx;" v-show="Number_commodities>0">
				 <view style=""><i class='iconfont' style="font-size:55rpx;top:5rpx;left:6rpx;">&#xe634;</i></view>
				<view class="border_b fontcolob lh40" style=" background: red; height:38rpx;width:38rpx; position: absolute;left:40rpx; text-align: center;font-size:20rpx;">{{Number_commodities}}</view>
				 <view class="flex">
					 <view style="padding-top:15rpx; margin-right: 30rpx;box-sizing: border-box;"><text >合计:</text><text class="fontcolorr">{{good_commodity}}</text></view>
					 <button class="fontcolob" style="background: #09BB07; border-radius:15rpx 0rpx 0rpx 15rpx; height:80rpx;" @click="go_goods()">去购物车</button>
				 </view>
				</view>
		</view>
	</view>
	</view>
</template>

<script>
	import api from '../../api/api.js'
	import { search } from '../../api/conf.js'//搜索
	import { pussearch } from '../../api/conf.js'
	import { shopPlus } from '../../api/conf.js'//商品增加
	import { shopReduce } from '../../api/conf.js'//商品减少接口
	export default{
		data(){
			return {
			tabIndex:0,
			num:1,
			tabBars:[],
			commoditydata:{},
			goods_car:[],
			searrch:"",//输入框绑定的数据
			goodHistory:[],//读取缓存的搜索
			searrchs:[],//搜索保存的内容
			switchdata:true,//商品返回的数据显示
			}
		},
		onLoad() {//加载历史记录标签
		    var THis=this;
			api.get(search, {
			 goodname:"",//需要搜索的商品
		     goodHistory:"",//是否清楚历史
			}).then(res=>{
			THis.goodHistory=res.goodHistory;
			}).catch(err => {
			}) 
		},
		onShow() {
		//读取用户名和团长
		var _THis=this;
		uni.getStorage({
				key:"settion_key",
				success:function (res) {
				_THis.usid=res.data.usid;
				_THis.leader_id=res.data.leader_id;
					console.log(res)
				}
			})	
			},
		methods:{
			addLabel(e){//点击相应标签页
				 var THis=this;
	         api.get(search, {
				goodname:e,
				goodHistory:"nodelete",//是否清楚历史
			}).then(res=>{
			var data1=res.goodsList;
			THis.commoditydata = data1;
			THis.switchdata=false;
			//	console.log("已经搜索")
			}).catch(err => {
			}) 
			THis.switchdata=false;
			},
			data(){
				 var THis=this;
				//删除历史记录
				api.get(search, {
					goodname:"",
					goodHistory:"delete",
				}).then(res=>{
				THis.goodHistory=res.goodHistory;
			//	console.log("历史数据删除成功")
				}).catch(err => {
				}) 
				
			},
			//点击搜索
			search(){
				 var THis=this;
			api.get(search, {
				goodname:this.searrch,
				goodHistory:"nodelete",//是否清除历史
			}).then(res=>{
			//	console.log("为啥不加载数据");
			//	console.log(res)
			var data1=res.goodsList;
			THis.commoditydata = data1;
				console.log("已经搜索")
			}).catch(err => {
			}) 
			this.switchdata=false;
			this.searrch=[];
			},//详情页
			to_detali(id){
				uni.navigateTo({
				    url: "../Commodity_details/commodity_details?Seckill=flase&goods=3&id="+id
				});
			},
			/* 跳转至购物车 */
					go_goods(){
						uni.switchTab({
						url: '/pages/tabbar/cart/cart'
						});
					},
					/* 加的事件,接受每个点击的数据 */
					goods_add(item){
						var _THis=this;
						 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
						 var usid=uid.usid;
						 var leader_id=uid.leader_id;
						api.post(shopPlus, {
						  leader_id:leader_id,
						  user_id:usid,
						  shop_id:item.good_id
						}).then(res=>{
						}).catch(err => {
						})
						let good_info ={};//
						let good_id = item.good_id;
						let goods_car = this.goods_car;
						let car_ad=0;
						good_info.good_price=item.good_price;
						good_info.good_cart_num=1;
						good_info.good_id=item.good_id;
						if(item.good_cart_num+1>item.good_stock){
							uni.showToast({
							    title: '您好目前库存不足',
								icon:'none',
							    duration: 3000
							});
						}else{
							if(goods_car.length > 0){
								for(var i=0;i<goods_car.length;i++){
									if(goods_car[i].good_id == good_id){
										this.goods_car[i].good_cart_num++;
										car_ad=1;
										item.good_cart_num++;
									}				
								}
								if(car_ad == 0){
										goods_car.push(good_info);
										item.good_cart_num=1;
								}
							}else{
								goods_car.push(good_info);
								item.good_cart_num=1;
							}
						}
					},
				/* 	点击减的事件 */
					goods_red(item){
						var _THis=this;
					 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
					 var usid=uid.usid;
					 var leader_id=uid.leader_id;
						api.post(shopReduce, {
						  leader_id:leader_id,
						  user_id:usid,
						  shop_id:item.good_id
						}).then(res=>{
							console.log(res)
						}).catch(err => {
						})
						let good_id = item.good_id;
						let goods_car = this.goods_car;
						let car_index=0;
						for(var i=0;i<goods_car.length;i++){
							if(goods_car[i].good_id == good_id){
								car_index=i;
							}				
						}
						if(goods_car[car_index].good_cart_num>1){
							goods_car[car_index].good_cart_num--;
						}else{
							goods_car.splice(car_index,1);
							 
						}
						item.good_cart_num--;
					}
					
		},
		computed:{
			good_commodity(){//计算商品价格
				let pack=0;
				let Total=this.goods_car;
				Total.forEach((item)=>{
					pack+=item.good_price*item.good_cart_num;
				})
				return pack;
			},
			Number_commodities(){//计算商品的个数
				let pack=0;
				let Total=this.goods_car;
				Total.forEach((item)=>{
					pack+=item.good_cart_num;
				})
				return pack;
			}
			
		},
	}
</script>

<style>
	#search{
		width: 100%;
	}
	.iconfont{
		position: absolute;
		left: 40rpx;
	}
	page{
		background:#f7f7f7;
	}
	.uni-numbox{
		   width:150rpx;
	}
	.uni-numbox__plus,
	.uni-numbox__minus{
		height: 38rpx;
		line-height:35rpx;
		font-size:36rpx;
		font-weight: bold;
		text-align: center;
		width: 38rpx;
		border-radius: 100%;
		color: #FFFFFF;
	}
	.History{
		border: solid 1rpx #555555;
		border-radius: 15rpx;
		width:290rpx; 
		margin-top:150rpx;
		margin-left:220rpx;
	}
	.uni-numbox__plus{
		margin-left: 5rpx;
		font-size:30rpx;
		background:#3CC075;
	}
	.uni-numbox__minus{
		font-size:30rpx;
		transition: 6s all;
		background: #C5C5C5;
	}
	.sear{
		width: 556rpx;
		border-radius: 12rpx;
		background: #FFFFFF;
		padding-left: 60rpx;
	}
	.uni-numbox__value {
		color: #666666;
		position: relative;
		background-color: #fff;
		width:45upx;
		text-align: center;
		align-items: center;
	}
	
	.uni-tab-bar {
		display: flex;
		flex: 1;
		flex-direction: column;
		overflow: hidden;
		height: 100%;
	}
	.uni-swiper-tab {
		width: 100%;
		white-space: nowrap;
		line-height: 100upx;
		height: 100upx;
		border-bottom: 1px solid #c8c7cc;
	}
	.swiper-tab-list {
		font-size: 30upx;
		width: 150upx;
		display: inline-block;
		text-align: center;
		color: #555;
	}
	.uni-uploader__input-box:active {
		border-color: #999999;
	}
	
	.uni-uploader__input-box:active:before,
	.uni-uploader__input-box:active:after {
		background-color: #999999;
	}
	.active .Line{
		margin-top: 15rpx;
		margin-left: 40rpx;
		height: 5rpx;
		width: 70rpx;
		background: #3CC075;
	}
	.sele{
		background: url("http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-%20disabled.png");
	}
	.seleav{
		background: url("http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-selected.png");
	}
</style>
