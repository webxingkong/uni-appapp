<template>
    <view class="uni-container">
		<!-- 头像与地址 -->
        <view class="payment-details">
			<view class="phoneto"  @click="choosecommander">
				<image class="phoneto_img" :src="regiment_img"></image>
			</view>
			<view class="shop">
				<view class="shopname" style="font-size: 30rpx;">{{regiment_name}}</view>
				<view class="shopadress">{{regiment_address}}</view>
			</view>
			<view class="iconleft">
				<image class="adress-img" :src="adress_img"></image>
			</view>
		</view>
		<!-- 送货上门 -->
		<view class="shiping" v-if="isActive" @click="to_add()">
			<text class="shiping-text">选择收货地址:<text class="fontcolorhh p5">{{add_position}}</text></text>
			<i class="iconfont" style="padding-right:19rpx;">&#xe61f;</i>
		</view>
		<!-- 配送方式 -->
		<view class="shiping">
			<text class="shiping-text">配送方式:</text>
			<view style="border: 1rpx solid #09BB07;border-radius:20rpx; margin: 0rpx 30rpx 0rpx 30rpx; line-height:39rpx;">
				<text v-bind:class="[isActive==false ? 'errorClass' : '' ]" @click="mention()" style="margin-right:17rpx;">自提</text>
				<text v-bind:class="[isActive==false ? '' : 'errorClass' ]" @click="Delivery()" style="">送货上门</text>
			</view>
		</view>
		<!-- 订单详情 -->
		<view class="order-details">
			<view class="goods-arrive">
				<text style="font-size: 28rpx;color: #333333;">预计到货日期</text>
				<text style="font-size: 28rpx;color: #333333;">{{order_delivery_time}}</text>
			</view>
			<view class="goods-list" v-for="(item,index) in cart_good_lists" :key="index">
				<view style="display: flex;justify-content:space-between">
					<view class="goods-left">
						<view class="goods-img">
							<image :src="item.good_img_url" style="width: 170rpx;height: 170rpx;"></image>
						</view>
						<view style="margin-left: 32rpx;">
							<text class="goods-title">{{item.good_name}}</text>
							<view class="goods-company">单位&nbsp;&nbsp;&nbsp;袋</view>
							<view class="goods-price">￥{{item.good_price}}</view>
						</view>
					</view>
					<view class="goods-right">
						<text class="goods-num" style="font-size: 26rpx;">数量:&nbsp;&nbsp;&nbsp;{{item.good_order_num}}袋</text>
				<view style="display: flex;margin: 15rpx 0rpx 0rpx;" v-if="Buttons">
				<view class="reduce" @click="reduce(index,item)" v-if="item.good_order_num>1"></view><!-- 减的控件 -->
				<text class="goods-num" style="font-size: 26rpx;margin:0rpx 6rpx;color: #000000;box-sizing: border-box;" v-if="item.good_order_num>1">{{item.good_order_num}}</text>
				<view class="add" @click="add(index,item)"></view><!-- 加的控件 -->
				</view>
					</view>
				</view>
			</view>
			<!-- <view class="goods-buttom">
				
			</view> -->		
			
			<view class="goods-arrive">
				<text style="font-size: 24rpx;color: #333333;">共{{order_total_type_num}}种商品</text>
				<text style="font-size: 24rpx;color: #333333;">合计:&nbsp;&nbsp;￥{{order_total_prices}}</text>
			</view>
			<view class="goods-arrive" style="border: none !important;">
				<text style="font-size: 24rpx;color: #333333;">备注</text>
			</view>
		<!-- 	添加备注信息 -->
			<view class="goods_addmsg">
				<button class="addgoods" type="primary" @click="openPopup">添加订单备注信息</button>
				<uniPopup ref="popup" type="center">
					<view style="height:450rpx; width:650rpx;padding: 15rpx;overflow:hidden" class="flex_tb_c">
						<view>备注信息</view>
						<view style="background: #C9C7C7;border-radius: 15rpx;width:95%;text-align: left;"><textarea rows="110" cols="90"  placeholder="请输入您的备注" v-model="valuedata" ></textarea></view>
						<view style="margin-top:10rpx;"><text @click="closePopup">取消</text><text @click="Determine()" style="padding:0rpx 0rpx 55rpx 450rpx;">确定</text></view>
					</view>
				</uniPopup>
			</view>
		</view>
		<!-- 优惠券 -->
		<view class="coupon shiping" @click="alertDiscount()">
			<text class="shiping-text">优惠券</text>
			<view class="coupon-right">
				<text>查看优惠卷</text>
				<image class="coupon_right_img" :src="coupon_right_img"></image>
			</view>
		</view>
	<!-- 	底层优惠卷弹窗 -->
		<uniPopup ref="laretpopup" type="bottom">
			<view style="height:100rpx;padding: 15rpx;" class="flex_lr">
				<view style="padding-left:49%;">优惠卷</view>
               <view style="padding-left:190rpx;"><i class="iconfont" @click.stop="rlaetsclose()">&#xe608;</i></view>
			</view>
			   <view style="height:10%;">
				   
				   <view style="display: flex; justify-content:space-between;margin-top: 35rpx;" class="f32">
			   <view class="pl30">使用优惠卷</view>
				<view class="pr30"><text class="price">-{{Calculation_discount}}</text><view @click="Use_btndatas()" :class="[btndata==true ? 'seleav':'sele']" class="select_img"></view></view>
				</view>
				
				<view style="display: flex; justify-content:space-between ;margin-top: 35rpx; color: #8F8F94; overflow: scroll;" class="f32" v-for="(item,index) in coupan_lists" :key="index">
					   <view class="pl30">{{item.coupon_title}}</view>
						<view class="pr30"><text>{{item.coupon_ticket}}</text></view>
						</view>
						
					<view style="display: flex; justify-content:space-between ;margin-top: 35rpx;" class="f32">
				   <view class="pl30">不使用</view>
					<view class="pr30"><view  @click="btndatas()" :class="[btndata==true ? 'sele':'seleav']" class="select_img"></view></view>
					</view>
			   </view>
           <view style="height:65rpx;width:60%;background:#3ABA71;border-radius:15rpx; margin:0rpx 0rpx 20rpx 120rpx;text-align: center;color: #FFFFFF;line-height: 60rpx;" @click="complete(btndata)">完成</view>
		</uniPopup>
		<view class="buttom-pay flex_fcs ">
			<text class="shiping-text">共{{order_total_type_num}}件商品:</text>
			<button class="paybtn" @click="topay()"> 付款金额￥{{order_total_price}}</button>
		</view>
		
	</view>
</template>
<script>
	import api from '../../api/api.js'
	import { placeOrder } from '../../api/conf.js'
	import { ckorder } from '../../api/conf.js'
	import { userAddress } from '../../api/conf.js'
    import uniPopup from "../../components/uni-popup/uni-popup.vue"//弹层组件
    export default {
        components:{
			uniPopup
		},
        data() {
          return{
			  isActive:true,//配送方式切换
			  transport_type:1,//配送方式
			  receive_address_id:'',//用户收货地址id
			  add_position:'',//目前的文字地址
			  Buttons:"",/* 用于显示加减按钮控件 */
			  into:'',//存储那个页面加载进来的
			  "valuedata":"",//用户备注的信息
			  "regiment_name":"",
			  "regiment_address":"",
			  "regiment_img":"",
			  "order_delivery_time":"",
			  "cart_good_lists":[],//商品信息
			   order_total_price:"",//这是应付价格
			   Price:"",
			   Seckillgoods:'',//商品秒杀值
			   order_total_prices:"",//这是总价
			  "order_total_good_num":"",
			  "adress_img":"../../static/commodity_icon/address.png",
			  "coupon_right_img":"../../static/right.png",
			  "navigate_to_url":"",
			  "title": 'textarea',
			  "focus": false,
			  "btndata":true, /*, 是否使用优惠卷 */
			  coupan_lists:[],//优惠卷
			  "Extraction_method":"",//提取方式
			  "packss":0
			  
		  }
        },
        onLoad(option) {
			var Thta=this;
			Thta.Buttons=option.add;//从详情页加入付款页面的都可以在增加商品
			Thta.into=option.into;//该页面时是详情页进入还是购物车结算进入
			uni.getStorage({
			    key: 'buy_key',
			    success: function (res) {
					Thta.cart_good_lists=res.data;	
					console.log(res)
					var data=Thta.cart_good_lists;
					let pack = 0;
					data.forEach((food) => {	
						return pack += food.good_price*food.good_order_num;
					})
					Thta.order_total_prices=pack;
					Thta.order_total_price=pack;
					Thta.Price=pack;
			    }
			});
/* 数据请求 */
				const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
				const sign_key=uni.getStorageSync('sig_key');//读取最新传来的商品秒杀值和数量
				var usid=uid.usid;
				var leader_id=uid.leader_id;
					var sign=sign_key.sign;//秒杀值
					var sum=sign_key.sum;//下单数量
					var shop_id=sign_key.shop_id;//商品id
			api.get(placeOrder, {
			    leader_id:leader_id,
				 user_id:usid,
				 shop_id:shop_id,
				 sign:sign,
				 sum:sum
			}).then(res => {

                    this.regiment_address=res.regiment_info.regiment_address;//团长地址
					this.regiment_name=res.regiment_info.regiment_name;//团长名
					this.regiment_img=res.regiment_info.regiment_img;//团长图片
					this.order_delivery_time=res.regiment_info.Estimate;//送达时间
					this.order_total_good_num=res.order_total_good_num;
					this.navigate_to_url=res.navigate_to_url;
					this.coupan_lists=res.coupan_lists.coupon_valid_lists;//优惠卷
					console.log(this.coupan_lists);
					this.Extraction_method=res.regiment_info.Distribution_mode;
			}).catch(err => {
			    uni.showToast({
			        title: "数据异常",
			        icon: 'none'  
			    })
			})
			const uids=uni.getStorageSync('settionid_key');//读取用户id和团长id
			var usid=uids.usid;
			api.get(userAddress, {
              user_id:usid,
			}).then(res=>{
				Thta.data.receive_address_id=res.addressList[0].id;//获取到最新默认的地址
				Thta.data.add_position=res.addressList[0].provincial_address+res.addressList[0].address;
			}).catch(err => {
			})
        },
		onShow() {
			var Thta =this;
			const value = uni.getStorageSync('address_key');//读取地址存储的信息
			var data_id=value.id;
			var data_position=value.provincial_address+value.provincial_address;
			if(value.id!=""){//第一次进入页面的时候读取服务端第一条地址，当用户选择地址的时候存储该地址信息，页面判断地址是否为空，有数据的则表示用户选择
							 Thta.receive_address_id=data_id;//赋值最新的地址id
							 Thta.add_position=data_position;//地址信息
			}
		},
        methods: {
			reduce(e){
				var _THis=this;
				if(_THis.cart_good_lists[e].good_order_num<=1){
					_THis.cart_good_lists[e].good_order_num=1;
				}
				else{
					_THis.cart_good_lists[e].good_order_num--;
				}
				var data=_THis.cart_good_lists;
				let pack = 0;
				data.forEach((food) => {	
					return pack += food.good_price*food.good_order_num;
				})
				_THis.order_total_prices=pack;
				_THis.order_total_price=pack;
				_THis.Price=pack;
			},
			add(e){
				const _THis=this;
				var data=_THis.cart_good_lists;
				let pack = 0;
				data.forEach((food) => {	
					return pack += food.good_price*food.good_order_num;
				})
				_THis.order_total_prices=pack;
				_THis.order_total_price=pack;
				_THis.Price=pack;
				_THis.shows++;
				uni.getStorage({
				    key: 'buy_key',
				    success: function (res) {
				var good_stock=res.data[0].good_stock
				if(	_THis.cart_good_lists[e].good_order_num>=good_stock){//不能大于库存
				uni.showToast({
				    title: '库存不足',
				    duration: 3000
				});
					return
				}
					_THis.cart_good_lists[e].good_order_num++;
				    }
				});
			},
			mention(){//自提函数
				var _THis=this;
					_THis.isActive=!true;//样式切换
				_THis.transport_type=0;//自提提交的数据为0
				_THis.receive_address_id="";
			},
			Delivery(){//送货函数
				var _THis=this;
				_THis.isActive=!false;//样式切换
				_THis.transport_type=1;//送货提交的数据为1
				
			},
			to_add(){
				var _THis=this;
				uni.navigateTo({//跳转到地址选择地址
				    url: "/pages/tabbar/my/address/address?palceorder=1"//给地址进行传参表示为付款选择的地址
				});
			},
			bindTextAreaBlur: function (e) {
			},
			/* 确定备注 */
			Determine(){
				    this.$refs.popup.close();
			},
			/* 备注弹窗事件 */
        openPopup(){
            this.$refs.popup.open();
        },
        closePopup(){
			this.valuedata="";
            this.$refs.popup.close();
        },
	/* 	优惠卷弹窗事件 */
		alertDiscount(){
			  this.$refs.laretpopup.open();
		},
		rlaetsclose(){
			 this.$refs.laretpopup.close();
		},
		/* 跳转至付款页面 */
            topay(){
				var _THis=this;
				/* 发送数据 */
					var num=0;//下单数量
					if(_THis.into=="details"){//判断是否是详情页进入(购物页进入为0)
						num=_THis.cart_good_lists[0].good_order_num;
					}
					const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
					const sign_key=uni.getStorageSync('sig_key');//读取最新传来的商品秒杀值和数量
					var sign=sign_key.sign;//秒杀值
					var shop_id=sign_key.shop_id;//商品id
					var usid=uid.usid;
					var leader_id=uid.leader_id;
				api.post(ckorder,{
					company_id:1,//城市id
					leader_id:leader_id,//团长id
					user_id:usid,//用户id
					shop_id:shop_id,//商品id
					order_remarks:_THis.valuedata,//备注信息
					transport_type:_THis.transport_type,//配送方式
					sign:sign,//秒杀商品值
					sum:num,//商品数量
					receive_address_id:_THis.receive_address_id//用户收货id
				}).then((res)=>{
						uni.setStorageSync('Order_key',res.order_id);//成功以后返回订单id
				})
				uni.navigateTo({
				    url: "/pages/pay/pay"
				});
			},
/* 			choosecommander(){
				uni.navigateTo({
				    url: '../pay/choosecommander'
				});
			} */
			complete(e){//优惠卷确定付款金额
			var data=this.Calculation_discount;//优惠卷金额
			var Price=this.Price;//目前商品金额
			if(e==true){//使用
				this.order_total_price=Price-data>0 ? this.order_total_price=Price-data : this.order_total_price=0;//目前商品金额减去优惠卷金额，如果应付金额小于0 那么支付金额就等于0
			}
			else{
				this.order_total_price=Price;
			}
			this.$refs.laretpopup.close();
			},
			Use_btndatas(){
			this.btndata=true;//如果选中了使用则去除不使用状态
			},
			btndatas(){
			this.btndata=false;
				},
        },
		//过滤优惠卷是否满足条件
		computed:{
			Calculation_discount(){
			var pack=this.packss;
			var  discount=this.coupan_lists;//获取所有的优惠卷
			discount.forEach((item)=>{
					pack+=+item.coupon_ticket;
			})
				return pack;
			},
			order_total_type_num(){//计算商品的个数
				var pack=0;
				return pack=this.cart_good_lists.length
			},
		}
    };
</script>

<style>
	.uni-container{
		width: 100%;
		height: auto;
		
	}
	.uni-textarea{
		width:100%;
		background:#FFF;
	}
	.uni-textarea textarea{
		width:96%;
		padding:18upx 2%;
		line-height:1.6;
		font-size:28upx;
		height:150upx;
	}
	.phoneto_img{
		width: 137rpx;height: 137rpx;margin-top: 29rpx;margin-left: 18rpx;
	}
    .payment-details{
		width: 100%;
		height: 170rpx;
		background: #FFFFFF;
		display: flex;
	}
	/* 配送方式css */
	.errorClass{
		color:#FFFFFF;
		background: #09BB07;
		border-radius:10rpx;
	}
	.shop{
		margin-top: 29rpx;
		margin-left: 20rpx;
	}
	.shopadress{
		flex-wrap:wrap;
		width: 392rpx;height: 61rpx;font-size: 28rpx;color: #666666;
	}
	/* 配送方式 */
	.shiping{
		height: 80rpx;
		width: 100%;
		background: #FFFFFF;
		display: flex;
		justify-content:space-between;
		align-items:center;
		margin-top:15rpx;
		padding: 5rpx 0rpx;
	}
	.shiping-text{
		font-size: 28rpx;
		margin-left: 32rpx;
		font-weight: 400;
	}
	.shiping-type{
		width:100rpx;
		height:auto;
		background:linear-gradient(0deg,rgba(60,192,117,1) 0%,rgba(55,176,107,1) 100%);
		border-radius:0px 12px 0px 12px;
		margin-right: 32rpx;
		text-align: center;
		color: #FFFFFF;
		font-size: 22rpx;
	}
	.iconleft{
		margin-top: 75rpx;margin-left: 100rpx;
	}
	.adress-img{
		height: 44rpx;width: 40rpx;
	}
	/* 订单详情 */
	.goods-list{
		margin-top: 22rpx;margin-left:10rpx;display: flex;justify-content:space-between
	}
	.goods-left{
		display: flex;justify-content:flex-start;align-items:flex-start
	}
	.order-details{
		margin-top: 18rpx;
		width: 100%;
		/* height: 690rpx;
		overflow: auto; */
		height: auto;
		background: #FFFFFF;
	}
	.goods-title{
		color: #333333;font-size: 28rpx;font-weight: 400;
	}
	.goods-company{
		color: #999999; font-size: 24rpx;
	}
	.goods-price{
		margin-top: 48rpx;font-size: 26rpx;color: #333333;
	}
	.goods-right{
		margin-left:20rpx;
		display: flex;
		flex-direction: column;
		align-items:flex-end;
		margin-left:120rpx;
		justify-content: center;
		box-sizing: border-box;
		color:#808080;
	}
	.goods-arrive{
		height: 70rpx;
		display: flex;
		justify-content:space-between;
		align-items:center;
		margin-left: 32rpx;
		margin-right: 32rpx;
		font-weight: 400;
		border-bottom: #C9C7C7 2rpx solid;
	}
	.goods_addmsg{
		width: 686rpx;margin-left: 32rpx;margin-right: 32rpx;font-weight: 400;margin-bottom: 10rpx;height: 75rpx;
	}
	.coupon_right_img{
		width: 13rpx;height: 20rpx;margin-right: 32rpx;
	}
	/* 优惠券 */
	.coupon{
		display: flex;justify-content:space-between;align-items:center;margin-bottom:150rpx;/* 底部外边距给50rpx是因为付款金额覆盖住优惠卷造成优惠卷不能显示,所有往上移动一部分 */
	}
	.coupon-right text{
		color: #999999;font-weight: 400;font-size: 26rpx;margin-right: 76rpx;
	} 
	/* 付款按钮 */
	.buttom-pay{
		width: 100%;background: #FFFFFF;position: fixed;bottom:0rpx; height: 88rpx;z-index: 9999;
	}
	.paybtn{
		width:240rpx;height:100%;background:#3CC075;border-radius:12px 0px 0px 12px;color: #FFFFFF;font-size: 28rpx;font-weight: 400;margin-right: 0rpx;padding: 10rpx;
	}
	/* 添加商品按钮 */
	.addgoods{
		width:100%;height:60rpx;background:#F4F4F4 !important;border-radius:12rpx;font-size: 20rpx;color: #999999 !important;font-weight: 400;padding: 5rpx;
	}
@font-face {
  font-family: 'iconfont';  /* project id 1395133 */
  src: url('//at.alicdn.com/t/font_1395133_5dltquasdwo.eot');
  src: url('//at.alicdn.com/t/font_1395133_5dltquasdwo.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_1395133_5dltquasdwo.woff2') format('woff2'),
  url('//at.alicdn.com/t/font_1395133_5dltquasdwo.woff') format('woff'),
  url('//at.alicdn.com/t/font_1395133_5dltquasdwo.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_1395133_5dltquasdwo.svg#iconfont') format('svg');
}
.iconfont{
    font-family:"iconfont" !important;
    font-size:16px;font-style:normal;
    -webkit-font-smoothing: antialiased;
    -webkit-text-stroke-width: 0.2px;
    -moz-osx-font-smoothing: grayscale;}
	
	/* 选中未选中样式 */
	.sele{
		background: url("http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-%20disabled.png");
	}
	.seleav{
		background: url("http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-selected.png");
	}
	.goods-right .add{
		height:45rpx;
		width: 45rpx;
        background-position:center;
		background: url("~@../../static/add.png");
		background-size:100%;
		background-repeat: no-repeat;
		margin:5rpx;
		
	}
	.goods-right .reduce{
		height:45rpx;
		width: 45rpx;
		background-position:center;
		background: url("~@../../static/reduce.png");
		background-size:100%;
		background-repeat: no-repeat;
		margin:5rpx;
		
	}
	/* 选中图片样式 */
	.select_img{
		height: 42rpx;width: 42rpx; background-size: 100%;float:right;
	}
	/* 折扣文字样式 */
	.price{
		color: #FF0000; padding-right: 30rpx;
	}
</style>
