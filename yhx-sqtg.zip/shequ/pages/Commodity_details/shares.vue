<template>
	<view>
		<view class="flex_line_c_m box-size "  style="background: #3CC075; margin:30rpx;">
			<view class="box-size b-ra">
				<view class="mt20 lh0"><image class="" src="../../static/commodity_icon/img-2.png" style="width:624rpx;height:630rpx;border-radius:15rpx 15rpx 0rpx 0rpx ;"></image></view>
				<view class="f32 b_color b_color pl15">彼岸花500/克</view>
				<view class="b_color b_color p20 pl15 b-ra"><text class="fontcolorr">$9.9</text><text class="pl32 fonts">$9.70</text></view>
			</view>
			<view class="flex mt30 box-size" style="justify-content:flex-end;">
				<view class="ml30 pt20"><image src="../../static/0907165353.png" style="width: 97rpx; height: 97rpx;" class="border_b"></image></view>
				<view class="ml30 fontcolob pt20">
					<view>泡面旗舰店</view>
					<view>团长:李云龙</view>
				</view>
				<view style="margin: 0 90rpx;"><image src="../../static/QR_code.png" style="height: 180rpx;width: 180rpx;" class="border_b"></image></view>
			</view>
	    <view class="pb30 box-size" style="padding-right:300rpx;"><button style="font-size:25rpx;border-radius:35rpx; height:40rpx; line-height:40rpx;">长按识别小程序二维码</button></view>
		</view>
		
		<view @tap="Preservation()"><button class="b_radisu fontcolob" style="width:618rpx;height:98rpx; background:#3CC075;">保存到本地</button></view>
		
	</view>
</template>

<script>
	export default{
		data(){
			return{
				
			}
		},
		methods:{
			Preservation(){
			}
		}
	}
</script>

<style>
	
</style>
