<template>
	<view>
		<!--轮播图-->
		<view class="page-section-spacing">
			<swiper class="swiper" 
				indicator-dots="true" 
				autoplay="true" 
				interval="5000" 
				duration="1500"	>
				<swiper-item v-for="(item,index) in detailsdataL.swiper_list" :key="index">
					<image :src="item.img" mode="aspectFill"></image>
				</swiper-item>
			</swiper>
		<!--轮播图下的信息表--> 
					<view class="surface font-size pl32 box-size">
						<view>${{detailsdataL.good_data.good_price}}<text  class="siperimg">${{detailsdataL.good_data.good_cost_price}}</text></view>
						<view class="" style="position: absolute;z-index: 9;left:55%; top: 650rpx;">
							<image src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/goodinfo/img.png" style="width:750rpx;height:120rpx;"></image>
							<view style="position:absolute; color:#3CC075;top:0rpx;margin-left:35rpx;" class="flex_line_c_m" v-if="timeshow">
								<view>{{buy_time}}</view>
								<!-- <view class="">{{detailsdataL.good_data.good_deadline}}</view> -->
								<uniCountDown
								    :day="day" 
								    :hour="hour" 
								    :minute="minute" 
								    :second="secoud" :reset="reset"
									 @watchChild="timereach">
								</uniCountDown>
							</view>
						</view>
					</view>
				</view> 
		<!--分享区域-->
		
		<view class="bg-h pt5 box_border pl32"><text>{{detailsdataL.good_data.good_name}}</text></view>
		<view class="Sharing_column f14 lh22 box_border pl32 content">
			<view class="fontcolorh">
				<text>累计销售{{detailsdataL.good_data.good_sales}}袋</text>
				<text class="pl20">剩余{{detailsdataL.good_data.good_stock}}袋</text>
			</view>
			<image src="../../static/commodity_icon/share.png" @tap="shareEvn()"></image><!-- 点击分享事件区域 -->
		</view>
		<!--发货区域-->
		<view class="Delive_goods fontcolorh  f24 pl32 box-size">
			<text class="">发货时间</text>
			<text class="pr10">{{detailsdataL.good_data.good_delivery_time}}</text>
		</view>
		
		<!--用户信息-->
		<view>
		<view class="flex_m bgb box-size">
			<view class="p10"><image :src="detailsdataL.good_data.good_url" style="height: 110rpx; width: 110rpx;" mode="widthFix"></image></view>
			<view class="" style="">
				<view class="fontcolorq f32">{{detailsdataL.good_data.good_names}}</view>
				<view class="fontcolorhh  fontcolorhh">{{detailsdataL.good_data.good_address}}</view>
			</view>
			<view class="iconleft" style="padding-left: 170rpx;"> <i class="iconfont pl10 fontcolorh pr10" style="font-size: 40rpx;">&#xe7e0;</i></view>
		</view>
		</view>
		
		<!--商品描述-->
		<view class="describe b_color b_radisu" style=" margin: 16rpx 0rpx;">
		<text class="pl32">商品描述</text>
		<view style="border: 1px solid rgba(201, 199, 199, 1);"></view>
		<text>{{detailsdataL.good_data.good_desc}}</text>
		</view>
		<!--图片展示区-->
		<view v-for="(item,index) in good_details_img.good_details" :key="index" class="flex_line_c_m">
	    <image :src="item.img" style="width:95%; background-size: 100%;"></image>
		</view>
		<!--订单下单区域-->
		<view class="order box_border pb10" style="display: flex;justify-content: space-between;">
			<view class='flex box_border' style="align-items: center; padding: 5rpx 10rpx;">
				<view class="flex iconimg" style="flex-direction: column; align-items: center; margin: 0 12rpx;" @tap="toindex()">
					<image src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/goodinfo/home.png"></image>
					<text style="color: #666666; font-size: 20rpx;">首页</text>
				</view>
				<view class="flex box_border iconimg" style="flex-direction: column; align-items: center; margin: 0 25rpx;" @tap="toShopping()">
					<image src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/goodinfo/shopcart.png"></image>
						<text style="color: #666666; font-size: 20rpx;">购物车</text>
				</view>
			</view>
			<view style="display: flex;">
				<view><button @tap="add_Shopping()" class="addgood">加入购物车</button></view>
				<view style="margin-left:10rpx;" @click.prevent="purchase()"><button class="btnbuy">立即购买</button></view>
			</view>
		<!-- 	分享的底部弹窗 -->
		
			</view>
			
			
			<!-- 分享弹窗-->
					<view class="share-pro" >
						<view class="share-pro-mask" v-if="deliveryFlag"></view>
						<view class="share-pro-dialog" :class="deliveryFlag?'open':'close'" >
							<view class="close-btn" @tap="closeShareEvn">
								<span class="font_family">&#xe6e6;</span>
							</view>
							<view class="share-pro-title">分享</view>
							<view class="share-pro-body">
								<view class="share-item">
									<button open-type="share">
										<view class="font_family share-icon">&#xe6fa;</view>
										<view >分享给好友</view>
									</button>
								</view>
								<view class="share-item" @tap="createCanvasImageEvn">
									<view class="font_family share-icon">&#xe6f9;</view>
									<view >生成分享图片</view>
								</view>
							</view>
			
						</view>
					</view>
					<hchPoster ref="hchPoster" :canvasFlag.sync="canvasFlag" @cancel="canvasCancel" :posterObj.sync="posterData"/>
					<view :hidden="canvasFlag"><!-- 海报 要放外面放组件里面 会找不到 canvas-->
						<canvas class="canvas"  canvas-id="myCanvas" ></canvas><!-- 海报 -->
					</view>
			
			
		</view>
		</view>
</template>

<script>
import api from '../../api/api.js'
import { goodInfo } from '../../api/conf.js'
import { shopAdd } from '../../api/conf.js'
import uniCountDown from '../../components/uni-count-down/uni-countdown.vue'
import hchPoster from '../../components/poster/hch_poster.vue'

	export default {
		components: {
			hchPoster,
			uniCountDown
		},
		data() {
			return {
				"product_id":'',/* 商品id */
				Seckill:false,//布尔值判断是否是秒杀活动true表示是
				timeshow:true,//控制时间的显示，普通商品不显示
				"entry_mode":'99',/* 点击秒杀值为 88，点击首页商品 null */
				"buy_time":'',//抢购时间说明
				goodtime:false,//商品时间是否可以立即购买了
				"cart_good":[],//存储购物车的商品数据
				good_datas:[],//传递给支付页的数据
				deliveryFlag: false,
				canvasFlag: true,
				good_details_img:[],//商品描述的图片
				Seckillgoods:2,//商品秒杀值默认为2活动商品
				posterData:{},
				detailsdataL:{},
				Activity_date:"",
				sec:'0',
				day:0,//天
				hour:0,//小时
				secoud:0,//秒
				minute:0,
				reset: false,
			}
		},
		onLoad(option) {
			this.Seckillgoods=option.goods//子页传递过来的秒杀值
			this.product_id=option.id;
			console.log(option)
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var leader_id=uid.leader_id;
			//获取服务端数据
			api.get(goodInfo, {
				product_id:this.product_id,
				leader_id:leader_id,
				entry_mode:this.Seckillgoods,//秒杀标识
			}).then(res => {
				var data=res;
				var text=data.good_data;
				this.cart_good=res.good_data;
				this.detailsdataL = data;
				this.Activity_date=data.good_data.good_deadline;
				this.good_details_img=text;
				var good_stamp_start=res.good_data.good_stamp_start;//抢购开始时
				if(good_stamp_start==undefined||""){//是否是时间获得商品
					console.log("商品类型为4")
					this.Seckillgoods=3;
					this.timeshow=false;//普通商品不显示时间
					this.goodtime=true//普通商品可以立即购买
				}
				else{
				var good_stamp_end=res.good_data.good_stamp_end;//抢购结束时间
				var good_curren_ttime=res.good_data.good_curren_ttime;//服务器当前时间
				if(good_curren_ttime<=good_stamp_start)//判断是否是倒计时或者是抢购开始
				{
					this.buy_time="据活动开始还有";
					 var time =good_stamp_start - good_curren_ttime;
					 var days = Math.floor(time/86400);//计算小时数
					 var remain = time%86400;
					 var hours = Math.floor (remain/3600);
			//计算分钟数
					 var remain = remain%3600;
					 var mins =  Math.floor(remain/60);
			//计算秒数
					 var secs = remain%60;
					this.day=days;
					this.hour=hours;
					this.minute=mins;
					this.secoud=secs;
				}
				else{
					this.buy_time="据活动结束还有";
						 var time =good_stamp_end - good_curren_ttime;
						 var days = Math.floor(time/86400);//计算小时数
						 var remain = time%86400;
						 var hours = Math.floor (remain/3600);
				//计算分钟数
						 var remain = remain%3600;
						 var mins =  Math.floor(remain/60);
				//计算秒数
						 var secs = remain%60;
						this.day=days;
						this.hour=hours;
						this.minute=mins;
						this.secoud=secs;
				
				}
				//动态赋值
				this.reset=true;
				this.minute=parseInt(quesTime);
				}
				
			}).catch(err => {
			});
			console.log("请告诉我这是什么商品"+this.Seckillgoods)
		},
methods:{
	//跳转到首页
	toindex(){
		uni.switchTab({
		url: '/pages/tabbar/index/index'
		});
	},
	//跳转到购物车
	toShopping(){
		uni.switchTab({
		url: '/pages/tabbar/cart/cart'
		});
	},
	//加入购物车
	add_Shopping(){
		var _THis=this;
		if(this.Seckillgoods==1){//秒杀商品不能加入购物车
			//判断是否是秒杀商品（秒杀商品不能加入购物车）
		}else{
			console.log("能下单")
					 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
					 var usid=uid.usid;
					 var leader_id=uid.leader_id;
			//提交加入购物车数据
				api.post(shopAdd, {
					shop_id:_THis.product_id,//商品id
					leader_id:leader_id,
					shop_id:_THis.product_id
				}).then(res => {
					console.log("存储的数据发送成功")
				}).catch(err => {
					console.log("存储的数据发送失败")
				});
				uni.showToast({
					title:"成功加入购物车"
				})
		}
	},//活动时间结束触发事件
	timereach(){
		var _THis=this;
		 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
		 var leader_id=uid.leader_id;
		api.get(goodInfo, {
			product_id:_THis.product_id,
			leader_id:leader_id,
			entry_mode:_THis.entry_mode,//秒杀标识
		}).then(res => {
		var time_stamp_start=res.good_data.good_stamp_start;//抢购开始时间
		if(time_stamp_start==undefined||""){//是否是时间获得商品
		_THis.goodtime=true//如果没有时间表示为普通商品则可以直接立即购买
		}else{
			var time_curren_ttime=res.good_data.good_curren_ttime;//服务器当前时间
			if(time_curren_ttime=>time_stamp_start)//判断是否是倒计时或者是抢购开始
			{
				_THis.goodtime=true;
				console.log("活动开始了")
			}else{
				_THis.data.goodtime=false;
				console.log("活动已经结束或未开始")
			}
		}

		});
	},
	purchase(){
	var _THis=this;
	const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
	 var usid=uid.usid;
	if(usid==0||usid==undefined){//如果没有登录不能下单
	 uni.showModal({
		 title: '提示',
		 content: '您还没有登录请登录',
		 success: function (res) {
			 if (res.confirm) {
				 uni.navigateTo({
				     url: '/pages/authorize/authorize'
				 });
			 } else if (res.cancel) {
				 console.log('用户点击取消');
			 }
		 }
	 });
	  }
	  else{//登录状态下才可以购买
		  var pack=_THis.cart_good;
		  if(_THis.goodtime==true){
				var data=_THis.good_datas;//获取存储的到支付对象的页面
					var pack=_THis.cart_good;
						var a =
						[{
						good_id: pack.good_id,//商品id
						good_name:pack.good_name,//商品名称
						good_img_url:pack.good_img,//商品图片
						good_price:pack.good_price,//商品现价
						good_cost_price:pack.good_cost_price,//商品原价
						good_order_num:1,//下单数量
						good_stock:pack.good_stock//商品库存
						}];
						console.log(pack)
						uni.setStorage({
							key: 'buy_key',
							data:a,
							success: function () {
								console.log('success');
							}
						});
						uni.navigateTo({
						url: '/pages/placeorder/placeorder?add=true&&into=details'
						});
		  }
			var data={};
			data.sign=_THis.Seckillgoods;
			data.sum=0;
			data.shop_id=_THis.product_id;//商品id
			uni.setStorageSync('sig_key',data);//存储最新的商品秒杀值和商品数量，购物车不传数量
	  }
	},
		createCanvasImageEvn(){
					// 这个获取到的数据渲染到分享这里
					let goods_imgurl=this.detailsdataL.swiper_list;
					let goods_data=this.detailsdataL.good_data;
					Object.assign(this.posterData,
					{
						url:goods_imgurl[0].img,//商品主图
						icon:'https://img0.zuipin.cn/mp_zuipin/poster/hch-hyj.png',//醉品价图标
						title:goods_data.good_name,//标题
						discountPrice:goods_data.good_price,//折后价格
						orignPrice:goods_data.good_cost_price,//原价
						code:'https://img0.zuipin.cn/mp_zuipin/poster/hch-code.png',//小程序码
					})
					this.$forceUpdate();//强制渲染数据
					setTimeout(()=>{
						this.canvasFlag=false;//显示canvas海报
						this.deliveryFlag = false;//关闭分享弹窗
						this.$refs.hchPoster.createCanvasImage();//调用子组件的方法
					},500)
					
				},
				
				// 获取海报的小程序码
				codeImg(){
					return new Promise((resolve,reject)=>{
						wx.request({
							method: 'get',
							url:'http://javaXXXXX',//自己java接口
							header: { 'Content-Type': 'application/x-www-form-urlencoded'},
							data: {
								scene:`sku=${this.sku}`,//自己的参数
								page:"pages/Commodity_details/commodity_details",//想要生成小程序码的页面地址
								width:"128px",//小程序码大小
							},
							success: res => {
							  if(res.data.code==0){
								if (res.data.code==0) {
									const fsm = wx.getFileSystemManager();
									const FILE_BASE_NAME = 'tmp_img_src';
									let filePath = `${wx.env.USER_DATA_PATH}/${FILE_BASE_NAME}.jpg`;//图片临时地址
									fsm.writeFile({
										filePath,
										data: res.data.data,
										encoding: 'binary',
										success() {
											resolve(filePath)
										},
										fail() {
											this.canvasFlag=true;
											uni.showToast({title:'海报生成失败',duration:2000,icon:'none'});
										},
									});
								} else {
									uni.showToast({title: res.data.message, icon: 'none',duration: 2000,icon:'none'})
								}
							  }else{
								this.canvasFlag=true;
								uni.showToast({title:'海报生成失败',duration:2000,icon:'none'});
							  }
							},
							fail:res=>{
							  this.canvasFlag=true;
							  uni.showToast({title:'海报生成失败',duration:2000,icon:'none'});
							}
					  })
					})
				},
				// 分享弹窗
				shareEvn() {
					this.deliveryFlag = true;
				},
				// 关闭分享弹窗
				closeShareEvn() {
					this.deliveryFlag = false;
				},
				// 取消海报
				canvasCancel(val){
					this.canvasFlag=val;
				}
},

	}
</script>

<style lang="scss">
	page{
		
	}
	.swiper{
		width: 100%;
		height:662rpx;
	}
	
	swiper-item image{
		width: 750rpx;
		height: 662rpx;
	}
.surface{
	box-sizing: border-box;
	color: #F1F1F1;
	display: flex;
	justify-content: space-between;
	align-items: center;
	width: 750rpx;
	height: 88rpx;
	background:#3CC075;
	
}
.Sharing_column{
	display: flex;
	box-sizing: border-box;
	background: #F1F1F1;
	border-radius: 0rpx 0rpx 10rpx 10rpx;
	justify-content: space-between;
	align-items: center;
	height:70rpx;
	background:rgba(255,255,255,1);
}
.Sharing_column image{
	width: 200rpx;
	height: 65rpx;
	box-sizing: border-box;
	background:rgba(242,85,118,1);
	border-radius:26px;
	bottom: 8rpx;
	right: -23rpx;
	margin-right: -30rpx;
   margin-bottom: 50rpx;
}
.Delive_goods{
	width:750rpx;
	height:68rpx;
	margin: 15rpx 0rpx;
	background:rgba(255,255,255,1);
	box-shadow:0rpx 6rpx 4rpx 0rpx rgba(76,175,56,0.06);
	border-radius:6px;
	display: flex;
	flex-direction: row;
	justify-content:space-between;
	align-items: center;
}
.order image{
	height:43rpx;
	width:43rpx;
}
.iconimg image{
	height: 50rpx;
	width: 50rpx;
}
 /* 按钮去掉边框 */
	  button::after {
		border: none;
	  }
	  button{
		margin-left: 0;
		margin-right: 0;
		padding-left: 0;
		padding-right: 0;
		line-height: 1;
		color: #1c1c1c;
		font-size: 28rpx;
		background: none;
	  }
	  .button-hover {
		color:#1c1c1c;
		background:none;
	  }
	  /*每个页面公共css */
	.content {
		text-align: center;
		height: 100%;
	}
	.share-btn{
		padding: 30upx 60upx;
	}
	.share-pro{
        display: flex;
        align-items: center;
        justify-content: flex-end;
        flex-direction: column;
        z-index: 5;
        line-height: 1;
        box-sizing: border-box;
        .share-pro-mask{
            width: 100%;
            height: 80%;
            position: fixed;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            background: rgba(0, 0, 0, 0.5);
        }
        .share-pro-dialog {
            width: 750rpx;
            height:325rpx;
            overflow: hidden;
            background-color: #fff;
            border-radius: 24rpx 24rpx 0px 0px;
            position: relative;
            box-sizing: border-box;
            position: fixed;
            bottom: 0;
            .close-btn {
                padding: 20rpx 15rpx;
                position: absolute;
                top: 0rpx;
                right: 29rpx;
            }
            .share-pro-title {
                font-size: 28rpx;
                color: #1c1c1c;
                padding: 28rpx 41rpx;
                background-color: #f7f7f7;
            }

            .share-pro-body{
                display: flex;
                flex-direction: row;
                justify-content:space-around;
                font-size: 28rpx;
	            color: #1c1c1c;
                .share-item{
                    display: flex;
                    flex-direction:column;
                    justify-content: center;
                    justify-content:space-around;
                    .share-icon{
                        text-align:center;
                        font-size: 70rpx;
                        margin-top: 10rpx;
                        margin-bottom: 16rpx;
                        color: #42ae3c;
                    }
                    &:nth-child(2){
                        .share-icon{
                            color: #ff5f33;
                        }
                    }
                }
            }
        }
        /* 显示或关闭内容时动画 */
        .open {
            transition: all 0.3s ease-out;
			transform: translateY(0);
        }

        .close {
            transition: all 0.3s ease-out;
			transform: translateY(310rpx);
        }
    }
	 .canvas{
	    position: fixed !important;
	    top: 0 !important;
	    left: 0 !important;
	    display: block !important;
	    width: 100% !important;
	    height: 100% !important;
	    z-index: 10;
	}//立刻购买按钮css
	.btnbuy{
		height:88rpx; 
		width: 204rpx;
		 background: #38B26D;
		  color: #F1F1F1;
		  font-size:15px;
		  font-size:15rpx;
		  line-height:80rpx; 
		  margin-right:30rpx;
	}
	//加入购物车按钮css
	.addgood{
		height:88rpx; 
		width: 204rpx;
		 background: #7AC79B;
		  color: #F1F1F1;
		  font-size:15rpx;
		  line-height:80rpx;
	}
	.siperimg{
		font-size:25rpx;
		 text-decoration: line-through;
		 padding-left:25rpx;
	}
</style>
