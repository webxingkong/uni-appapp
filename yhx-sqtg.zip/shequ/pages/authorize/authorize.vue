<template>
<view style="height: 100%;overflow: hidden;">
<view style="background: url(../../static/bg.png);height:100%;background-size:cover;">
	
		<view class="Landing_Background">
			<view class="Landing_Background_DIV flex" style="flex-direction: column;align-items: center;">
							<view class="Title">
							<text>为了更好的购物体验请您登陆授权</text>
							</view>
                      <button open-type="getUserInfo" @getuserinfo="getUserInfo" class="btn">获取授权</button>
					<view  style="margin-top: 25rpx;pa">                
					<checkbox-group >
						<label style="color:#FF3333;" @click="checkedswihs()">
						<checkbox value="cb" :checked="che" />我已阅读并同意商城用户协议
						</label>
					</checkbox-group>
					</view>
					<navigator url="/pages/Land/Land" style="color: #808080;align-self:flex-end;padding-top: 15rpx;padding-right: 10%;">
					<text >使用其他号码></text>
					</navigator>
			</view>
		</view>
</view>
</view>
</template>
<script>
	import api from '../../api/api.js'
	import { authorization } from '../../api/conf.js'
    export default {
        data() {
        	return{
				"che":true,
        		"title": 'get/set/clearStorage',
        		"key": '',
        		"data": ''
        	} 
        },
        methods: {
			checkedswihs(){
						this.che=this.che==true ? this.che=false　: this.che=true;/* 控制是否选择 */

  			}, 
        	// 获取用户信息
            getUserInfo(){
				if(this.che==true){
				uni.login({
				  provider: 'weixin',
				  success: function (loginRes) {
				    console.log(loginRes.code);//发送code获取到用户id
					api.get(authorization, {
					   uid:loginRes.code
					}).then(res=>{
               uni.setStorageSync('settionid_key',res);
					}).catch(err => {
					})
        		uni.getUserInfo({
        			provider:"weixin",
        			success:function(result){
						console.log(result)
        				uni.setStorage({
        				    key: "userInfo_key",
        				    data: result,
        				    success: function () {
								   uni.setStorageSync('usidimg_key',result.userInfo.avatarUrl);
        				    }
        				});
        				
        			},
        		});
        		uni.navigateBack({
        			delta: 1
        		});
				}
				});
				}
				else{
					uni.showToast({
					    title: '请勾选用户商城协议',
					    duration: 5000,
					});
				}
        	},
        	unagree: function(){
        		uni.navigateBack({
        		    delta: 1
        		});
				
        	},
        }
		
    };
</script>

<style scoped>
	.Title{
	  padding:25rpx;
	 color: #333333;
	 font-size:35rpx;
	 width: 530rpx;
	 height: 120rpx;
	 margin-bottom:100rpx;
	 color: #808080;
	}/*加粗的-文字*/

.Landing_Background_DIV{
	width: 630rpx;
	 height: 555rpx;
	 background:#FFFFFF;
	 border-radius: 15rpx;
	 margin: auto;
	 padding-top:100rpx;
	  }
	 /* 绑定微信按钮样式 */
	  .btn{
		  background-color: #37B06B;
		  height:85rpx;
		  width:480rpx;
		  border-radius: 12rpx; 
		  color: #FFFFFF;
		  line-height:85rpx;
		  font-size:35rpx;
		  text-align: center;
	  }
</style>
