<template>
	<view>
		<view class="uni-padding-wrap">
		</view>
	</view>
</template>
<script>
	var util = require('../../common/util.js');
	var formatLocation = util.formatLocation;

	export default {
		data() {
			return {
				title: 'chooseLocation',
				hasLocation: false,
				location: {},
				locationAddress: ''
			}
		},
		methods: {
			chooseLocation: function () {

			},
			clear: function () {
				this.hasLocation = false
			}
		},
		onLoad() {
			uni.chooseLocation({
				success: (res) => {
					this.hasLocation = true,
						this.location = formatLocation(res.longitude, res.latitude),
						this.locationAddress = res.address//确定的时候跳转至选择团长界面
						uni.navigateTo({
						    url: "/pages/pay/choosecommander"
						});
				}
			})
		}
	}
</script>

<style>
	.page-body-info {
		padding-bottom: 0;
		height: 440upx;
	}
</style>
