<template>
	<div>99999</div>
</template>

<script>
	import api from '../../../api/api.js'
	import { index } from '../../../api/conf.js'
		export default {
			onLoad() {
			api.get(index, {
			    data: '23'
			}).then(res => {
				console.log(res)
			}).catch(err => {
			    uni.showToast({
			        title: "3465",
			        icon: 'none'
			    })
			})
			}
		}
</script>

<style>
</style>
