<template>
    <view style="display: flex;justify-content: center;flex-direction: column;">
			<view :class="{padd:widhei}"> <canvas class='canvas' canvas-id="firstCanvas"></canvas></view>
		<view class="say_btn" style="width: 100%;height: 130rpx;margin-top: 32rpx;">
			<button type="primary" size="default" style="width: 618rpx;"  @click="capture">保存到相册</button>
		</view>
    </view>
</template>
<script>
    import api from '../../../api/api.js'
    import { qrCode } from '../../../api/conf.js'
    export default {
        data() {
			return{
				widhei:false,//控制自适应样式
				leader_info:[],//团长信息
				adder:'',//地址
				detial_adder:'',//详细地址，canvas不自适应文字超出画布，所有当超过12字符的时候分行显示
				shop_list:[],//商品信息
				heightpx:0,
				pr_url:'',//二维码地址
				deta:'9月12日'
			}   
        },
		 onReady:function () {
			 var _THis=this;/* 做自适应,如果设备宽度大于321就把canvas往右移动, */
			uni.getSystemInfo({
				success: function (res) {
					if(res.windowWidth>321){
						_THis.widhei=true;
						_THis.heightpx=20
					}
				}
			});
			 uni.showLoading({
			     title: '拼命加载中'
			 });
			 
			 setTimeout(function () {//给出4秒的时间获取数据生成canvas
			     uni.hideLoading();
			 }, 4500);
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			  var leader_id=uid.leader_id;
			 api.post(qrCode, {
			 path:'/pages/index/index',//携带商品id去
			 leader_id:leader_id,
			 scene:1
			 }).then(res => {
			this.leader_info=res.leader_info;
			if(res.leader_info.detail_address.length>=12){
			this.adder=res.leader_info.detail_address.substring(0,13);
			this.detial_adder=res.leader_info.detail_address.substring(14);
			}
			this.shop_list=res.shop_list;
			 this.pr_url=res.pr_url;
			  console.log("1")
			 }).catch(err => {
			uni.showToast({
				title: '获取数据失败',
				icon: 'none'
			});
			 });
	setTimeout(()=>{
		var context = uni.createCanvasContext('firstCanvas')
		       context.drawImage('../../../static/shaer_bg.png',10, 20, 300,630)
				context.setFontSize(20)
				context.setFillStyle('#FFFFFF')
				context.fillText('每日精选', 120, 50)
				context.beginPath()
				context.fillRect(22, 55, 275,(300+_THis.heightpx))
				context.setFillStyle('#343A40')
				context.setFontSize(15)
				context.fillText(this.deta, 130, 80)
				context.save()
		uni.getImageInfo({
		      src:_THis.shop_list[0].img_url,//服务器返回的图片地址
		      success: function (res) {
				  context.drawImage(res.path,29,90, 60,60);
				  context.setFontSize(10)
				    context.setFillStyle('#343A40')
				  context.fillText(_THis.shop_list[0].product_name,93,105)
				  context.setFillStyle('#FF0000')
				  context.fillText(_THis.shop_list[0].activity_price,93,135)
		      },
		      fail: function (res) {}
		    });
			uni.getImageInfo({
			      src:_THis.shop_list[1].img_url,//服务器返回的图片地址
			      success: function (res) {
					  context.drawImage(res.path,29,190, 60,60);
					  context.setFontSize(10)
					   context.setFillStyle('#333333')
					  context.fillText(_THis.shop_list[1].product_name,93,210)
					  context.setFillStyle('#FF0000')
					  context.fillText(_THis.shop_list[1].activity_price,93,240)
			      },
			      fail: function (res) {}
			    });
				uni.getImageInfo({
				      src:_THis.shop_list[2].img_url,//服务器返回的图片地址
				      success: function (res) {
						  context.drawImage(res.path,29,280, 60,60);
						  context.setFontSize(10)
						   context.setFillStyle('#333333')
						  context.fillText(_THis.shop_list[2].product_name,93,300)
						  context.setFillStyle('#FF0000')
						  context.fillText(_THis.shop_list[2].activity_price,93,330)
				      },
				      fail: function (res) {}
				    });
					uni.getImageInfo({
					      src:_THis.shop_list[3].img_url,//服务器返回的图片地址
					      success: function (res) {
							  context.drawImage(res.path,170,288, 60,60);
							  context.setFontSize(10)
							   context.setFillStyle('#333333')
							  context.fillText(_THis.shop_list[3].product_name,235,310)
							  context.setFillStyle('#FF0000')
							  context.fillText(_THis.shop_list[3].activity_price,235,330)
					      },
					      fail: function (res) {}
					    });
						uni.getImageInfo({
						      src:_THis.shop_list[4].img_url,//服务器返回的图片地址
						      success: function (res) {
								  context.drawImage(res.path,170,180, 60,60);
								  context.setFontSize(10)
								   context.setFillStyle('#333333')
								  context.fillText(_THis.shop_list[4].product_name,235,210)
								  context.setFillStyle('#FF0000')
								  context.fillText(_THis.shop_list[4].activity_price,235,230)
						      },
						      fail: function (res) {}
						    });
							uni.getImageInfo({
							      src:_THis.shop_list[4].img_url,//服务器返回的图片地址
							      success: function (res) {
									  context.drawImage(res.path,170,85, 60,60);
									  context.setFontSize(10)
									   context.setFillStyle('#333333')
									  context.fillText(_THis.shop_list[4].product_name,235,110)
									  context.setFillStyle('#FF0000')
									  context.fillText(_THis.shop_list[4].activity_price,235,135)
							      },
							      fail: function (res) {}
							    });
					  context.setFontSize(13)
					   context.setFillStyle('#FFFFFF')
					  context.fillText('团长:'+_THis.leader_info.leader_name,20,(375+(_THis.heightpx*1.5)))
					   context.fillText('地址:'+_THis.adder,20,(393+(_THis.heightpx*2)))
					     context.fillText(_THis.detial_adder,20,(415+(_THis.heightpx*2)))
						 context.setFillStyle('#FFFFFF')
					   context.fillRect(20, (422+(_THis.heightpx*2)),197,20)
					  context.setFillStyle('#343A40')
					   context.fillText('长按图片扫一扫，更多精彩抢先购',22,(436+(_THis.heightpx*2)))
					   uni.getImageInfo({
					   					src:_THis.pr_url,//服务器返回的图片地址
					   					success: function (res) {
					   						context.arc(262, (407+_THis.heightpx), 39, 0, 2 * Math.PI)
					   						context.clip() 
					   					  context.drawImage(res.path,225,(370+_THis.heightpx), 75,75);
					   					},
					   					fail: function (res) {}
					   });
				setTimeout(function() {
					context.draw(true)
				},1000);
	},4000)
		    },

        methods: {
           capture() {  
	uni.canvasToTempFilePath({
						x: 0,
						y: 0,
						width: 750,
						height: 1205,
						destWidth: 750,
						destHeight: 1205,
						quality:1,
						canvasId: 'firstCanvas',
						success: function(res) {
								uni.saveImageToPhotosAlbum({
									filePath: res.tempFilePath,
									success: function(res) {
										uni.hideLoading();
										uni.showToast({
										    title: "保存成功",
										    icon: 'none'
										})
									},
									fail(res) {
										uni.hideLoading();
										uni.showToast({
										    title: "保存成功",
										    icon: 'none'
										})
									}
								});
						},
						fail(res) {
						uni.showToast({
						    title: "生成失败",
						    icon: 'none'
						})
							uni.hideLoading();
						}
					},this);
        }
    },
	}
</script>

<style scoped>
    .padd{
		padding-left:40rpx;
	}
    .canvas{
      width: 100%;
      height:1050rpx;
    }
</style>
