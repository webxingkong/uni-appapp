<template>
	<!-- by xiaofu -->
	<view class="content">
		<!-- 首页社区位置及团长信息 -->
		<view class="index-head-location flex_1 pl20 pr20 flex_lr_m">
			<view class="head-location-l flex_m logind" v-if="data.regiment_img">
				<image :src="data.regiment_img" class="img"></image>
				<!-- <text class="f26 ml20">{{data.regiment_address}}</text> -->
				<text class="f26 ml20" @click="to_position()" style="color:#5F6368;">{{data.regiment_address}}</text>
			</view>
			<view class="head-location-l flex_m unlogin" v-else>
				<text class="f26 ml20" @click="toauthorize" style="color: #666666;">您还没有登录，轻触立即登录</text>
			</view>
			<view class="head-location-r flex_c_m" @click="search">
				<text class="f26 mr20 iconfont">&#xe717;</text>
				<text class="f26">搜索</text>
			</view>
		</view>
		<view class="index-body pr20 pl20">
			<!-- 头部轮播 -->
			<view class="body-banner mt20 rel">
				<swiper class="banner-item" :autoplay="data.autoplay" :interval="data.interval" :duration="data.duration" @change="bannerChange">
					<swiper-item class="banner-list" v-for="(item, index) in data.index_banner" :key="index" @click="totheir_url(item.id)">
						<image :src="item.img_url" class="img"></image>
					</swiper-item>
				</swiper>
				<!-- 自定义轮播图指示点 -->
				<view class="banner-dots abs flex_c_m w100">
					<text class="dats mr10 ml10" :class="{active: data.swiper_current == mun}" v-for="(item, mun) in data.index_banner" :key="mun"></text>
				</view>
			</view>
			<!-- 分类导航 -->
			<view class="body-type mt20">
				<view class="type-item w100 flex">
					<view class="type-list flex_tb_c pt20 pb20" v-for="(item, index) in data.index_type" :key="index" @click="topage(item.id)">
						<image :src="item.img_url" class="img"></image>
						<text class="type-list-name f22">{{item.name}}</text>
					</view>
				</view>
			</view>
			<!-- 抢购 -->
			<view class="body-panic mt20 w100" v-if="data.timeshow">
				<view class="panic-top pt20 pb20 pl10 pr10 flex_lr_m">
					<view class="top-btn flex_c_m">
						<text class="f24" style="color: #000000;">今日疯抢</text>
					</view>
					<view class="top-time">
						<text class="iconfont f24 mr10">&#xe671;</text>
						<text class="f24 mr20">{{data.buy_time}}</text>
						<!-- <text>{{data.hour}}-{{data.minu}}-{{data.sec}}</text> -->
						<uniCountDown 
						    :day="data.day" 
						    :hour="data.hour" 
						    :minute="data.minute" 
						    :second="data.secoud" :reset="data.reset"
							 @watchChild="timereach">
						</uniCountDown>
						<!-- timereach 接受子组件时间到达触发的函数 -->
					</view>
				</view>
				<view class="panic-bottom pl10 pr10" >
					<scroll-view  class="scroll-view flex" scroll-x="true">
						<view class="scroll-list flex_tb mr10" v-for="(item,index) in data.index_panic" :key="index" @click="to_details(item.good_id)">
								<view class="scroll-list-t">
									<image :src="item.good_img_url" class="img"></image>
									<view class="good-name ell">
										<text class="f24">{{item.good_name}}</text>
									</view>
								</view>
								<view class="scroll-list-b flex mb20">
									<view class="good-price flex_b mr20">
										<text class="f18 lh18">￥</text>
										<text class="f24 lh24">10</text>
									</view>
									<view class="good-sales f22 lh22 flex_b">
										<text>￥9.9</text>
									</view>
								</view>
						</view>
					</scroll-view >
				</view>
			</view>
			<view style="display: none;" else></view>
		</view>
		<!-- 商品模块 -->
		<view class="index-good mt20">
			<view class="good-type w100">
				<view class="type-list pl20 pr20 rel">
					<text class="type-list-name f28 b tc">今日推荐</text>
					<view class="abs type-list-line tc">
						<view class="line"></view>
					</view>
				</view>
			</view>
			<view class="good-item mt20 pl20 pr20">
				<view class="good-list mb20" v-for="(item,index) in data.index_goods" :key="index">
					<image :src="item.good_img_url" class="img" @click="toCommoditydetails(item.good_id)"></image>
					<text class="f26 good-name pl20 pr20">{{item.good_name}}</text>
					<view class="good-center flex_lr_m pl20 pr20">
						<text class="f24">预计到货：{{item.good_time}}</text>
						<view class="good-center-r">
							<view class="case pl10 pr10 ml20 dib">
								<text class="f20 mr5 iconfont" style="color: #60B45C;">&#xe709;</text>
								<text class="f15">累计{{item.good_sales}}袋</text>
							</view>
							<view class="case pl10 pr10 ml20 dib">
								<text class="f20 mr10 iconfont" style="color: #60B45C;">&#xe709;</text>
								<text class="f15">剩余{{item.good_stock}}袋</text>
							</view>
						</view>
					</view>
					<view class="good-bottom flex_lr_m p20">
						<view class="good-bottom-l flex_c_m">
							<text class="good-price f28 mr20">￥{{item.good_price}}</text>
							<text class="good-cost-price f20">￥{{item.good_cost_price}}</text>
						</view>
						<view class="shop-cart tc pl20 pr20">
							<view class="f28" @click="buynow(item,index)">立即购买<font v-if="item.good_number>0">{{item.good_number}}</font></view>
						</view>
					</view>
				</view>
				<image class="totop" src="../../../static/index_img/backtop.png" @click="top()"  v-show="swithtop"></image><!-- 返回顶部 -->
				<image class="share" src="../../../static/commodity_icon/share.png" @click="toshare"></image><!-- 分享 -->
				
			</view>
		</view>
		<view style="display: none;"></view>
		<view class="but_img" style="margin-left: 32rpx;margin-right: 32rpx;margin-top: 20rpx;">
			<image :src="data.but_img" style="width: 100%;height:190rpx; background-size:auto;"></image>
		</view>
		<!-- <uni-popup ref="popup" type="center">
		    <view class="m0">
				<view class="f32 fb" style="margin-top: 88rpx;">提醒</view>
				<view class="flex_wrap presentation">您选择的团长距离您5.9km,是否确定选择？</view>
			</view>
		    <view class="flex btn_buttom" style="justify-content: space-between;">
				<button class="cancel fb" plain="true" @click="closePopup">取消</button>
				<button class="sure fb" type="primary" plain="true">确定</button>
			</view>
		</uni-popup> -->
	</view>
</template>

<script>
	import api from '../../../api/api.js'
	import { index } from '../../../api/conf.js'
	import { shopAdd } from '../../../api/conf.js'
	import uniPopup from "../../../components/uni-popup/uni-popup.vue"
	import uniCountDown from '../../../components/uni-count-down/uni-countdown.vue'
	var amapFile = require("../../../common/amap-wx.js");
	export default {
		components: {
			uniCountDown,
			uniPopup
		},
		data() {
			return {	                 
				"data":{
					"goodtime":false,//抢购活动是否可以抢购了
					"buy_time":"",//抢购是否开始说明
					"regiment_img":"../../../static/index_img/user-img@2x.png",//团长头像
					"regiment_id":"",//团长id
					"regiment_address":"您还没有选择团长",//团长名称
					"but_img":"",//底部宣传图片
					"index_banner":[],
					timeshow:true,//秒杀商品栏的显示
					"autoplay": true,
					"interval": 2000,
					"duration": 500,
					"swiper_current": 0,
					"index_type":[],
					"index_panic":[],
					"index_goods":[],
					"index_goods_pages":0,//商品页数
					"url_item":"",
					"item_id":"",
					"sort_url":"",
					"time_stamp":"",
					"code":"dlnfdfnfjf",
					day:0,
					hour:0,
					secoud:0,
					minute: 0,
					reset: false,
					"page_url":"",//轮播图链接地址
					"Commoditydetails_url":"",//商品详情链接
					"cart_good":[],//存储购物车的商品数据
					"Rush_time":1,//1表示活动还未开始
					
				},
				usid:0,//用户名
				leader_id:0,//团长id
				"latitude": 22.83,
				"longitude": 108.39,
				buynum:"",
				swithtop:false,/* 控制点击返回顶部按钮的显示 */
			}
		},
		onShow() {
			this.onladindex()
			var myAmapFun = new amapFile.AMapWX({key:"e9f8f27c740f9cccf7cd083958685e52"});//位置服务
			myAmapFun.getRegeo({
			  success: (res) => {
				uni.setStorage({//存储地理位置
				    key: "Adress_key",
				    data: res,
				    success: function () {
				     
				    }
				});
				console.log("登录成功");
			  },
			  fail: function(info){
			    //失败回调
			    console.log(info)
			  }
			});
		},
		onLoad() {
this.onladindex()//第一次进入页面加载首页数据
		},
		methods: {
			onladindex(){//首页数据封装为一个函数，用于每次显示页面调用更新数据
				var that = this;
				 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
				 var usid=uid.usid;
				 if(usid==undefined){//如果未读取到id说明未登陆加载0的数据
					 usid=0;
				 }
							/* 首页封装数据请求 */
							api.get(index, {
								   uid:usid,
							   //用户id
							}).then(res=>{
								that.data.index_banner=res.index_banner;
								that.data.regiment_id=res.regiment_info.leader_id;//团长id
								that.data.regiment_img=res.regiment_info.regiment_img;//团长头像
								that.data.index_type=res.index_type;
								that.data.index_panic=res.index_panic;
								if(res.regiment_info.leader_name!=""){
									that.data.regiment_address=res.regiment_info.leader_name;//团长名称
								}
								that.data.index_goods=res.index_goods;
								that.data.but_img=res.but_img.img_url;
								for(let i in that.data.index_type){
									that.data.item_id=res.index_type[i].id;
									that.data.sort_url=res.index_type[i].sort_url
								};
								for(let j in that.data.index_banner){
									that.data.page_url=res.index_banner[j].page_url;
								}
								for(let z in that.data.index_goods){
									that.data.Commoditydetails_url=res.index_goods[z].page_url;
								}
								var time_stamp_start=res.time_stamp_start;//抢购开始时间
								var time_stamp_end=res.time_stamp_end;//抢购结束时间
								var time_curren_ttime=res.time_curren_ttime;//服务器当前时间
								if(time_curren_ttime<=time_stamp_start)//判断是否是倒计时或者是抢购开始
								{
							              that.data.buy_time="开始倒计时";
								         var time =time_stamp_start - time_curren_ttime;
								         var days = Math.floor(time/86400);//计算小时数
								         var remain = time%86400;
								         var hours = Math.floor (remain/3600);
								//计算分钟数
								         var remain = remain%3600;
								         var mins =  Math.floor(remain/60);
								//计算秒数
								         var secs = remain%60;
									that.data.day=days;
									that.data.hour=hours;
									that.data.minute=mins;
									that.data.secoud=secs;
								}
								else{ 
									     that.data.buy_time="剩余";
										 var time =time_stamp_end - time_curren_ttime;
								         var days = Math.floor(time/86400);//计算小时数
								         var remain = time%86400;
								         var hours = Math.floor (remain/3600);
								//计算分钟数
								         var remain = remain%3600;
								         var mins =  Math.floor(remain/60);
								//计算秒数
								         var secs = remain%60;
									that.data.day=days;
									that.data.hour=hours;
									that.data.minute=mins;
									that.data.secoud=secs;
								}
								//动态赋值
								that.data.reset=true;
								that.data.minute=parseInt(quesTime);
								
								that.data.but_img=res.but_img[0].img_url 
							}).catch(err => {
							})
			},
			//过滤存储商品数据加入购物车
			buynow(item,index){
			var _THis=this;
				const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
				 var usid=uid.usid;
				 var leader_id=uid.leader_id;
				if(usid==0||usid==undefined){//如果没有登录
				 console.log("最先执行的")
				 uni.showModal({
					 title: '提示',
					 content: '请您登录后操作',
					 success: function (res) {
						 if (res.confirm) {
							 uni.navigateTo({
								 url: '/pages/authorize/authorize'
							 });
							 console.log("请先登录")
						 } else if (res.cancel) {
							 console.log('用户点击取消');
						 }
						 return;
					 }
				              });
				}
				else{
						if(_THis.data.index_goods[index].good_number>=_THis.data.index_goods[index].good_stock){
						uni.showToast({
							title: '库存不足',
							duration: 3000
						             });
						      return
						                      }
					_THis.data.index_goods[index].good_number++
					api.post(shopAdd, {
					   leader_id:leader_id,//团长id
					   user_id:usid,//用户名
					   shop_id:item.good_id//商品id
					}).then(res=>{
						
					}).catch(err => {
					})
					uni.showToast({
						title: '成功加入购物车',
						duration: 1500
					            });
				   }
			
			},
			to_position(){
				uni.navigateTo({
				    url: "../../pay/choosecommander"
				});
			},
		/* 	返回顶部 */
			top(){
				uni.pageScrollTo({
				    scrollTop: 0,
				    duration: 300
				});
			},
			//搜索
			search(){
				uni.navigateTo({
				    url: "../../search/search"
				});
			},
			//授权
			toauthorize(){
				uni.navigateTo({
				    url: '../../authorize/authorize'
				});
				
			},//子组件到达时间触发事件，判断是否可以下单了
			timereach(){
				let _THis=this;
				 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
				 var usid=uid.usid;
				api.get(index, {
				uid:usid,//用户id
				}).then(res => {
				var time_stamp_start=res.time_stamp_start;//抢购开始时间
				var time_curren_ttime=res.time_curren_ttime;//服务器当前时间
				var time_stamp_end=res.time_stamp_end;//抢购结束时间
				if(time_curren_ttime>=time_stamp_start)//判断是否是倒计时或者是抢购开始
				{
					_THis.data.goodtime=true;
					console.log("活动开始了")
				}
				if(time_curren_ttime>=time_stamp_end)//判断是否是倒计时是否结束
				{
					_THis.data.timeshow=false;//如果时间结束关闭秒杀栏
				}
				}).catch(err => {
				
				});
			},
			//轮播图切换修改指示点背景色
			bannerChange(e) {
				let index = e.detail.current;
				this.data.swiper_current = index;
			},
			// openPopup(){
			//     this.$refs.popup.open()
			// },
			// closePopup(){
			//     this.$refs.popup.close()
			// },
			//分类链接
			topage(id){	//将点击进入分类的商品名称传给分类页
				uni.navigateTo({
			   url:"/pages/classification/classification?name"+id
				});
				console.log(id)

			},
			toshare(id){
				uni.showToast({
					title:"敬请期待",
					icon:"success"
				})
			/* 	uni.navigateTo({
				    url: 'share'
				}); */
			}, 
			//轮播图链接
			totheir_url(id){
				uni.authorize({
				    scope: 'scope.userLocation',
				    success() {
				        uni.getLocation()
				    }
				})
				let data_index=id;
				for(let i in this.data.index_banner){
					if(this.data.index_banner[i].id == data_index){
							this.data.page_url=this.data.index_banner[i].page_url;
							// console.log(this.data.url_item);
							uni.navigateTo({
							    url: this.data.page_url
							});
					}
				}
			},
			toCommoditydetails(id){
				uni.navigateTo({url: "../../Commodity_details/commodity_details?Seckill=false&goods=2&id="+id
				});
			},
			to_details(id){ /* 点击的商品id */
			if(this.data.goodtime==true){//当为true(就是活动开始)的时候才能跳转下单
				uni.navigateTo({//Seckillw为秒杀商品，goods未秒杀活动，id为商品id
				    url: "../../Commodity_details/commodity_details?Seckill=true&goods=1&id="+id
				});
			}
			            }
		},
		/* 获取滚动条位置 ,操作返回顶部*/
		onPageScroll: function(Object) {
		 Object.scrollTop>=50? this.swithtop=true:this.swithtop=false;
		},
		created: function(e) {
			// console.log(this.data.time_stamp);
			

		},
	}
</script>

<style lang="less" scoped>
	.example-body {
		border-top: 1px #f5f5f5 solid;
		padding: 30rpx;
		background: #fff
	}
	.db{
		display: block;
	}
	.dn{
		display: none;
	}
	.logind{
		
	}
	.unlogin{
		
	}
	.content {
		.index-head-location{
			height: 100rpx;
			background-color: #FFFFFF;
			background-size: 100%;
			.head-location-l{
				.img{
					height: 50rpx;
					width: 50rpx;
					border-radius: 50%;
					border: 5rpx solid #EFEFEF;
					background-size: 100%;
				}
			}
			.head-location-r{
				width: 190rpx;
				height: 60rpx;
				border-radius: 30rpx;
				background-color: #EFEFEF;
			}
		}
		.index-body{		
			.body-banner{
				.banner-item{
					width: 100%;
					height: 268rpx;
					.banner-list{
						width: 100%;
						height: 100%;
						overflow: hidden;
							.img {
								width: 100%;
								height: 100%;
								border-radius: 20rpx;
							}
					}
				}
				.banner-dots{
					height: 20rpx;
					left: 0rpx;
					bottom: 15rpx;
					.dats{
						height: 5rpx;
						width: 25rpx;
						background-color: #FFFFFF;
					}
					.dats.active{
						background-color: #3CC075;
					}
				}
			}
			.body-type{
				.type-item{
					border-radius: 20rpx;
					background-color: #FFFFFF;
					justify-content: flex-start;
					.type-list{
						width: 25%;
						height: 150rpx;
						.img{
							width: 80rpx;
							height: 80rpx;
						}
					}
				}
				
			}
			.body-panic{
				background-color: #FFFFFF;
				border-radius: 20rpx;
				height: 425rpx;
				.panic-top{
					.top-btn{
						height: 27rpx;
						width: 112rpx;
						// border-radius: 52rpx;
						// background-color: #FA6058;
						color: #fff;
						font-size: 28rpx;
					}
					.top-time{
						color: #777777;
					}
				}
				.panic-bottom{
					height: 337rpx;
					.scroll-view{
						 flex-direction:row;
						 white-space: nowrap;
						 width: 100%;
							.scroll-list{
								width: 200rpx;
								height: 337rpx;
								display: inline-block;
								.scroll-list-t{
									.img{
										width: 200rpx;
										height: 200rpx;
									}
									.good-name{
										width: 200rpx;
									}
								}
								.scroll-list-b{
									flex-direction:row;
									.good-price{
										color: #FA6058;
									}
									.good-sales{
										text-decoration:line-through;
										color: #808080;
									}
								}
							}
						
					}
				}
			}
		}
		.index-good{
			.good-type{
				height: 95rpx;
				background-color: #FFFFFF;
				.type-list{
					height: 95rpx;
					color: #F96156;
					line-height: 95rpx;
					.type-list-line{
						height: 8rpx;
						left:0;
						bottom:0;
						.line{
							width: 50rpx;
							margin-left: 50rpx;
							height: 8rpx;
							border-radius: 8rpx;
							background-color: #F96156;
						}
					}
				}
			}
			.good-item{
				.good-list{
					background-color: #FFFFFF;
					border-radius: 30rpx;
					.img{
						width: 100%;
						height: 350rpx;
						border-radius: 30rpx 0 0 30rpx;
					}
					.good-name{
						height: 100rpx;
						line-height: 100rpx;
					}
					.good-center{
						color:#C9CACA;
						.good-center-r{
							.case{
								color: #3CC075;
								height: 34rpx;
								line-height: 34rpx;
								border-radius: 34rpx;
								border: 2rpx solid #3CC075;
							}
						}
					}
					.good-bottom{
						.good-bottom-l{
							.good-price{
								color: #F3604C;
							}
							.good-cost-price{
								text-decoration: line-through;
								color: #808080;
							}
						}
						.shop-cart{
							line-height: 50rpx;
							height: 50rpx;
							border-radius: 50rpx;
							color: #FFFFFF;
							background-color: #3CC075;
						}
					}
				}
			}
		}
	}
	.totop{
		width: 60rpx;height: 60rpx;float: right;position: fixed;top: 900rpx;right: 5rpx;z-index: 9999;
	}
	.share{
		width: 145rpx;height: 50rpx;float: right;position: fixed;top: 1000rpx;right: -20rpx;z-index: 9999;
	}

</style>
