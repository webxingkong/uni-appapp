<template>
	<view>
		<view class="uni-tab-bar">
	<scroll-view scroll-x class="uni-swiper-tab">
		<block v-for="(item,index) in tabBars" :key="index">
		<view class="swiper-tab-list" :class="{'active':tapIndex==index}" @tap="tabswper(item.id,index)">
			{{item.name}}
			<view class="Line"></view>
		</view>
		</block>
	</scroll-view>
	</view>
		<!--展示区域-->
    <view class="siper_item" v-for="(item,index) in goodListdata" :key="index">
		<view  class="item_name"><view>{{item.orderleader.community_name}}</view><view>{{item.order_state}}</view></view>
		<view style="width: 100%;height: 0.5rpx;background:#F4F4F4;"></view>
		<view class="item_img"><image :src="item.orderleader.head_img" style="height:165rpx; width: 165rpx;" mode="数据异常"></image>共{{item.order_good_number}}件</view>
		<view style="width: 100%;height:2rpx;background:#F4F4F4;"></view>
		<view style="display: flex;align-items: center;margin:5rpx; 0rpx">
		<text class="btnmode">{{item.transport_type}}</text>
		<text style="margin-left:50rpx;">付款金额:<text style="color: #FF0000;padding-left:20rpx;">￥{{item.pay_money}}</text></text>
		<text style="margin-left:30%;border:1px solid #666666;border-radius: 15rpx;color:#666666;font-size:25rpx;">查看详情</text>
		</view>
	</view>
	<text style="color:#999999 ;display: flex;justify-content: center;">{{title}}</text>
		</view>
</template>

<script>
	import api from '../../../api/api.js'
	import { orderLists } from '../../../api/conf.js'
	export default{

		data(){
			return{
				"title":'已经到底了',
				tapIndex:0, //tap选择的下标
				"goodListdata":[],
				tabBars:[
					{name:'全部',
					id:0},
					{name:'待付款',
					id:1},
					{name:'备货中',
					id:2},
					{name:'待取货',
					id:5},
					{name:'售后',
					id:8},
					],
			}
		},
		onLoad(option) {//option在我的页面传递过来的订单参数
		var _THis=this;
		_THis.tapIndex=option.id;
		this.tabswper()
		},
		methods:{
			tabswper(e,v){//下标和id
			var _THis=this;
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var usid=uid.usid;
				api.get(orderLists, {
					user_id:usid,
					order_state:_THis.tapIndex
					}).then(res => {
				     _THis.goodListdata = res.orderList;
					 _THis.tapIndex=v;//点击分类重新赋值下标
					}).catch(err => {
				uni.showToast({
					title: '获取数据失败',
					icon: 'none'
				});
						})
			}
		},
	}
</script>
<style>
	.siper_item{
		display: flex; 
		box-sizing: border-box;
		width:90%;
		background:#FFFFFF;
		 flex-direction:column;
		 justify-content:space-around;
		 align-content: center;
		 margin:25rpx 0rpx 25rpx 25rpx;
		 border-radius:15rpx;
		 margin-left:35rpx;
	}
	.swiper-tab-list :active{
		color: #FFFFFF;
	}
	.item_name{
		display: flex; 
		justify-content: space-between;
		flex-direction:row;
		margin:10rpx;
	}
	.btnmode{
		border:1px solid #8F8F94;
		color:#666666;
		padding-left: 5rpx;
		padding-right: 5rpx;
		border-radius:15rpx;
		font-size:25rpx;
		margin-left:10rpx;
	}
	.item_img{
		display: flex;
		 align-items: center;
		  justify-content: 
		  space-between;
		  padding-right: 15rpx;
	}
	.uni-tab-bar {
background: #3CC075;
		display: flex;
		flex: 1;
		flex-direction: column;
		overflow: hidden;
		height: 100%;
	}
	.uni-swiper-tab {
		width: 100%;
		white-space: nowrap;
		line-height: 100upx;
		height: 100upx;
		border-bottom: 1px solid #c8c7cc;
	}
	.swiper-tab-list {
		font-size: 30upx;
		width: 150upx;
		display: inline-block;
		text-align: center;
		color: #555;
	}
	.uni-tab-bar .active {
	    color: #FFFFFF;
	}
	.uni-uploader__input-box:active {
		border-color: #999999;
	}
	
	.uni-uploader__input-box:active:before,
	.uni-uploader__input-box:active:after {
		background-color: #999999;
	}
	.active .Line{
		margin-top: 15rpx;
		margin-left: 40rpx;
		height: 5rpx;
		width: 70rpx;
		background: #FFFFFF;
	}
   .page{background:#F4F4F4;}
</style>
