<template>
<view><!-- 主根目录 -->
	<view><!-- 页面主根目录 -->
   <view v-show="!shows">
	<view>
		<view class="hemargin flex_tbr border_rad b_color box-size" >
		<view class="p15"><image :src="Shopping_data.regiment_info.head_img" style="height: 110rpx; width: 110rpx;" mode="widthFix" class="border_b"></image></view>
		<view style="padding-right:160rpx;">
			<view class="fontcolorq" style="font-size: 32rpx;">{{Shopping_data.regiment_info.community_address}}</view>
			<view class="fontcolorh f24">收货地址:{{Shopping_data.regiment_info.community_name}}</view>
		</view>
			<view class="iconleft" style=" padding-right: 10rpx;"> <i class="iconfont pl10 fontcolorh f32">&#xe7e0;</i></view>
		</view>
	</view>
		<!--商品数据-->
		 <view  v-for="(item,index) in Shopping_data2" :key="index">
		<view class="good_buy" >
				<view class="box relative" >
					<view :class="[item.goods_staice == 1 ? 'seleav':'sele']" @tap="Selection(index)" style="height: 42rpx;width: 42rpx; background-size: 100%;"></view>
					<view><img :src="item.good_img_url" style="height: 127rpx; width: 127rpx;margin: 0 12rpx;" mode="widthFix"></image></view>
						<view  @tap="gotoIndex(item.good_id)">
						<view><text class="fontcolorq" style="font-size:37rpx;box-sizing: border-box;">{{item.good_name}}</text></view>
						<view><p class="fontcolors" style="color: #F5222D;">{{item.good_price}}</p></view>
						<view><p class="fonts text_de fontcolorh text_font12">{{item.good_cost_price}}</p></view>
						</view>
						<!--商品按钮部分-->
					<view class="buttonself"  @click="Calculated_subscript(index,item.good_id)">
							<uni-number-box  @change="numer" :username="item.good_order_num" @reduces="reduce" @adds="add" :good_ids="item.good_id" :good_stock.sync="item.good_stock"/>
							<!-- @change为子组件变化触发的函数，username将数量传给子组件显示，@reduces减号触发，@add加号触发，good_ids传递商品id -->
					</view>
				   </view>
		 </view>
		 </view>
		
		
		<!--倒计时的商品区域-->

<!-- <view class="good_buy">
		<view class="box" >
		<view><img src="../../../static/tabimg/select.png" style="height:42rpx; width:42rpx; margin: 0 12rpx;" mode="widthFix"></image></view>
		<view><img src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/img-2.png" style="height: 127rpx; width: 127rpx;margin: 0 12rpx;" mode="widthFix"></image></view>
		<view>
		<view><text class="fontcolorq" style="font-size:37rpx;box-sizing: border-box;">八宝粥现货500克</text></view>
		<view><p class="fontcolors">¥4.9</p></view>
		<view><p class="text_de fontcolorh text_font12">￥99999</p></view>
			抢购栏在这里
		<view>
			<p class="" style="background:rgba(242,85,118,1);opacity:0.44;position: absolute; width:686rpx; left: 35rpx; box-sizing: border-box;border-radius: 12rpx;text-align:center;">月20日13.14开抢</p>
		</view>
			</view>
			</view>
			</view> -->
			
		
		<!--列表失效界面-->
<!-- 		<view class="good_buy" style="color: #808080!important;">
				<view class="box" style="justify-content:flex-start!important;">
					<view><img src="../../../static/tabimg/select.png" style="height:42rpx; width:42rpx; margin: 0 12rpx;" mode="widthFix"></image></view>
					<view><img src="../../../static/tabimg/9091650.png" style="height: 127rpx; width: 127rpx;margin: 0 12rpx;" mode="widthFix"></image></view>
						<view>
						<view><text class="">八宝粥现货500克</text></view>
						<view><p class="">¥4.9</p></view>
						<view><p class="text_de  text_font12">￥99999</p></view>
						</view>
				</view>
			</view> -->

		 	<!--计算下单部分-->
		 <view class="Calculation">
		 <view :class="[btndata==true ? 'seleav':'sele']" @tap="Selections(index)" style="height: 42rpx;width: 42rpx; background-size: 100%;"></view>
		 	<view style="display: flex; padding-right:150rpx; align-items: center;">
		 		<text>合计:</text>
		 		<view style="color: red;">{{totalPack_price}}</view>
		 	</view>
		 	<view @click="to_summary()"><button>去结算{{Settlement}}</button></view>
		 </view>
</view>
	</view>
	
<view class="flex_line_c_m pt30" v-show="shows"><!-- 无购物下单的根目录 -->
	<view> <image src="http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/emptystate/Empty%20state-img-3.png"></image></view>
	<text class="fontcoll b" style="font-size:36rpx; ">购物车为空</text>
	<text class="mt30 fontcolorhh">您还没有登录或添加商品到购物车</text>
	<view class="mt30 border_rad fontcoll lh40 f24" style="height: 50rpx; width:250rpx; heiborder-radius: 60rpx; border:1rpx solid #09BB07;text-align: center;" @tap="order()">去下单</view>
</view>
</view>
</template>

<script>
	import uniNumberBox from './uni-number-box.vue'
	import api from '../../../api/api.js'
	import { shopCart } from '../../../api/conf.js'
	import { shopPlus } from '../../../api/conf.js'
	import { shopReduce } from '../../../api/conf.js'
	import { shopDel } from '../../../api/conf.js'//购物车的删除
	import { placeOrder } from '../../../api/conf.js'//提交订单
	export default {
		components: {
			uniNumberBox,
		},
		data() {
			return {
				btimg:'http://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-%20disabled.png',
				Shopping_data:[],//这是存储用户数据
				Shopping_data2:[],//这是存储商品数据
				clickdata:[],//存储点击每个btn的数据
				btndata:true,
				shows:true,//无下单的状态页面
				Nowid:'',//目前点击的商品id//用于发送购物车的商品的增加和减少
				status:0,
			}
		},
		onLoad(){
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var usid=uid.usid;
			  var leader_id=uid.leader_id;
				 //提交加入购物车数据
				 	api.get(shopCart, {
				 		user_id:usid,
				 		leader_id:leader_id,
				 	}).then(res => {
/* 				 		this.shows=true; */
				 		var data2=res.cart_goods;
						if(data2!=""){//数据是否为空
							this.shows=false;
							this.Shopping_data = res;
							this.Shopping_data2=data2;
							this.status=res.status;
						}

				 	}).catch(err => {
				 		console.log("存储的数据发送失败")
				 	});
		
		},
		onShow() {
			var _THis=this;
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var usid=uid.usid;
			if(usid==undefined){//如果没有登录
			 uni.showModal({
				 title: '提示',
				 content: '您还没有登录请登录',
				 success: function (res) {
					 if (res.confirm) {
						 uni.navigateTo({
						     url: '/pages/authorize/authorize'
						 });
					 } else if (res.cancel) {
				      _THis.shows=true;
					 }
				 }
			 });
			 }
/* 			 if(this.status==1||usid!=undefined){//假如购物车为绑定手机号
			 							 uni.showModal({
			 							 title: '提示',
			 							 content: '请绑定手机号码购物',
			 							 success: function (res) {
			 								 if (res.confirm) {
			 									 uni.navigateTo({
			 										 url: '/pages/Land/Land'
			 									 });
			 								 } else if (res.cancel) {
			 									 console.log('用户点击取消');
			 								 }
			 							 }
			 							 });
			 } */
		},
		methods: {
			//跳转至详情并把购物车的id传递
			gotoIndex(id){
				uni.navigateTo({
				url: '../../Commodity_details/commodity_details?id='+id
				});
			},
			to_summary(){//购物车下单
			var _THis=this;
			let This=[];//存储支付购物车的
			let goods=this.Shopping_data2;
			goods.forEach((food) => {
				if(food.goods_staice==1){
				return	This.push(food)
				}
			})
		uni.setStorage({
		    key: 'buy_key',
		    data:This,
		    success: function () {
				var pack=[];//循环出加入购物车的id
				This.forEach((food) => {
					return	pack.push(food.cart_id)
				})
			var shop_id=pack;//购物车id
		    }
		});
		var data={};
		data.sign=4;//秒杀值
		data.sum=0;//下单数量
		data.shop_id=this.shop_id;//购物车id
		uni.setStorageSync('sig_key',data);//存储最新的商品秒杀值和商品数量，购物车不传数量
		uni.navigateTo({
		url: '/pages/placeorder/placeorder?into=cart'
		});
			},
			
			order(){ /* 无单跳转去下单 */
				uni.switchTab({
				url: '/pages/tabbar/index/index'
				});
                   },
			Calculated_subscript(index,id){
				var _THis=this;
				// 点击的下标
				_THis.Shopping_data2[index].good_order_num=this.clickdata;

				if(this.clickdata<1){
				let Shopping_data2=this.Shopping_data2;
					uni.showModal({
					    title: '是否删除该商品',
					    success: function (res) {
					        if (res.confirm) {
					          Shopping_data2.splice(index,1);//当点击数据小于0的时候删除选项
							  //购物车删除
							  const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
							  var usid=uid.usid;
							  var leader_id=uid.leader_id;
							  api.post(shopDel, {
								 leader_id:leader_id,
								 user_id:usid,	
							    shop_id:id
							  }).then(res=>{
							  }).catch(err => {
							  })
					        }
							else{
								_THis.Shopping_data2[index].good_order_num=1;
							}
					    }
					});
				}
			},
			//加发送的商品数据
			add(id){
				console.log("我一直触发")
				var _THis=this;
				 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
				 var usid=uid.usid;
				 var leader_id=uid.leader_id;
				api.post(shopPlus, {
				  leader_id:leader_id,
				  user_id:usid,
				  shop_id:id
				}).then(res=>{
					console.log(res)
				}).catch(err => {
				})
			},//减发送的商品数据
			reduce(id){
				var _THis=this;
				const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
				var usid=uid.usid;
				var leader_id=uid.leader_id;
				api.post(shopReduce, {
				  leader_id:leader_id,
				  user_id:usid,
				  shop_id:id
				}).then(res=>{
				}).catch(err => {
				})
			},
			numer(data){
				// 从子组件获取的点击数据
				this.clickdata=data++;
			},
			//实现选中切换功能
			Selection(id){
				let  goodsStaice= this.Shopping_data2[id].goods_staice;
				if(goodsStaice==1){
					this.Shopping_data2[id].goods_staice =0;
				}
				else{
					this.Shopping_data2[id].goods_staice =1;
				}
			},
			/* 全选功能 */
			Selections(){
				let goods=this.Shopping_data2;
				this.btndata=this.btndata==true ? false : true; //下单按钮的选中未选中状态
				if(this.btndata==true){
					goods.forEach((food) => {
						food.goods_staice=1;
						
					})
				}
				else{
					goods.forEach((food) => {
								food.goods_staice=0;
					})
				};
			},
		},

		computed:{
			totalPack_price(){
				let clickdata=this.clickdata;
				let goods=this.Shopping_data2;
				let pack = 0;
				goods.forEach((food) => {	
					if(food.goods_staice==1){
					pack += food.good_price*food.good_order_num;
					}
				})
				return pack;
			},
			Settlement(){
				let clickdata=this.clickdata;
				let goods=this.Shopping_data2;
				let pack = 0;
				goods.forEach((food) => {	
					if(food.goods_staice==1){
					pack++;
					}
					
				})
				return pack;
			}
		}
	}
</script>

<style>
	.bordrad{
		width: 70rpx;
		height: 30rpx;
		background: #007AFF;
		border-radius: 50rpx;
	}
	.example-body {
		border-top: 1rpx #f5f5f5 solid;
		padding: 30rpx;
		background: #fff
	}
	.good_buy{
		display: flex;
		height:236rpx;
		box-sizing: border-box;
		background:white;
		margin: 20rpx 32rpx ;
		border-radius:15rpx;
	}
	.box{
	display: flex;
	align-items: center;
	margin-left:5rpx;
	}
	.buttonself{
 width: 160rpx;
	margin-left: 50rpx;
	align-self: flex-end;
	padding-bottom: 17rpx;

	}
	img{
	width:183rpx;
	height:183rpx;
	}
.Calculation{
	display: block;
	display: flex;
	flex-direction: row;
	flex-wrap: nowrap;
    padding: 0rpx 50rpx;
	justify-content:space-between;
	align-items: center;
	align-content: center;
	height: 100rpx;
	background:#FFFFFF;
	box-sizing: border-box;
	margin-bottom: 90rpx;/* 这个用于解决下单按钮居于底部无法显示 */
}
.Calculation button{
	background: #3CC075;
	color: #F8F8F8;
}
.Count_down{
		width: 100%;
		height:60rpx;
		background:rgba(242,85,118,1);
		opacity:0.44;
		border-radius:12rpx;
	}
	.sele{
		background: url("https://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-%20disabled.png");
	}
	.seleav{
		background: url("https://yhx-img.oss-cn-hongkong.aliyuncs.com/sqtg-item/shopcart/icon-selected.png");
	}
</style>
