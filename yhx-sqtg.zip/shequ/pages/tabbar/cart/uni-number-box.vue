<template>
	<view class="uni-numbox">
		<view :class="{'uni-numbox--disabled': inputValue <= min || disabled}" class="uni-numbox__minus" @click="_calcValue('minus')">-</view>
		<input disabled="false" v-model="username" class="uni-numbox__value" type="number">
		<view :class="{'uni-numbox--disabled': inputValue >= max || disabled}" class="uni-numbox__plus" @click="_calcValues('plus')">+</view>
	</view>
</template>
<script>
	export default {
		name: 'UniNumberBox',
		props: {
			value: {
				type: [Number, String],
				default: 1
			},
			min: {
				type: Number,
				default: 0
			},
			max: {
				type: Number,
				default: 100
			},
			step: {
				type: Number,
				default: 1
			},
			disabled: {
				type: Boolean,
				default: false
			},
			username:{
				type: [Number],
				default: 1
			},
			good_ids:{//父组件传来的商品id
				type: [Number],
			},
			good_stock:{
				type: [Number],
			}
		},
		watch: {
			username(newVal, oldVal) {
				if (+newVal !== +oldVal) {
					this.$emit('change', newVal)
				}
			}
		},
		methods: {
			_calcValue(type) {
				this.$emit('reduces',this.good_ids)
		/* this.inputValue=this.username.good_order_num */
				this.$emit("accept",this.username)
				if (this.disabled) {
					return
				}
				const scale = this._getDecimalScale()
				let value = this.username * scale
				let step = this.step * scale
				if (type === 'minus') {
					value -= step
				} else if (type === 'plus') {
					value += step
				}
				if (value < this.min || value > this.max) {
					return
				}
				this.username = value / scale
			},
			_calcValues(type) {
					if (this.disabled) {
						return
					}
					const scale = this._getDecimalScale()
					let value = this.username * scale
					let step = this.step * scale
					if (type === 'minus') {
						value -= step
					} else if (type === 'plus') {
						value += step
					}
					if (value < this.min || value > this.max) {
						return
					}
					this.username = value / scale
					if(this.username>=this.good_stock){//如果超过的库存则不回调+的事件
					uni.showToast({
					    title: '库存不足',
					    duration: 2000
					});
					this.username=this.good_stock;
						return false
					}
					this.$emit('adds',this.good_ids)
					/* this.inputValue=this.username.good_order_num */
							this.$emit("accept",this.username)
				},
			_getDecimalScale() {
				let scale = 1
				// 浮点型
				if (~~this.step !== this.step) {
					scale = Math.pow(10, (this.step + '').split('.')[1].length)
				}
				return scale
			},
		},
	}
</script>
<style>
	@charset "UTF-8";

	.uni-numbox {
		display: inline-flex;
		flex-direction: row;
		justify-content: flex-start;
		height: 50upx;
		position: relative
	}

	.uni-numbox:after {
		content: '';
		position: absolute;
		transform-origin: center;
		box-sizing: border-box;
		pointer-events: none;
		top: -50%;
		left: -50%;
		right: -50%;
		bottom: -50%;
		border: 1px solid #c8c7cc;
		border-radius: 60upx;
		transform: scale(.5)
	}

	.uni-numbox__minus{
		margin: 0;
		background-color: #f8f8f8;
		width: 50upx;
		font-size: 40upx;
		height: 100%;
		border-radius: 30upx 0upx 0upx 30upx;
		line-height: 70upx;
		text-align: center;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		color:#3CC075;
		position: relative
	}
	.uni-numbox__plus {
		margin: 0;
		background-color: #f8f8f8;
		width: 50upx;
		font-size: 40upx;
		height: 100%;
		border-radius: 0upx 30upx 30upx 0upx;
		line-height: 70upx;
		text-align: center;
		display: inline-flex;
		align-items: center;
		justify-content: center;
		color:#3CC075;
		position: relative
	}

	.uni-numbox__value {
		position: relative;
		background-color: #fff;
		width: 65upx;
		height: 100%;
		text-align: center;
		font-size:35rpx;
	}

	.uni-numbox__value:after {
		content: '';
		position: absolute;
		transform-origin: center;
		box-sizing: border-box;
		pointer-events: none;
		top: -50%;
		left: -50%;
		right: -50%;
		bottom: -50%;
		border-style: solid;
		border-color: #c8c7cc;
		border-left-width: 1px;
		border-right-width: 1px;
		border-top-width: 0;
		border-bottom-width: 0;
		transform: scale(.5)
	}

	.uni-numbox--disabled {
		color: silver
	}
</style>