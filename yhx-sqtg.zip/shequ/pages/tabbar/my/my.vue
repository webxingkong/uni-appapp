<template>
	<view>
			<view class="head">
<view><view class="Head_image1 tc " @click="to_login()"><image :src="head_img" class="Head_image mt10"></image></view></view>
				<view style="margin-left:40%;border: 1px solid #FFFFFF; border-radius: 15rpx;width:150rpx;text-align: center; color:#FFFFFF; font-size:25rpx;" @click="toequity()">{{Grade}}</view>
				<!--头像按钮-->
				<view class="Nickname mt5 f30 tc my-color1"><text>{{wx_name}}</text></view>
				<!--名称-->
				<view class="balance mt20 ft20 my-color1">
					<navigator url="balance/balance">
						<view class="Juxtaposition tc l di">
							<text>{{user_money}}</text>
							<br />
							<text>余额</text>
						</view>
				</navigator>
					<!--余额-->
					<navigator url="Coupon/Coupon">
						<view class="Juxtaposition tc l di">
							<text>{{coupon_sum}}</text>
							<br />
							<text>优惠劵</text>
						</view>
					</navigator>
					<!--优惠劵-->
					<navigator url="integral/integral">
						<view class="Juxtaposition tc l di">
							<text>{{cumulative_integrals}}</text>
							<br />
							<text>积分</text>
						</view>
					</navigator>
					<!--积分-->
				</view>
			</view>
			<!--绿色部分-->
			<view class=" Integral_module my-margin" style="margin-top: 16rpx;">
				<view class="headline f28 my-margin">
					<text style="color: #333333; font-size: 28rpx; font-weight: bold;">我的全部订单</text>
					<text style="color: #666666; font-size: 28rpx; float: right;" @click="to_Orders()">查看全部订单</text>
				</view>
				<view>
					<view class="text_center l tc mt30" @click="Pending_payment()">
						<view class="iconfont my-margin">&#xe704;</view>
					<view class=" f24 mt30" ><text>待付款</text></view>
					</view>
					<view class="text_center l tc mt30" @click="In_stock()">
						<view class="iconfont my-margin">&#xe638;</view>
						<view class="f24 mt30"><text>备货中</text></view>
					</view>
					<view class="text_center l tc mt30"  @click="Waiting_delivery()">
						<view class="iconfont my-margin">&#xe64f;</view>
						<view class="f24 mt30"><text>待取货</text></view>
					</view>
					<view class="text_center l tc mt30" @click="After_sale()">
						<view class="iconfont my-margin">&#xe70b;</view>
						<view class="f24 mt30"><text>售后</text></view>
					</view>
				</view>
			</view>
			<!--订单部分-->
			<view class=" Integral_module my-margin" style="height: 358rpx;">
				<view class="headline f28 my-margin"><text style="font-weight: bold;">扫码取货</text></view>
				<view class=" tc mt20"><image src="../../../static/123.jpg" style="width: 240rpx; height: 236rpx;"></image></view>
			</view>
			<!--扫码部分-->
			<view class=" Integral_module my-margin" style="height: 230rpx;">
				<view class="headline f28 my-margin"><text style="font-weight: bold;">常用工具</text></view>
				<view>
					<view class="text_center l tc mt30" @click="Select_regiment()">
						<view class="iconfont my-margin">&#xe61b;</view>
						<view class="f24 mt30" ><text>选团长</text></view>
					</view>
					<view class="text_center l tc mt30" @click="to_Recommend()">
						<view class="iconfont my-margin">&#xe686;</view>
						<view class="f24 mt30"><text>推荐有奖</text></view>
					</view>
					<view class="text_center l tc mt30">
						<view class="iconfont my-margin">&#xe610;</view>
						<view class="f24 mt30"><text>设置</text></view>
					</view>
					<navigator url="address/address">
						<view class="text_center l tc mt30">
							<view class="iconfont my-margin">&#xe670;</view>
							<view class="f24 mt30"><text>收货地址</text></view>
						</view>
					</navigator>
				</view>
			</view>
			<!--工具部分-->
			<view class=" Integral_module my-margin" style="height: 254rpx;">
				<view class="bottom_module1 f28 my-color my-border">
					<text style="">申请团长</text>
					<image src="../../../static/303.png" class="Arrow_img"></image>
				</view>
				<view class="bottom_module1 f28 my-color my-border" @click="toLife()">
					<text style="">生活服务</text>
					<image src="../../../static/303.png" class="Arrow_img"></image>
				</view>
				<view class="bottom_module2 f28 my-color my-border">
					<text style="">联系客服</text>
					<image src="../../../static/303.png" class="Arrow_img"></image>
				</view>
			</view>
			<!--联系和申请部分-->
		
	</view>
	
</template>

<script>
	import api from '../../../api/api.js'
	import { mycenter } from '../../../api/conf.js'
export default{
	data(){
		return{
			wx_name:'',//用户名称
			Grade:'默认等级',
			"head_img":'../../../../static/index_img/user-img@2x.png',//用户头像,暂不使用服务端的头像
			user_money:0,//用户余额
			cumulative_integrals:0,//累计积分
			coupon_sum:0,//优惠卷数量
			rand_str:"",//生成的二维码字符串
			mydata:[],//用户信息
		}
	},
	
	onLoad() {
		 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
		 var usid=uid.usid;
		api.get(mycenter, {
		    user_id:usid,
		}).then(res => {
			this.wx_name=res.mycenter.wx_name;
				this.Grade=res.mycenter.Grade;
					this.head_img=res.mycenter.head_img;
						this.user_money=res.mycenter.user_money;
							this.cumulative_integrals=res.cumulative_integrals.wx_name;
								this.coupon_sum=res.mycenter.coupon_sum;
									this.rand_str=res.mycenter.rand_str;
			
		}).catch(err => {
		    uni.showToast({
		        title: "数据异常",
		        icon: 'none'
		    })
		})
	},
	onShow() {
setTimeout(()=>{//延迟读取用户头像
	let that=this;
	const img = uni.getStorageSync('usidimg_key');
	that.head_img=img;
},500)
	},
	methods:{//推荐有奖
		to_Recommend(){
			uni.navigateTo({
			    url: '/pages/tabbar/my/Recommended/recommended'
			});
		},//查看所有订单
		to_Orders(){
			uni.navigateTo({
			    url: '/pages/tabbar/index/toplist?id=0'
			});
		},
		to_login(){
			uni.navigateTo({
			    url: '/pages/authorize/authorize'
			});
		},
		//会员权益
		toequity(){
			uni.navigateTo({
			    url: '/pages/tabbar/my/Equity/equity'
			});
		},
		toLife(){//生活服务
			uni.navigateTo({
			    url: '/pages/tabbar/my/Life/Life'
			});
		},
		Select_regiment(){
			/* 跳转至选择团长页面 */
			uni.navigateTo({
			    url: '/pages/pay/choosecommander'
			});
		},//订单列表
		Pending_payment(){
			uni.navigateTo({
			    url: '/pages/tabbar/index/toplist?id=1'//传递下标和名称
			});
		},
		In_stock(){
			uni.navigateTo({
			    url: '/pages/tabbar/index/toplist?id=2'//传递下标和名称
			});
		},
		Waiting_delivery(){
			uni.navigateTo({
			    url: '/pages/tabbar/index/toplist?id=5'//传递下标和名称
			});
		},
		After_sale(){
			uni.navigateTo({
			    url: '/pages/tabbar/index/toplist?id=8'//传递下标和名称
			});
		},
		},
	}
</script>
<style>
.Arrow_img {
	height: 45rpx;
	width: 45rpx;
	float: right;
} /*箭头-图片*/
.Juxtaposition {
	width: 33.3%;
	height: auto;
} /*余额,优惠劵,积分-并列*/
.bottom_module2 {
	margin: auto;
	position: relative;
	top: 28rpx;
	margin-top: 18rpx;
	height: 58rpx;
	border: none;
	width: 94%;
} /*联系-客服*/
.bottom_module1 {
	margin: auto;
		position: relative;
		top: 28rpx;
		margin-top: 18rpx;
		height: 58rpx;
		border-bottom: solid 2rpx #f4f4f4; /* 下划线 */
		width: 94%;
} /*申请-团长*/
.text_center {
	 width: 24.3%;
} /*并-列*/
.headline {
	height: 50rpx;
	border-bottom: solid 2rpx #f4f4f4; /* 下划线 */
	width: 94%;
	margin-top: 30rpx;
} /* 标题居-中加粗 */
.iconfont {
	font-size: 56rpx;
	width: 68rpx;
	height: 58rpx;
} /* 矢量-图标 */
.head {
	width: 100%;
	height: 400rpx;
	background-color: #3cc075;
} /* 背-景色 */
.Head_image {
	width: 126rpx;
	height: 126rpx;
	border-radius: 50%; /*把图片调圆形*/
	border: solid 18rpx #36ab68;
} /* 头像-图片 */

.Integral_module {
	width: 686rpx;
	height: 230rpx;
	border-radius: 12rpx;
	background-color: #ffffff;
} /* 我的订单 */
</style>
