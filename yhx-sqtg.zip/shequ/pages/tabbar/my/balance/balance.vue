<template>
	<view>
		<view class="Assets_DIV">
			<view class="Assets rel my-radius my-margin">
				<view class="Assets_element f24 rel"><text>总资产（元）</text></view>
				<view class="element rel font-lg"><text>{{balance.balance}}</text></view>
			</view>
			<!--绿色资产部分-->
			<view class="query tc f28 l" style=" border-right: ridge 2rpx #C9C7C7;">
				<view class="iconfont">
					&#xe63a;
					<text>交易查询</text>
				</view>
			</view>
			<view class="query tc f28 l">
				<view class="iconfont">
					&#xe604;
					<text>充值卡兑换</text>
				</view>
			</view>
			<!--绿色下面部分-->
		</view>
		<view class="Recharge_amount mt20" >
			<view class="Recharge_amount_text">
				<view class="Recharge_amount_text1 f28 rel"><text>充值金额</text></view>
			</view>
			<!--充值金额文字部分-->
			<view class="Recharge f28 l ml30 mt30" v-for="(item,index) in balance.Recharge" :key="index" @click="seceticon(index)">
				<image :src="[isActive==index ?  secetiocns:secetiocn]" class="img abs"></image>
				<view class=" mt30 tc rel "><text>充值{{item.Recharge_numer}}￥</text></view>
			</view>
		</view>
		<!--充值金额-->
		<view class="Immediate_recharge mt20">
			<navigator>
				<view class="Recharge_button my-radius my-margin">
					<view class="Immediate_recharge_text tc rel f28 my-color1" @click="to_Recharge()"><text>立即充值</text></view>
				</view>
			</navigator>
		</view>
		<!--立即充值-->
	</view>
</template>
<script>
	import api from '../../../../api/api.js'
	import { balance } from '../../../../api/conf.js'
export default {
	data() {
		return {
			"isActive":'',
			balance:[],//后台存储的余额数据
			secetiocn:'../../../../static/balance/icon-4.png',/* 选中的图片 */
			secetiocns:'../../../../static/balance/icon-3.png'/* 未选中的图片 */
		};
	},
	methods: {
		to_Recharge(e){
			
			uni.showToast({
			    title: '充值成功',
				icon:'none',
			    duration: 3000
			});
		},
		seceticon(e){
			this.isActive=e;
			uni.showToast({
			    title: '充值成功',
				icon:'none',
			    duration: 3000
			});
		}
	},
	onLoad() {
	 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
	 var usid=uid.usid;
	api.get(balance, {
		uid:usid
		}).then(res => {
	this.balance = res.balance;
		}).catch(err => {
		console.log("数据错误")
		})
	}
};
</script>

<style>
.Vectorgraph {
	height: 28rpx;
	width: 28rpx;
}
.Assets_DIV {
	width: 750rpx;
	height: 282rpx;
	background-color: #ffffff;
} /*资产DIV大框*/
.Assets {
	width: 686rpx;
	height: 152rpx;
	background-color: #FF5E46;
	top: 11%;
} /*绿色DIV框*/
.Assets_element {
	color: #ffffff;
	width: 631rpx;
	height: 40rpx;
	margin: auto;
	top: 11%;
}
/*总资-产元*/
.element {
	color: #ffffff;
	width: 631rpx;
	height: 60rpx;
	margin: auto;
	top: 28%;
} /*00.0*/
.query {
	margin-top: 65rpx;
	width: 49%;
	color: #333333;
	/* border: solid 1rpx #007AFF; 定位框*/
}
/*交易查询*/
.Recharge_amount {
	width: 750rpx;
	height: 432rpx;
	background-color: #ffffff;
	/*等待添加背景的色*/
} /*充值金额板块*/
.Recharge_amount_text {
	width: 686rpx;
	height: 84rpx;
	border-bottom: solid 2rpx #c9c7c7; /* 下划线 */
	margin: auto;
} /*充值-金额*/
.Recharge_amount_text1 {
	top: 28%;
	color: #333333;
} /*充值金-额文字定位*/
.Recharge {
	width: 28.5%;
	height: 128rpx;
	color: #333333;
}
/*定-位框*/
.img {
	width: 200rpx;
	height: 128rpx;
} /*图-片*/
.Immediate_recharge {
	width: 750rpx;
	height: 432rpx;
	background-color: #ffffff;
	border: solid 1rpx #ffffff;
} /*充值-板块*/
.Recharge_button {
	width: 618rpx;
	height: 98rpx;
	background-color: #FF5E46;
	margin-top: 318rpx;
} /*定位充值按钮*/
.Immediate_recharge_text {
	top: 23rpx;
} /*定位立即充值*/
</style>
