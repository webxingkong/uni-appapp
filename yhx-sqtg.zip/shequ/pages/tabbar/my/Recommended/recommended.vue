<template>
	<view>
		
	<!-- 	首部推荐导航栏 -->
		<view  class="headbox">
			<view class="" style="padding: 10rpx;">
				<image :src="Recommend.commander_img" style="height: 140rpx;width: 140rpx; border-radius: 100%;"></image>
			</view>
			<view style="display: flex; flex-direction: column;padding-left: 20rpx;">
				<view>{{Recommend.Recommend_name}}</view>
				<view><i class="iconfont">&#xe63d;</i><text style="font-size: 26rpx; color:#D8D8D8;padding-left:15rpx;">{{Recommend.Recommend_default}}</text></view>
			</view>
			<image src="../../../../static/commodity_icon/share.png" style="position: absolute; height: 60rpx;width: 178rpx; padding-left: 580rpx;"></image>
		</view>
		
		<!-- 	推荐列表部分 -->
		<view style="display:flex;justify-content: center;">
			<!-- 	第一栏 -->
			<view class="Recommend">
				<view>
					推荐奖励
				</view>
				<view style="color:#F25C7C ;">
					{{Recommend.Recommend_reward}}
				</view>
			</view>
			<!-- 	第二栏 -->
			<view class="Recommend">
				<view>
					推荐奖励
				</view>
				<view style="color:#F25C7C ;">
					{{Recommend.Recommend}}
				</view>
			</view>
			
		</view>
	<!-- 	账户表 -->
		<view style="display: flex;justify-content: center;margin-top: 20rpx;">
			<view class="borderM"  style="background:#FF5F46;"><text class="borderh">账户</text></view>
			<view class="borderM"  style="background:#F0A323; margin: 0rpx 12rpx;"><text class="borderh">推荐列表</text></view>
			<view class="borderM"  style="background:#FF5F46;"><text class="borderh">推荐明细</text></view>
		</view>
		
		<!-- 规则说明 -->
		<view class="box-size" style="display: flex; flex-direction: column;justify-content: center;padding:60rpx 0rpx 0rpx 20rpx">
			<view><image src="../../../../static/icon-1.png" style="height: 40rpx; width: 40rpx;"></image><text style="padding-left: 30rpx;">规则说明</text></view>
			<view style="height: 1rpx;width:630rpx; background:#C9C7C7;margin: 0rpx 0rpx;padding-right: 60rpx;"></view>
		</view>
		
	</view>
</template>

<script>
	import api from '../../../../api/api.js'
	import { Recommend } from '../../../../api/conf.js'
	export default{
		data(){
			return{
				"Recommend":[]
			}
		},
		onLoad() {
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var usid=uid.usid;
			api.get(Recommend, {
			    user_id:usid,
			}).then(res => {
				this.Recommend=res.Recommend;
			}).catch(err => {
			    uni.showToast({
			        title: "数据异常",
			        icon: 'none'
			    })
			})
		}
	}
</script>

<style>
	/* 头部样式 */
	.headbox{
		margin:32rpx;
		 display: flex;
		 align-items: center; 
		 background:#FFFFFF; 
		 border-radius:15rpx;
		 box-sizing: border-box;
		 box-shadow:0px 6px 4px 0px rgba(76,175,56,0.06);
	}
	/* 推荐奖励css */
	.Recommend{
		margin-left: 10rpx;
		width:336rpx;
		height:188rpx; 
		background:#FFFFFF;
		display: flex;
		justify-content: center;
		align-items: center;
		flex-direction: column; 
		border-radius: 15rpx;
	}
	.borderM{
		height:90rpx; width:220rpx;
		color:#FFFFFF;
		border-radius:15rpx;text-align:center;
		border-radius:15rpx;text-align:center;
	}
	.borderh{
		line-height:90rpx 
	}
	page{
		background: #F4F4F4;
	}
	@font-face {
	  font-family: 'iconfont';  /* project id 1395133 */
	  src: url('//at.alicdn.com/t/font_1395133_ntttl3l9ts.eot');
	  src: url('//at.alicdn.com/t/font_1395133_ntttl3l9ts.eot?#iefix') format('embedded-opentype'),
	  url('//at.alicdn.com/t/font_1395133_ntttl3l9ts.woff2') format('woff2'),
	  url('//at.alicdn.com/t/font_1395133_ntttl3l9ts.woff') format('woff'),
	  url('//at.alicdn.com/t/font_1395133_ntttl3l9ts.ttf') format('truetype'),
	  url('//at.alicdn.com/t/font_1395133_ntttl3l9ts.svg#iconfont') format('svg');
	}
	.iconfont{
	    font-family:"iconfont" !important;
	    font-size:16px;font-style:normal;
	    -webkit-font-smoothing: antialiased;
	    -webkit-text-stroke-width: 0.2px;
	    -moz-osx-font-smoothing: grayscale;}
</style>
