<template>
	<view>
		<view class="uni-tab-bar">
	<scroll-view scroll-x class="uni-swiper-tab">
		<block v-for="(item,index) in tabBars" :key="index">
		<view class="swiper-tab-list" :class="{'active':tapIndex==index}" @tap="tabswper(item.id,index)">
			{{item.name}}
			<view class="Line"></view>
		</view>
		</block>
	</scroll-view>
	</view>
		<!--展示区域-->
    <view class="siper_item" v-for="(item,index) in goodListdata" :key="index"  v-if="switchs">
		<view  class="item_name"><view>{{item.orderleader.community_name}}</view><view>{{item.order_state}}</view></view>
		<view style="width: 100%;height: 0.5rpx;background:#F4F4F4;"></view>
		<view class="item_img"><image :src="item.order_product.img_url" style="height:165rpx; width: 165rpx;" mode="数据异常"></image>共{{item.order_good_number}}件</view>
		<view style="width: 100%;height:2rpx;background:#F4F4F4;"></view>
		<view style="display: flex;align-items: center;margin:5rpx; 0rpx">
		<text class="btnmode">{{item.transport_type}}</text>
		<text style="margin-left:50rpx;">付款金额:<text style="color: #FF0000;padding-left:20rpx;">￥{{item.pay_money}}</text></text>
		<text style="margin-left:30%;border:1px solid #666666;border-radius: 15rpx;color:#666666;font-size:25rpx;">查看详情</text>
		</view>
	</view>
	<text style="color:#999999 ;display: flex;justify-content: center;"  v-if="switchs">{{title}}</text>
	<view v-else style="display: flex; justify-content: center;margin-top:250rpx;">
		<image src="./../../../static/static_img/img-3.png"></image>
	</view>
		</view>
</template>

<script>
	import api from '../../../../api/api.js'
	import { Life } from '../../../../api/conf.js'
	export default{

		data(){
			return{
				switchs:true,//判断页面是否有数据，显示空页面
				"title":'已经到底了',
				"tapIndex":"", //tap选择的下标
				"Initialization":"whole",//进入页面时加载的第一步数据
				"goodListdata":[],
				tabBars:[
					{name:'全部',
					id:"whole"},
					{name:'待付款',
					id:"Pending_payment"},
					{name:'待核销',
					id:"cancellation"},
					{name:'已完成',
					id:"Completed"},
					{name:'售后',
					id:"After_sale"},
					],
			}
		},

		methods:{
			tabswper(e,v){//下标和id
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var usid=uid.usid;
				this.tapIndex=v;
				api.get(Life, {
					company_id:e,
					user_id:usid,
					}).then(res => {
				     this.goodListdata = res.orderList;
					 console.log(res.orderList)
					 if(res.orderList==""){//空数据的时候
					 this.switchs=false;
					 }
					}).catch(err => {
				uni.showToast({
					title: '获取数据失败',
					icon: 'none'
				});
						})
			}
		},
		onLoad() {
				api.get(Life, {
					company_id:this.Initialization,
					user_id:1,
					}).then(res => {
						console.log(res)
				     this.goodListdata = res.orderList;
					 if(res.orderList==""){//空数据的时候
                     this.switchs=false;
					 }
					 console.log(res.orderList)
					}).catch(err => {
				uni.showToast({
					title: '获取数据失败',
					icon: 'none'
				});
						})
		}
	}
</script>
<style>
	.siper_item{
		display: flex; 
		box-sizing: border-box;
		width:90%;
		background:#FFFFFF;
		 flex-direction:column;
		 justify-content:space-around;
		 align-content: center;
		 margin:25rpx 0rpx 25rpx 25rpx;
		 border-radius:15rpx;
		 margin-left:35rpx;
	}
	.swiper-tab-list :active{
		color: #FFFFFF;
	}
	.item_name{
		display: flex; 
		justify-content: space-between;
		flex-direction:row;
		margin:10rpx;
	}
	.btnmode{
		border:1px solid #8F8F94;
		color:#666666;
		padding-left: 5rpx;
		padding-right: 5rpx;
		border-radius:15rpx;
		font-size:25rpx;
		margin-left:10rpx;
	}
	.item_img{
		display: flex;
		 align-items: center;
		  justify-content: 
		  space-between;
		  padding-right: 15rpx;
	}
	.uni-tab-bar {
    background: #FF5E46;
		display: flex;
		flex: 1;
		flex-direction: column;
		overflow: hidden;
		height: 100%;
	}
	.uni-swiper-tab {
		width: 100%;
		white-space: nowrap;
		line-height: 100upx;
		height: 100upx;
		border-bottom: 1px solid #c8c7cc;
	}
	.swiper-tab-list {
		font-size: 30upx;
		width: 150upx;
		display: inline-block;
		text-align: center;
		color: #555;
	}
	.uni-tab-bar .active {
	    color: #FFFFFF;
	}
	.uni-uploader__input-box:active {
		border-color: #999999;
	}
	
	.uni-uploader__input-box:active:before,
	.uni-uploader__input-box:active:after {
		background-color: #999999;
	}
	.active .Line{
		margin-top: 15rpx;
		margin-left: 40rpx;
		height: 5rpx;
		width: 70rpx;
		background: #FFFFFF;
	}
   .page{background:#F4F4F4;}
</style>
