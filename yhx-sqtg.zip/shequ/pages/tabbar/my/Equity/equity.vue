<template>
	<view>
<!--头部信息-->
<view class="flex_wrap size box-size b_radisu b_color" style="width:686rpx;height:312rpx;margin: 0rpx auto;">
		<view class="flex_wrap size" style="align-items: center; justify-content:space-around;margin-left: 15rpx;">
		<view>
			<image :src="head_img" style="height: 124rpx; width: 124rpx; border-radius: 100%;"></image>
		</view>
		<view class="pl30">
			<view>{{wx_name}}</view>
			<view style="position: absolute;top:50rpx;right:50rpx; color: #666666;">累计积分:{{cumulative_integrals}}</view>
			<view style="margin-top:5rpx;"><button class="btn">{{user_level_name}}</button></view>
			
		</view>
		</view>
		<view class="flex  box-size" style=" flex-direction:column;width:95%;">
			<view class="flex" style="justify-content:space-between; color: #666666;">
				<text>{{user_level_name}}</text>
				<text>{{next_level_name}}</text>
			</view>
             <view style="margin-left: 10rpx;">
                           <progress :percent="progress" activeColor="orangey" active stroke-width="6" />
                       </view>
			<view class="flex" style="justify-content:space-between; color: #666666;">
				<text>{{user_integrals}}</text>
				<text >{{next_conditions}}</text>
			</view>
		</view>
		
</view>
		<!--信息提示栏-->
	<view class="flex b_radisu b_color b_radisu mt20 Explain">
<view><text style="font-size: 26rpx; margin-left:25rpx;">您是{{user_level_name}}，距离下一个等级还有{{Surplus}}积分</text></view>
<view style="margin-top:10rpx;"><button class="btnExplain" @click="to_order()">下单获得积分</button></view>
	</view>
		
		
		<!--列表栏-->
		<view class="flex_wrap size box-size b_radisu  mt20" style="width:686rpx;  margin: 0rpx auto;background:;">
			<view class="flex box-size pl24 Memberbtn">
				<text style="padding-top:20rpx;padding-right: 10rpx;">会员等级</text>
				<text class="pl27">积分值</text>
				<text class="pl27">积分比率</text>
				<text style="padding-left:50rpx;padding-top:20rpx;">会员权益</text>
			</view>
			<view class="flex_lr_ms" style="width: 100%; height: 114rpx; color: #666666;">
				<view>注册会员</view>
				<view style="padding-left:30rpx;">0.0</view>
				<view style="padding-left:70rpx;">1:1</view>
				<view>购买商品享受无打折优惠</view>
			</view>
		<view class="flex_lr_ms" style="width: 100%; height: 114rpx; color: #666666;background: #F3D2CA;">
			<view>铜牌会员</view>
			<view style="padding-left: 20rpx;">1000.0</view>
			<view style="padding-left:40rpx;">1:1</view>
			<view>购买商品享受无打折优惠</view>
		</view>
		<view class="flex_lr_ms" style="width: 100%; height: 114rpx; color: #666666;">
			<view>铜牌会员</view>
			<view style="padding-left: 25rpx;">10000.0</view>
			<view style="padding-left: 30rpx;">1:1</view>
			<view>购买商品享受无打折优惠</view>
		</view>
		<view class="flex_lr_ms" style="width: 100%; height: 114rpx; color: #666666;background: #F3D2CA;">
			<view>金牌会员</view>
			<view>100000.0</view>
			<view>1:1</view>
			<view>购买商品享受9.5折优惠</view>
		</view>
		<view class="flex_lr_ms" style="width: 100%; height: 114rpx; color: #666666;">
			<view>金牌会员</view>
			<view>1000000.0</view>
			<view>1:1</view>
			<view>购买商品享受9.5折优惠</view>
		</view>
		</view>
		
		
	</view>
</template>

<script>
	import api from '../../../../api/api.js'
	import { membership } from '../../../../api/conf.js'
	export default{
		data(){
			return {
				progress:"",//滚动条进度
				cumulative_integrals:0,
				head_img: "",
				id:0,
				next_conditions: 1000,
				next_level_name: "铜牌会员",
				score_percentage: 1,
				upgrade_conditions: 0,
				user_integrals: 24,
				user_level_id: 2,
				user_level_name: "默认等级",
				wx_name: "昵称",
				
			}
		},
		onLoad(){
			/* 数据请求 */
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var usid=uid.usid;
			api.get(membership, {
					user_id:usid,
				}).then(res => {
			this.cumulative_integrals=res.cumulative_integrals;
			this.head_img=res.head_img;
			this.next_conditions=res.next_conditions;
			this.next_level_name=res.next_level_name;
			this.score_percentage=res.score_percentage;
			this.upgrade_conditions=res.upgrade_conditions;
			this.progress=this.user_integrals/this.next_conditions*100;
			this.user_integrals=res.user_integrals;
			this.user_level_id=res.user_level_id;
			this.user_level_name=res.user_level_name;
			this.wx_name=res.wx_name;
				}).catch(err => {
					uni.showToast({
						title: "数据异常",
						icon: 'none'
					})
				});
		},
		methods:{
			to_order(){
				uni.switchTab({
					 url: '/pages/tabbar/index/index'
				});
			}
		},
		computed:{
			Surplus(){
				 return this.next_conditions-this.user_integrals;
			}
		}
	}
</script>

<style>
	page{
		background:rgba(244,244,244,1);
	}
	.bg{
		padding:27rpx;
	}
	/* 等级按钮样式 */
	.btn{
		background:#FF5E46;
		height:50rpx; 
		width: 170rpx;
		font-size:25rpx;
		line-height:50rpx; 
		color: #F1F1F1;
	}
	/* 积分说明栏 */
	.Explain{
		width:686rpx;
		height:230rpx;
		 margin:20rpx auto;
		 flex-direction:column;
		  justify-content: center;
		  align-items: center;
	}
	/* 下单积分按钮 */
	.btnExplain{
		background:#FF5E46;
		height:60rpx;
		 width:200rpx;
		  font-size:20rpx;
		   line-height:60rpx; 
		   color: #F1F1F1;
		   border-radius:25rpx;
	}
	/* 会员等级按钮 */
	.Memberbtn{
		background: #FF5E46;
		width:720rpx; 
		height: 88rpx;
		 border-radius:15rpx 15rpx 0rpx 0rpx;
		  color: #F1F1F1;
	}
</style>
