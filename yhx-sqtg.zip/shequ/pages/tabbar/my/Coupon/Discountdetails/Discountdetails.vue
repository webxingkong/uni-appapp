<template>
	<view>
	<view class="Upper_frame mt15 my-radius my-margin">
	<view class="Upper_text1 ml15 f28 my-w65">
		<text>{{coupon_invalid_lists.coupon_name}}</text>
	</view>
	<view class="available_text my-margin">
	<view class="available mt30 f20  l ">
		<text>{{coupon_invalid_lists.coupon_des}}</text>
		</view>
		<view class="element mt30 f22 l rel " style="#333333">
			<text>￥</text>
		</view>
		<view class="One_yuan mt20 f28 l b" style="#333333">
		<text>{{coupon_invalid_lists.coupon_money}}</text>
	</view>
	</view>
	<view class="Lower_frame">
		<view class="time rel my-margin">
		<view class="time_text mt15 f20 l my-color0">
			<text>{{coupon_invalid_lists.valid_start_time}}--{{coupon_invalid_lists.valid_end_time}}</text>
		</view>
		<view class="time_text1 mt15 f20 l my-color0">
			<text>{{[coupon_invalid_lists.use_product==1? "指定商品可用" :coupon_invalid_lists.use_product==0? "所有商品使用" : "指定商品不可用"]}}</text>
		</view>
	</view>
	</view>
	<view class="Concave_Left my-br5 my-wh rel">
		</view><!--左边凹面角-->
		<view class="Concave_right my-wh my-br5 rel">
		</view><!--右边凹面角--><!--找两个圆盖住优惠劵虚线位置，实现凹角-->
			</view>
			<!--定位框-->
			<view class="details_box rel my-margin">
		<view class="Instructions mt-4">
			<view class="Instructions_text tc f24">
			<text>使用说明</text>
			</view>
		</view>
		<view class="First_order f20 my-color0 my-margin">
			<text>{{coupon_invalid_lists.coupon_des}}</text>
		</view>
		<view class="Instructions mt-4">
			<view class="Instructions_text tc f24 mt30">
			<text>使用条件</text>
			</view>
		</view>
		<view class="First_order f20 my-color0 my-margin">
			<text>{{coupon_invalid_lists.coupon_name}}</text>
		</view>
		<view class="Instructions mt-4">
			<view class="Instructions_text tc f24 mt30">
			<text>适用商品</text>
			</view>
		</view><!--说明。条件。商品部分-->
		<view class="img_box mt30 l my-radius" v-for="(item,index) in coupongood" :key="index">
			<view class="img_Centered tc">
			<image :src="item.good_img_url" class="img"></image>
		</view>
		<view class="Trade_name">
		<view class="weight">
			<text>{{item.good_name}}</text>
		</view>
		<view class="cope_with f24" style="color: #F25576;">
			<text>{{item.good_price}}</text>
		</view>
		</view>
		</view>

	</view><!--详情框-->
	<view class="Bottom_frame">
		<view class="bottom mt30 tc f22" style="color: #999999;">
			<text>已经到底部了</text>
		</view>
	</view>
	<!--底部-->
	</view>
</template>

<script>
	import api from '../../../../../api/api.js'
	import { couponInfo } from '../../../../../api/conf.js'
	export default {
		data() {
			return {
				"coupon_invalid_lists":[],//优惠卷信息
				"coupongood":[]//优惠卷详情
			}
		},
		methods: {
			
		},
		onLoad(option) {
			api.get(couponInfo, {
			    coupon_id:option.id,
			}).then(res => {
				this.coupon_invalid_lists=res;//优惠卷信息
				this.coupongood=res.coupon_apply_goods;//
			}).catch(err => {
			    uni.showToast({
			        title: "数据异常",
			        icon: 'none'
			    })
			})
		}
	}
</script>

<style>
	.img{
		width: 300rpx;height: 310rpx;
	}/*图片-大小*/
	.Trade_name{
		margin: auto;
		width: 260rpx;
	}/*商品-名称*/
	.img_box{
		width: 49.3%;
		height: 426rpx;
		color: #666666;
		border: solid 1rpx #f4f4f4;
		/* border: solid 1rpx #007AFF; */
	}/*定位-框*/
	.First_order{
		width: 550rpx;
		margin-top: 20rpx;
	}/*首单和无-门槛文本*/
	.Instructions_text{
		color: #FFFFFF;
	}/*使用说明文本*/
	.Instructions{
		width: 146rpx;
		height: 46rpx;
		background-color: #FF6846;
		border-top-right-radius: 50rpx;
		border-bottom-right-radius: 50rpx;
	}/*使用说明框*/
	.details_box{
		width: 650rpx;
		height: 1254rpx;
		top: 57rpx;
		background-color: #ffffff;
	}/*详情框*/
	.bottom{
	margin-top: 90rpx;
	}/*已到底部文本*/
	.Concave_Left{
		background-color: #F4F4F4;
		top: -87rpx;
		margin-left: -25rpx;
	}/*找两个圆盖住优惠劵虚线位置，实现凹角,左边*/
	.Concave_right{
		background-color: #F4F4F4;
		top: -137rpx;
		margin-left: 660rpx;
	}/*找两个圆盖住优惠劵虚线位置，实现凹角,右边*/
	.time_text1{
		width: 19%;
	}/*所有商品适用*/
	.time_text{
		width: 79.8%;
	}/*时间*/
	.time{width: 650rpx;
		height: 60rpx;
		top: 8rpx;
	}/*优惠劵使用时间*/
	.available_text{
		width: 650rpx;
		height: 95rpx;
		border-bottom: dashed 3rpx #C9C7C7;/* 下划线 */
	}/*定位可用和一元的框*/
	.available{
	width: 88%;
	color: #666666;
	}/*满10元可用*/
	.Upper_text1{
		height: 43rpx;
		color: #333333;
	}/*新人首单优惠劵*/
.Upper_frame{
	width: 686rpx;
	height: 206rpx;
	background-color: #ffffFF;
}/*优惠劵部分--框*/
</style>
