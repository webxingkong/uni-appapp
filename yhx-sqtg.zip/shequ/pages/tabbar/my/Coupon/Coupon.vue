<template>
	<view>
		<view v-if="isShow === 1">
	<view class="Upper_frame my-margin my-radius rel" v-for="(item,index) in coupon" :key="index" @click="to_coupondetails(item.coupon_id)">
				<view class="Upper_text1 ml20 f28 ">
					<text>{{item.coupon_title}}</text>
				</view>
				<view class="available_text my-margin">
				<view class="available ml15 f20 l rel mt30 my-color0">
					<text>{{item.coupon_des}}</text>
					</view>
					<view class="element mt30 f20 l rel my-c3">
						<text>￥</text>
					</view>
					<view class="One_yuan mt20 f28 l b my-c3">
					<text>{{item.coupon_ticket}}</text>
				</view>
				</view>
				<view class="Lower_frame">
					<view class="time my-margin rel">
					<view class="time_text mt15 l f20 my-color0">
						<text>{{item.coupon_termStart}}--{{item.coupon_termEnd}}</text>
					</view>
					<view class="time_text1 mt15 l f20 my-color0">
						<text>{{[item.coupon_criteria==1? "指定商品可用" :item.coupon_criteria==0? "所有商品使用" : "指定商品不可用"]}}</text>
					</view>
				</view>
				</view>
		<view class="Concave_Left rel my-wh my-br5">
		</view><!--左边凹面角-->
		<view class="Concave_right rel my-wh my-br5">
		</view><!--右边凹面角--><!--找两个圆盖住优惠劵虚线位置，实现凹角-->
			</view>
			<!--定位框-->
	<view class="Bottom_frame my-margin rel my-w65">
		<view class="Be_overdue f20 tc" style="color: #666666;">
			<navigator>
		<text>查看过期劵></text>
			</navigator>
		</view>
		<br>
		<view class=" mt30 tc f22" style="color: #999999;">
		<text>已经到底部了</text>
	    </view>
	</view>
	</view>
	<!-- 暂无数据状态 -->
	<view class="state" v-if="isShow === 2">
		<image src="../../../../static/static_img/img-4.png"></image>
		<view style="font-size:55rpx; color: #47CB7D; font-weight: bold;">暂无数据</view>
	</view>
	<!-- 暂无网络状态 -->
	<view class="state" v-if="isShow === 3">
		<image src="../../../../static/static_img/img-1.png"></image>
		<view style="font-size:55rpx; color: #47CB7D; font-weight: bold;">暂无网络</view>
	</view>
	</view>
</template>

<script>
	import api from '../../../../api/api.js'
	import { couponLists } from '../../../../api/conf.js'
	export default {
		data() {
			return {
				isShow:1,
				coupon:[]
			}
		},
		methods: {//优惠卷详情页
			to_coupondetails(id){
				uni.navigateTo({
				    url: '/pages/tabbar/my/Coupon/Discountdetails/Discountdetails?id='+id
				});
			}
		},
		onLoad() {
			uni.onNetworkStatusChange(function (res) {//如果网络状态等于true则显示无网络状态
			console.log(res.isConnected)
				if(res.isConnected==false){
					this.isShow=3;
				}
			});
			 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			 var usid=uid.usid;
			api.get(couponLists, {
			    user_id:usid,
			}).then(res => {
				this.coupon=res.coupon_valid_lists;
				if(res.coupon_valid_lists==""){
					this.isShow=2;
				}
			}).catch(err => {
				this.isShow=3;
			    uni.showToast({
			        title: "数据异常",
			        icon: 'none'
			    })
			})
		},
	}
</script>

<style>
	/* 网络状态和数据状态页面css */
	.state{
		display: flex;
		 justify-content: center;
		 flex-direction: column; 
		 align-items: center;
		 align-content: center; 
		 margin-top:250rpx;
	}
	.Bottom_frame{
		height: 180rpx;
				top: 66rpx;
	}/*过期劵和底部框*/
	.Concave_Left{
		background-color: #F4F4F4;
		top: -27rpx;
		margin-left: -25rpx;
	}/*找两个圆盖住优惠劵虚线位置，实现凹角,左边*/
	.Concave_right{
		background-color: #F4F4F4;
		top: -77rpx;
		margin-left: 660rpx;
	}/*找两个圆盖住优惠劵虚线位置，实现凹角,右边*/
	.time_text1{
		width: 19%;
	}/*所有商品适用*/
	.time_text{
		width: 79.8%;
	}/*时间*/
	.time{width: 650rpx;
		top: 8rpx;
	}/*优惠劵使用时间*/
	.available_text{
		width: 650rpx;
		height: 90rpx;
		border-bottom: dashed 3rpx #C9C7C7;/* 下划线 */
	}/*定位可用和一元的框*/
	.element{
		width: 4%;
	}/*元*/
	.available{
	width: 85%;
	}/*满10元可用*/
	.One_yuan{
	width: 5%;
	}/*1.0元*/
.Upper_frame{
	overflow: hidden;
	width: 686rpx;
	height: 206rpx;
	background-color: #ffffFF;
	top: 20rpx;
	margin-bottom: 15rpx;
}/*优惠劵部分--框*/

</style>
