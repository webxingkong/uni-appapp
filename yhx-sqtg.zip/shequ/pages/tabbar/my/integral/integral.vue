<template>
	<view>
		<view class="frame my-margin my-radius">
			<view class="integral_text ml10">
			<view class=" font-lg mt30 tc my-color1">
				<text>积分</text>
				</view>
			</view>
			<view class="text1 f26 tc mt30 l">
			<text>{{integral.cumulative_integrals}}</text>
			<br>
			<text>累计积分</text>
			</view>
			<view class="text1 f26 tc mt30 l">
				<text>{{integral.user_integrals}}</text>
				<br>
				<text>可用积分</text>
			</view>
			<!--文本部分-->
			<view>
			<image class="Head_portrait" :src="integral.head_img"></image>
			</view>
			<view class="Yellow_floor my-radius">
	<view class="Grade my-margin my-radius">
		<view class=" f24 my-margin">
			<text>{{integral.user_level_name}}</text>
		</view>
		</view>
		</view>
		</view>
		<!--上面为绿色板块-->
		<view class="Explain my-margin">
			<view><image src="../../../../static/icon-1.png" style="height: 40rpx; width: 40rpx;"></image>
			<text style="color: #333333;">规则说明</text>
			</view>
		</view>
		<!--规则说明-->
		<view class="consumption my-margin my-radius" v-for="(item,index) in score_Explain" :key="index">
			<view class="consumption_text ml30 mt30">
			<text>{{item.score_Explains}}</text>
			</view>
		</view>
		<!--规则下的积分说明-->
	</view>
</template>

<script>
	import api from '../../../../api/api.js'
	import { integral } from '../../../../api/conf.js'
	export default {
		data() {
			return {
				integral:[],//获取的积分数据
				"score_Explain":[]//规则说明
			}
		},
		methods: {
			
		},
		onLoad() {
		 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
		 var usid=uid.usid;
			api.get(integral, {
			  user_id:usid
			}).then(res=>{
				this.integral=res.integral;
			}).catch(err => {
				
			})
		}
	}
</script>

<style>
	.consumption{
		width: 686rpx;
		height:58rpx;
		background-color: #E9E8E8;
		color: #999999;
	}/*规则说明中的积分说明*/
	.Explain{
		width: 686rpx;
		height: 50rpx;
		margin-top:20rpx;
		color: #3CC075;
	}/*规则说明*/
.frame{
	width: 686rpx;
	height: 283rpx;
background: linear-gradient(to right,#FF7C5E, #FF6947);
}/*积分绿色板块*/
.integral_text{
height: 108rpx;
width:182rpx;
}/*积分文本定位框*/
.text1{
	color: #ffffff;
	width: 28.5%;
	height: 128rpx;
}/*累计和可用--并列*/
.Head_portrait{
	width: 150rpx;
	height: 150rpx;
	border-radius: 50%;
	margin-top: -76rpx;
	margin-left: 115rpx;	
}/*头像*/
.Grade{
	width: 100rpx;
}/*默认等级辅助框*/
.Yellow_floor{
	width: 125rpx;
	margin-left: 520rpx;
	background-color: #FEA525;
}/*默认等级的背景色以及一些调整*/
</style>
