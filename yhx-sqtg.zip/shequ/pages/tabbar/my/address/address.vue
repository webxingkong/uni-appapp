<template>
	<view>
		<view class="content">
			<view class="list">
				<view class="row" v-for="(row,index) in addressList" :key="index" @click="setstrog(row)">
					<view class="center">
						<view class="name-tel">
							<view class="name">{{row.user_name}}</view>
							<view class="tel">{{row.user_mobile}}</view>
							<view class="default" v-if="row.is_default">
								默认
							</view>
						</view>
						<view class="address">
						{{row.provincial_address}}  {{row.address}}
						</view>
					</view>
					<view style="position: absolute;right:9%;" @click="to_editadd(row.id)"><i class="iconfont">&#xe73f;</i></view>
				</view>
				
			</view>
		</view>
		<view class="add">
			<view class="btn" @tap="add">
				<view class="icon tianjia"></view>新增地址
			</view>
		</view>
	</view>
</template>
<script>
	import api from '../../../../api/api.js'
	import { userAddress } from '../../../../api/conf.js'
		import { addressDefault } from '../../../../api/conf.js'
	export default {
		data() {
			return {
				iocn:true,
				isSelect:false,
				option_id:'',//目前选择的id
				addressList:[]
			};
		},
		onShow() {
	this.reqdata();
		},
		onLoad(option) {
			this.option_id=option.palceorder;
       this.reqdata();
		},
		methods:{
		add(){
			uni.navigateTo({
			    url: '/pages/tabbar/my/address/new_address'
			});
		},
		setstrog(row){
      var _THis=this;
			//设为默认地址
			const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			var usid=uid.usid;
			api.post(addressDefault, {
			 id:row.id,
			 user_id:usid,
			 is_default:1
			}).then(res=>{
				this.reqdata()
			}).catch(err => {
			})
			if(_THis.option_id==1){//判断是否来自提交订单页面
				//存储用于提交订单读取
				 uni.setStorageSync('address_key', row);//存储选择的地址id
				 uni.showLoading({
					 title: '地址选择成功',
					  duration: 3000
				 });//提示
				 uni.navigateTo({//跳转
					 url: '/pages/placeorder/placeorder?add=true&&swith=false'
				 });
			}		 
		},
		to_editadd(id){//编辑跳转的话传递参数表示可删除(新增地址不能删除)
			uni.navigateTo({
			    url: '/pages/tabbar/my/address/Edit_address?id='+id//修改标识
			});
		},
		reqdata(){//第一次页面调用的数据
			const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
			var usid=uid.usid;
		api.get(userAddress, {
		 user_id:usid,
		}).then(res=>{
			this.addressList=res.addressList;
		}).catch(err => {
		})
		},
	},

	}
</script>

<style lang="scss">
	@font-face {
	  font-family: 'iconfont';  /* project id 1395133 */
	  src: url('http://at.alicdn.com/t/font_1395133_agq9glrax1v.eot');
	  src: url('http://at.alicdn.com/t/font_1395133_agq9glrax1v.eot?#iefix') format('embedded-opentype'),
	  url('http://at.alicdn.com/t/font_1395133_agq9glrax1v.woff2') format('woff2'),
	  url('http://at.alicdn.com/t/font_1395133_agq9glrax1v.woff') format('woff'),
	  url('http://at.alicdn.com/t/font_1395133_agq9glrax1v.ttf') format('truetype'),
	  url('http://at.alicdn.com/t/font_1395133_agq9glrax1v.svg#iconfont') format('svg');
	}
@font-face {
  font-family: 'iconfont';  /* project id 1395133 */
  src: url('//at.alicdn.com/t/font_1395133_sagblcflwa.eot');
  src: url('//at.alicdn.com/t/font_1395133_sagblcflwa.eot?#iefix') format('embedded-opentype'),
  url('//at.alicdn.com/t/font_1395133_sagblcflwa.woff2') format('woff2'),
  url('//at.alicdn.com/t/font_1395133_sagblcflwa.woff') format('woff'),
  url('//at.alicdn.com/t/font_1395133_sagblcflwa.ttf') format('truetype'),
  url('//at.alicdn.com/t/font_1395133_sagblcflwa.svg#iconfont') format('svg');
}
	.iconfont{
	    font-family:"iconfont" !important;
	    font-size:16px;font-style:normal;
	    -webkit-font-smoothing: antialiased;
	    -webkit-text-stroke-width: 0.2px;
	    -moz-osx-font-smoothing: grayscale;}
view{
	display: flex;
}
	.add{
		position: fixed;
		bottom: 0;
		width: 100%;
		height: 120upx;
		justify-content: center;
		align-items: center;
		.btn{
			box-shadow: 0upx 5upx 10upx rgba(0,0,0,0.4);
			width: 70%;
			height: 80upx;
			border-radius: 80upx;
			background-color: #3CC075;
			color: #fff;
			justify-content: center;
			align-items: center;
			.icon{
				height: 80upx;
				color: #fff;
				font-size: 30upx;
				justify-content: center;
				align-items: center;
			}
			font-size: 30upx;
		}
	}
	.list{
		flex-wrap: wrap;
		.row{
			border-radius: 15rpx;
			margin-top: 15rpx;
			width: 96%;
		
			padding: 20upx 2%;
		box-shadow: 3px 3px 9px #888888;;
			.left{
				width: 90upx;
				flex-shrink: 0;
				align-items: center;
			}
			.center{
				box-sizing: border-box;
				width: 100%;
				flex-direction:row;
				flex-wrap: wrap;
				.name-tel{
					align-items: baseline;
					.name{
						font-size: 34upx;
					}
					.tel{
						margin-left: 30upx;
						font-size: 24upx;
						color: #777;
					}
					.default{
						font-size: 22upx;
						background-color: #3CC075;
						color: #fff;
						padding: 0 18upx;
						border-radius: 24upx;
						margin-left: 20upx;
					}
				}
				.address{
					width: 100%;
					font-size: 24upx;
					align-items: baseline;
					color: #777;
				}
				
			}
		}
	}
</style>
