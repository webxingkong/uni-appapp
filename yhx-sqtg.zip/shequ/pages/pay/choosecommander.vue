<template>
	<view>
    <view class="uni-container" v-if="!show">
        <view class="current_location flex" style="flex-direction:column;">
			<view class="locaion_left">
				<image src="../../static/commodity_icon/address.png" style="width: 28rpx;height: 31rpx;margin-left: 25rpx;margin-top: 40rpx;"></image>
				<text style="font-size:35rpx;margin-left: 25rpx;">您当前的位置:<text style="font-size:30rpx;color: #666666;">{{dynamicIcon}}</text></text>
			</view>
			<view>
				<button class="positionbtn" type="primary" size="mini" @click="to_position()">位置选择</button>
			</view>
		</view>
		<view class="lacation_list" >
			<view class="location_top">
				当前团长
			</view>
			<view class="location_center flex">
				<view class="location_img flex">
					<image src="../../static/0907165353.png" style="width: 110rpx;height: 110rpx;"></image>
					<view style="margin-left: 19rpx;">
						<view style="font-size: 30rpx;">{{chooseCommanderdata.regiment_info.regiment_name}}</view>
						<view class="flex_wrap" style="">取货地址:{{chooseCommanderdata.regiment_info.regiment_address}}</view>
						<view style="margin-top: 10rpx;color: #666666;font-size: 28rpx;">距您:&nbsp;&nbsp;{{chooseCommanderdata.regiment_info.distance}}</view>
					</view>
				</view>
				<view class="location_address_img">
					<image src="../../static/commodity_icon/address.png" style="padding-right: 25rpx;"></image>
				</view>
			</view>
		</view>
		
		<view class="lacation_list" v-for="(item,index) in chooseCommanderdata.other_regiment_info" :key='index'>
			<view class="location_tops">
				附近团长
			</view>
			<view class="location_center flex">
				<view class="location_img flex">
					<image :src="item.regiment_img" style="width: 110rpx;height: 110rpx;margin-top:20rpx;"></image>
					<view style="margin-left: 19rpx;">
						<view style="font-size: 30rpx;">{{item.regiment_name}}</view>
						<view class="flex" >
							<view class="flex_wrap" style="">取货地址:{{item.regiment_address}}</view>
							<image class="address_img" src="../../static/commodity_icon/address.png" style=""></image>
						</view>
						<view class="flex" style="justify-content: space-between;">
							<text style="color: #666666;font-size: 28rpx;">距您:&nbsp;&nbsp;{{item.distance}}</text>
							<button class="paybutton" type="primary" @click="openPopup(item.distance,item.regiment_id)">就选这位</button>
						</view>
					</view>
				</view>
			</view>
			</view>
		</view>
		
		<!-- 未开启位置服务的页面 -->
		<view style="display: flex;flex-direction: column;align-items: center;margin-top:350rpx;"  v-if= "show">
			<view style="border: 2rpx solid #09BB07;color: #3DC076;width:200rpx;text-align: center;border-radius:25rpx;" @click="getLocal()">开启位置</view>
			<text style="margin-top:15rpx;color:#666666;">系统检测到您未开启位置授权服务，这将影响到您的正常使用，请开启！</text>
		</view>
 </view>
</template>
<script>
	import api from '../../api/api.js'
	import { chooseCommander } from '../../api/conf.js'
	import { checkedCommander } from '../../api/conf.js'
		var amapFile = require("../../common/amap-wx.js");
    export default {
        data() {
          return{
			  show:false,//控制位置权限页面的显示
			  dynamicIcon:'',//存储位置信息
			  "chooseCommanderdata":[],

		  }
        },
		onShow() {
		const _this = this;
			//每次显示页面重新加载位置实现最新的位置
			var myAmapFun = new amapFile.AMapWX({key:"e9f8f27c740f9cccf7cd083958685e52"});//位置服务
			myAmapFun.getRegeo({
			  success: (res) => {
		_this.dynamicIcon=res[0].name;
			  },
			  fail: function(info){
			    //失败回调
			  }
			});
		},
        onLoad() {//加载页面的时候判断是否授权位置如果授权则显示数据没收授权执行_this.getLocal();打开设置重新授权
		const _this = this;
			uni.getSetting({
			   success(res) {
				   var getposition=res.authSetting['scope.userLocation'];
				   if(getposition==false){
					   _this.show=true;
					  _this.getLocal();
				   }
				   else{
					    _this.show=false;
				   }
			   }
			}); 
			api.get(chooseCommander, {//页面数据请求
			}).then(res => {
				this.chooseCommanderdata=res;
			}).catch(err => {
			
			});
        },
        methods: { 
			            getLocal() {//打开设置授权
			                uni.openSetting({
			                    success: (res) => {
			                        if(res.authSetting) {
			                            var that = this
			                            uni.getLocation({
			                                type: 'gcj02',
			                                success: function (res) {
												  that.show=false;
			                                },
			                                fail:function(e){
			                                }
			                            });
			                        }
			                    }
			                })
			            },
			to_position(){
				
			uni.navigateTo({
				    url: '../get-location/get-location'
				});
			},
			openPopup(i,v){			
           var _THis=this;
	//i为团长的距离v为该团长的id
			    uni.showModal({//
			        title:"您选择的团长距离您"+i+"是否确定选择？",
			        success: function (res) {
            if (res.confirm) {
							 const uid=uni.getStorageSync('settionid_key');//读取用户id和团长id
							 var usid=uid.usid;
							api.post(checkedCommander, {
							   uid:usid,
							   lid:v,
							}).then(res => {
								console.log(_THis.res)
								uni.showToast({
									title: '成功选择该团长',
									duration: 900
								});
							   uni.switchTab({
								   url: '/pages/tabbar/index/index'
							   });
							}).catch(err => {
							
							})
            } else if (res.cancel) {  
               console.log('用户点击取消');  
            }  
			            }
			    });
			},

        }
    };
</script>

<style>
	/* 位置选择css */
	.positionbtn{
		font-size: 24rpx;
		border-radius: 22rpx;
		background: #FFFFFF;
		color: #3CC075;
		border: #3CC075 solid 2rpx;
		margin-top: 35rpx;
		margin-left:35%;
	}
	.uni-container{
		width: 686rpx;
	}
	
    .current_location{
		height: 192rpx;
		width: 100%;
		background: #FFFFFF;
		margin-left: 32rpx;
		margin-right: 32rpx;
		margin-top: 30rpx;
		border-radius: 12rpx;
	}
	.btn_buttom button{
		border-radius: 0 !important;
		width: 50%;
	}
	.m0{
		width: 674rpx;height: 394rpx;
	}
	.cancel{
		border: #C9C7C7 1px solid !important;border-right: #FFFFFF !important;color: #666666;font-weight: bold;
	}
	.sure{
		border: #C9C7C7 1px solid !important;font-weight: bold;
	}
	.presentation{
		width: 445rpx;font-size: 28rpx;margin-left: 110rpx;margin-top: 59rpx;
	}
	.lacation_list{
		height: 256rpx;
		background: #FFFFFF;
		margin-left: 32rpx;
		margin-top: 16rpx;
		margin-right: 32rpx;
		width: 100%;
		border-radius: 12rpx;
	}
	.location_tops{
		width: 120rpx;height: auto;background: #8CB739;color: #FFFFFF;border-radius: 12rpx 0rpx 12rpx 0rpx;
	}
	.location_top{
		width: 120rpx;height: auto;background:#09BB07;color: #FFFFFF;border-radius: 12rpx 0rpx 12rpx 0rpx;
	}
	.location_center{
		justify-content: space-between;margin-top:15rpx;margin-left:10rpx;
	}
	.location_img{
		justify-content:flex-start
	}
	.flex_wrap{
		width: 393rpx;font-size: 28rpx;color: #666666;flex-direction: row;line-height: 32rpx;
	}
	.address_img{
		width: 40rpx;height: 44rpx;margin-left: 76rpx;margin-top: -15rpx;
	}
	.location_address_img image{
		width: 40rpx;height: 44rpx;
	}
	.paybutton{
		box-sizing: border-box;height:55rpx; font-size: 24rpx;border-radius: 22rpx;background: #3CC075;color: #FFFFFF;margin-left: 206rpx;
	}
</style>
