<template>
    <view class="uni-container">
		<!-- 头像与地址 -->
        <view class="payment-details">
			<view class="phoneto">
				<image :src="regiment_info.community_nameimg"></image>
			</view>
			<view class="shop">
				<view class="shopname" style="font-size: 30rpx;">{{regiment_info.community_name}}</view>
				<view class="shopadress">{{regiment_info.community_address}}</view>
			</view>
			<view class="iconleft">
				<image class="adress-img" :src="address_img"></image>
			</view>
		</view>
		<!-- 订单信息 -->
		<view class="order-information">
			<view class="order-mes" style="height: 50%;">
				<text style="margin-left: 23rpx;font-size: 28rpx;">订单信息</text>
			</view>
			<view class="order-number">
				<text  style="margin-left:23rpx;color: #666666;font-size: 26rpx;">订单编号:{{order_payment.order_number}}</text>
			</view>
		</view>
		<view class="paymentdetails">
			<view class="order-mes" style="height: 25%;">
				<text style="margin-left: 23rpx;font-size: 28rpx;">支付明细</text>
			</view>
			<view class="amount-payable">
				<text style="margin-left:23rpx;color: #666666;font-size: 26rpx;">应付金额</text>
				<text style="margin-right: 25rpx;color: #666666;font-size: 26rpx;">￥{{order_payment.order_sum}}</text>
			</view>
			<view class="paymentamount">
				<text style="margin-left:23rpx;color: #666666;font-size: 26rpx;">付款金额</text>
				<text style="margin-right: 25rpx;color:rgba(242,85,118,1);font-size: 26rpx;">￥{{order_payment.pay_money}}</text>
			</view>
			<view class="" style="height: 25%;width: 686rpx;display: flex;justify-content:space-between;align-items:center;">
				<text style="margin-left:23rpx;color: #666666;font-size: 26rpx;">优惠券</text>
				<text style="margin-right: 25rpx;color: #666666;font-size: 26rpx;">-￥{{order_payment.discount}}</text>
			</view>
		</view>
		<!-- 支付方式 -->
		<view class="pay-kind">
			<view class="order-mes" style="height: 33%;">
				<text style="margin-left: 23rpx;font-size: 28rpx;">支付方式</text>
			</view>
			<view class="order-mes" style="height: 33%;justify-content:space-between;">
				<view class="pay-left">
					<image class="wechat_img" :src="wechat_img"></image>
					<text style="margin-left: 10rpx;font-size: 28rpx;margin-left: 41rpx;">微信支付</text>
				</view>
				<image class="select_img" :src="select_img" @click="changeimg"></image>
			</view>
			<view class="order-mes" style="height: 33%;justify-content:space-between;">
				<view class="pay-left">
					<image class="commodity_img" :src="commodity_img"></image>
					<text style="margin-left: 10rpx;font-size: 28rpx;margin-left: 41rpx;">余额支付(<text style="color: #FF0000;">￥{{order_payment.balance}}</text>)</text>
				</view>
				<!-- <view class="circular" @click="changeimg()"></view> -->
				<image class="circular" :src="noselect" @click="changeimg"></image>
			</view>
		</view>
		<!-- 支付按钮 -->
		<view class="paybtn">
			<button class="paybutton" type="primary" @click="toplay()">立即支付</button>
		</view>
	</view>
</template>
<script>
    import api from '../../api/api.js'
    import { payOrder } from '../../api/conf.js'
    export default {

        data() {
          return{
			  regiment_info:[],//团长信息
			  order_payment:[],//订单信息
			  address_img:"../../static/commodity_icon/address.png",
			  wechat_img:"../../static/commodity_icon/wechat.png",
			  select_img:"../../static/select.png",
			  commodity_img:"../../static/commodity_icon/balance.png",
			  noselect:"../../static/no_select.png"
			  
			  
		  }
        },
        onLoad() {
			/* 数据请求 */
			api.get(payOrder, {
					order_id:"1",
				}).then(res => {
			this.regiment_info=res.leader_info;//团长信息
			this.order_payment=res.order_info;//商品订单信息
				}).catch(err => {
					uni.showToast({
						title: "数据异常",
						icon: 'none'
					})
				});
        },
        onReady() {
        },
        onShow() {
            
        },
        onHide() {
            
        },
        methods: {
            changeimg(){
				let changeimg="";
				changeimg=this.noselect;
				this.noselect=this.select_img;
				this.select_img=changeimg;
			},
			toplay(){
				//支付接口
				uni.requestPayment({
					provider: 'wxpay',
					timeStamp: String(Date.now()),
					nonceStr:'A1B2C3D4E5',
					package: 'prepay_id=wx20180101abcdefg',
					signType: 'MD5',
					paySign:'',
					success: function(res) {
						console.log('success:' + JSON.stringify(res));
					},
					fail: function(err) {
						console.log('fail:' + JSON.stringify(err));
					}
				});
				uni.showToast({
				    title: '支付成功',
				    duration: 2000
				});
			}
        }
    };
</script>

<style>
	/* 团长信息 */
	.phoneto image{
		width: 137rpx;height: 137rpx;margin-top: 29rpx;margin-left: 8rpx;
	}
	.shopadress{
		width: 392rpx;height: 61rpx;font-size: 28rpx;color: #666666;
	}
	.iconleft{
		margin-top: 75rpx;margin-left: 50rpx;
	}
	.adress-img{
		height: 44rpx;width: 40rpx;
	}
	
	.order-mes{
		width: 100%;border-bottom: 1px solid #F4F4F4;display: flex;align-items:center
	}
	.order-number{
		height: 50%;width: 100%;display: flex;align-items:center
	}
	.pay-left{
		display: flex; justify-content:flex-start;align-items:center
	}
	.wechat_img{
		width: 64rpx;height: 64rpx;margin-left:23rpx;
	}
	.select_img{
		height: 42rpx;width: 42rpx;margin-right: 25rpx;
	}
	.commodity_img{
		width: 64rpx;height: 64rpx;margin-left:23rpx;
	}
	.circular{
		width: 42rpx;height: 42rpx;margin-right: 25rpx;
	}
	
	.uni-container{
		width: 100%;
		height: auto;
	}
    .payment-details{
		width: 686rpx;
		height: 170rpx;
		background: #FFFFFF;
		display: flex;
		margin-left: 32rpx;
		margin-right: 32rpx;
	}
	.shop{
		margin-top: 29rpx;
		margin-left: 20rpx;
	}
	.shopadress{
		flex-wrap:wrap
	}
	/* 订单信息 */
	.order-information{
		width: 686rpx;
		height: 150rpx;
		background: #FFFFFF;
		margin-top: 32rpx;
		margin-left: 32rpx;
		margin-right: 32rpx;
	}
	/* 支付明细 */
	.paymentdetails{
		margin-top: 16rpx;height: 282rpx;width: 686rpx;background: #FFFFFF;margin-left: 32rpx;
		margin-right: 32rpx;
	}
	/* 应付金额 */
	.amount-payable{
		height: 25%;width: 686rpx;display: flex;justify-content:space-between;align-items:center;
	}
	/* 付款金额 */
	.paymentamount{
		height: 25%;width: 686rpx;display: flex;justify-content:space-between;align-items:center;
	}
	/* 支付方式 */
	.pay-kind{
		width: 686rpx;
		height: 308rpx;
		background: #FFFFFF;
		margin-top: 16rpx;
		margin-left: 32rpx;
		margin-right: 32rpx;
	}
	.paybtn{
		margin-top: 146rpx;height: 130rpx;width: 100%;background: #FFFFFF;display: flex;align-items:center;justify-content:center
	}
	.paybutton{
		width:618rpx;background:linear-gradient(0deg,rgba(60,192,117,1) 0%,rgba(55,176,107,1) 100%);border-radius:12px;
	}
</style>
