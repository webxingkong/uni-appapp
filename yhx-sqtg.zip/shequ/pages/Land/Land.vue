<template>
	<view>
	<view style="background: url(../../static/bg.png); width: 750rpx;height:1333rpx;">
	
<view class="Landing_Background">
	<view class="Landing_Background_DIV rel">
	
	<view>
	<view class="Title b">
	<text>绑定您的手机号</text>
	</view>
	</view>
	<!--上面绑定手机号-->
	<view  class="bottom">
	<view class="Input_box">
	<input placeholder="请输入你的手机号" class="Input_high" v-model="Mobilevalue.Mobile_phone" maxlength="11">
	</view>
	</view>
	<!--上面是手机号-->
	<!--下面是验证码-->
	<view>
	<view class="Input_box" style="width: 60%; height: auto; float: left; display: inline;">
	<input placeholder="请输入你的验证码" class="Input_high" v-model="Mobilevalue.Verification">
	</view>
	<view style="text-align: center; width: 39%; float: left;">
		<navigator url="">
	<view class="Obtain mt30 ml30 f28" @click="getCode">
	<text style="font-size:25rpx;">{{count}}获取验证码</text>
	</view>
	</navigator>
	</view>
	
	</view>
	<!--下面是登陆按钮-->
	<navigator>
	<view class="Landing_button">
	<view class="Land tc">
		<text @click="Sign()" class="lh40">绑定</text>
	</view>
	</view>
			</navigator>
			</view>
	</view>
	</view>
</view>
</template>

<script>
	import api from '../../api/api.js'
	import { placeOrder } from '../../api/conf.js'
export default{
	data(){
		return{
			"Mobilevalue":{
				Mobile_phone:[],//输入的手机号码
				Verification:[]//输入的验证码
			},
			"switchcation":true,
			"count": "",
			"timer": null,
		}
	},
	methods:{
		getCode(){
		const TIME_COUNT =60;
		if (!this.timer) {
		this.count = TIME_COUNT;
		this.timer = setInterval(() => {
		if (this.count > 0 && this.count <= TIME_COUNT) {
		this.count--;
		if(this.count==0){
			this.count="";
		}
		} else {
			
		clearInterval(this.timer);
		this.timer = null;
		}
		}, 1000)
		}
		},
		Sign(){
			/* 数据请求 */
						api.post(placeOrder, {
						    leader_id:"1",
						}).then(res => {

						}).catch(err => {
						    uni.showToast({
						        title: "数据异常",
						        icon: 'none'
						    })
						})
		}
	}
}
</script>

<style>
.Input_high{
	height:90rpx;
}/*输入-框高*/
	.Obtain{
		color: #666666;
		border: solid 1rpx #999999;
		border-radius: 17rpx;
	}/*获取验-证码*/
	.Input_box{
		 width: 530rpx;
		 border-bottom: solid 1rpx #999999;/* 下划线 */
		}/*下划线-部分*/
		
	.Title{
		color: #333333;
		font-size: 36rpx;
	width: 530rpx;
	 height: 120rpx;
	}/*加粗的-文字*/
	.Landing_button {
	background-color: #37B06B;
	height: 90rpx;
	width: 525rpx;
	margin-top: 230rpx;
	border-radius: 12rpx;
	}/*登陆按钮*/
.Landing_Background_DIV{
	width: 530rpx;
	 height: 595rpx;
	margin: auto;
	top: 6%;/*调整中间零件的上下距离*/
	  margin-top: 120rpx;
	  }
	  .Land{
		  color: #ffffff;
		  font-size: 36rpx;
	  }
	/*登陆DIV*/
</style>
